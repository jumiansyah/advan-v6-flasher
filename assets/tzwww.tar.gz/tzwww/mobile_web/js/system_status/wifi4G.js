/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-30 14:55:05
 * @,@LastEditTime: ,: 2021-02-22 16:14:33
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_status\wifi4G.js
 */
/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-27 17:07:49
 * @,@LastEditTime: ,: 2020-11-30 10:01:49
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\wan.js
 */
$(document).ready(function () {
    var loading = "-";
    var wifi_names = [DOC.wlan.currentMode, DOC.wlan.wifi, DOC.wlan.ssidBroadcast, DOC.wlan.ssid, DOC.wlan.channel, wirelessconfightml.form1.bandWidth, wirelessconfightml.form1.wepMode];
    var wifi24G_values = new Array(7);
    var form1 = wirelessconfightml.form1;
    var vm = new Vue({
        el:"#status-wifi4G",
        data(){
            return{
                title: wirelessconfightml.tab_menu.connectedList,
                title1:MENU.info.wifi24,
                title2:networkconfig2html.helper.title1,
                title3:wirelessconfightml.form1.radiusIp,
                title4:DOC.wlan.ssid,
                title5:DOC.lte.signalLeveldBm,
                title6:wirelessconfightml.prompt.trate,
                title7:wirelessconfightml.prompt.rxrate,
                active:0,
                wifi_names:wifi_names,
                wifi24G_values: wifi24G_values,
                deviceList:[],
                show:false,
                user:"",
                mac:"",
                ip:"",
                rssi:"",
                ssid:"",
                txrate:"",
                rxrate:""
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            clickTab(value){
                // if(value==1){
                //     this.getDevice();
                //     Page.timer = setInterval(function () {
                //         vm.getDevice();
                //     }, 3000);
                // }
            },
            showDetail(value){
                this.show = true
                this.user = value.user
                this.mac = value.mac
                this.ip = value.ip
                this.ssid = value.ssid
                this.rssi = value.rssi
                this.txrate = value.txrate
                this.rxrate = value.rxrate
            },
            getWlanMode: function (mode) {
                var secMode = "";
                switch (mode) {
                    case "0":
                        secMode = "11b only";
                        break;
                    case "1":
                        secMode = "11g only";
                        break;
                    case "2":
                        secMode = "11n only";
                        break;
                    case "3":
                        secMode = "11b/g";
                        break;
                    case "4":
                        secMode = "11g/n";
                        break;
                    case "5":
                        secMode = "11b/g";
                        break;
                    case "6":
                        secMode = "11b/g/n";
                        break;
                }
                return secMode;
            },
            getWepMode: function (mode) {
                var secMode = "";
                switch (mode) {
                    case "0":
                        secMode = form1.openSys;
                        break;
                    case "1":
                        secMode = "WPA-PSK";
                        break;
                    case "2":
                        secMode = "WPA2-PSK";
                        break;
                    case "3":
                        secMode = "WPA/WPA2-PSK";
                        break;
                    case "4":
                        secMode = "WPA3-PSK";
                        break;
                    case "5":
                        secMode = "WPA2/WPA3-PSK";
                        break;
                    case "6":
                        secMode = "WEP";
                        break;
                }
                return secMode;
            },
            getBandWidth: function (mode) {
                var secMode = "";
                switch (mode) {
                    case "0":
                        secMode = "20MHz";
                        break;
                    case "1":
                        secMode = "40MHz";
                        break;
                    case "2":
                        secMode = "20/40MHz";
                        break;
                }
                return secMode;
            },
            getData24G: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS_CONFIG,
                        methods: JSONMethod.GET,
                        wifi_advance: 1,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.$set(wifi24G_values, 0, vm.getWlanMode(data.wifiWorkMode) || loading);
                        vm.$set(wifi24G_values, 1, data.wifiOpen == "1" ? DOC.status.enable : DOC.status.disable);
                        vm.$set(wifi24G_values, 2, data.broadcast == "1" ? DOC.status.enable : DOC.status.disable);
                        vm.$set(wifi24G_values, 3, Base64.decode(data.ssid) || loading);
                        vm.$set(wifi24G_values, 4, data.channel || loading);
                        vm.$set(wifi24G_values, 5, vm.getBandWidth(data.bandWidth) || loading);
                        vm.$set(wifi24G_values, 6, vm.getWepMode(data.authenticationType) || loading);
                    }
                })
    
            },
            getDevice(){
                Page.postJSON({
                    json: { cmd: RequestCmd.WIFI24G_LIST_INFO,method:JSONMethod.GET},
                    success: function (datas) {
                      var list;
                      list = datas.wlan24g_wifi_info;
                      if(list){
                          vm.deviceList = list;
                      }else{
                          vm.deviceList.length = 0;
                      }
                    }
                });
            }
        },
        mounted(){
            this.getData24G();
            this.getDevice();
            Page.timer = setInterval(function () {
                vm.getData24G();
                vm.getDevice();
            }, 3000);
        }
    })
})