/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-07 09:28:29
 * @,@LastEditTime: ,: 2021-03-05 15:47:32
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_manage\set\changePass.js
 */
$(document).ready(function () {
    var index = sessionStorage.getItem("index")
    var vm = new Vue({
        el:"#set-pass",
        data(){
            return{
                title:TAB.sys.changePasswd,
                title2:DOC.sys.oldPasswd,
                title3:CHECK.required.oldPasswd,
                title4:DOC.sys.newPasswd,
                title5:CHECK.range.passwd,
                title6:CHECK.required.duplicateNewPasswd,
                oldPasswd:DOC.sys.oldPasswd,
                newPasswd:DOC.sys.newPasswd,
                colon:DOC.colon,
                duplicateNewPasswd:DOC.sys.duplicateNewPasswd,
                btnSave:DOC.btn.save,
                btnSave:DOC.btn.save,
                show:false,
                oldPass: '',
                newPass: '',
                affirmPass:"",
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/system_manage/setting.html")
                pageUrl = "html/system_manage/setting.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            formatter(value) {
                // 过滤输入的空格
                return value.replace(/\s/g, '');
              },
            btnSaveClick:function(){
                var pattern  = /^[\u4E00-\u9FA5\uF900-\uFA2D\u0020]*$/;
				var reg = new RegExp(/\s/)
				if(pattern.test(this.newPass)||reg.test(this.newPass)){
                    failLoad(CHECK.format.loginPass);
                    return false;
				}
               var json = {};
               if(vm.newPass != vm.affirmPass)
                {
                    failLoad(CHECK.format.passwdNotSame)
                    return false;
                }
                
               json.cmd = RequestCmd.CHANGE_PASSWD;
               json.method = JSONMethod.POST;
               json.newPasswd = this.newPass;
               json.old_passwd = this.oldPass;
               json.subcmd = 0;
               loading();
               Page.postJSON({
                   json: json,
                   success: function(data) {
                       if(data.message == "success"){
                           vm.oldPass = "";
                           vm.newPass = "";
                           vm.affirmPass = "";
                           clearToast();
                           successLoad();
                       }else if(data.message == "passwd error"){
                           failLoad(PROMPT.saving.previousPasswd)
                       }else{
                           failLoad()
                       }
                       
                   }
               });
            },
        },
        mounted(){
            this.$nextTick(()=>{
                this.$refs.oldPass.focus()
            })
        }
    })
})