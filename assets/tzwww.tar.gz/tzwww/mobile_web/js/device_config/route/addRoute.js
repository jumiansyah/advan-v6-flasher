/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-04 17:38:49
 * @,@LastEditTime: ,: 2021-03-18 10:36:59
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\device_config\route\addRoute.js
 */
$(document).ready(function () {
    var key = sessionStorage.getItem("key")
    var vm = new Vue({
        el:"#route-add",
        data(){
            return{
                title:TAB.route.AddroutingTable,
                title2:networktoolhtml.form5.btnSetting,
                title3:DOC.table.del,
                show:false,
                status: DOC.lbl.status,
                destinationIp: DOC.net.destinationIp,
                colon: DOC.colon,
                mask: DOC.net.mask,
                gateway: DOC.net.gateway,
                intername: DOC.lan.intername,
                valid: DOC.status.validEntry,
                invalid: DOC.status.invalid,
                checkIP:CHECK.format.ip,
                netmaskCheck: CHECK.required.netmaskCheck,
                gatewayCheck:CHECK.format.gateway,
                isDel:false,
                destination: '',
                internameValue: "1",
                maskNet: '',
                gatewayValue: '',
                validValue: "1",
                lanIP:"",
                tableContent:[],
                pattern:/^((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]).){3}(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])(?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/,
                pattern1:/^192\.168(\.(\d|([1-9]\d)|(1\d{2})|(2[0-4]\d)|(25[0-5]))){2}$/
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/device_config/route.html")
                pageUrl = "html/device_config/route.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onSelect(value,key){
                this.show = false
                this.selectAuth = value
            },
            validator(val){
                return /^(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/.test(val)
            },
            
            getData() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ROUTER_TABLE,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        if (datas.datas) {
                            vm.tableContent = datas.datas;
                        }
                        for (var i = 0; i < vm.tableContent.length; i++) {
                            if (key == i) {
                                vm.validValue = vm.tableContent[i].valid==true?"1":"2"
                                vm.internameValue = vm.tableContent[i].ifName=="WAN"?"1":"2"
                                
                                vm.destination = vm.tableContent[i].ip
                                vm.maskNet = vm.tableContent[i].netmask
                                vm.gatewayValue = vm.tableContent[i].gateway
                            }
                        }

                    }
                });
            },
            getLanIP() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LAN_INFO
                    },
                    success: function (data) {
                        vm.lanIP = data.lan_ip
                    }
                })
            },
            onSubmit(){
                var res1 = [], res2 = [];
                addr1 = this.lanIP.split(".");
                addr2 = this.destination.split(".");
                mask  = this.maskNet.split(".");
                for(var i = 0,ilen = addr1.length; i < ilen ; i += 1){
                    res1.push(parseInt(addr1[i]) && parseInt(mask[i]));
                    res2.push(parseInt(addr2[i]) && parseInt(mask[i]));
                }
                if(res1.join(".") == res2.join(".")){
                    failLoad(CHECK.format.destination)
                    return false
                }
                if (key>=0) {
                    this.tableContent[key].valid = this.validValue == "1"? true : false;
                    this.tableContent[key].ifName = this.internameValue == "1" ? "WAN" : "LAN";
                    this.tableContent[key].netmask = this.maskNet
                    this.tableContent[key].ip = this.destination;
                    this.tableContent[key].netmaskBits = FormatUtil.formatMaskBit(this.maskNet);
                    this.tableContent[key].gateway = this.gatewayValue;
                } else {
                    var tmp = {};
                    tmp.valid = this.validValue == "1"? true : false;
                    tmp.ifName = this.internameValue == "1" ? "WAN" : "LAN";
                    tmp.netmask = this.maskNet;
                    tmp.ip = this.destination;
                    tmp.netmaskBits = FormatUtil.formatMaskBit(this.maskNet);;
                    tmp.gateway = this.gatewayValue;
                    
                    this.tableContent.push(tmp);
                }
                $("#app").load("html/device_config/route.html")
                loading();
                var json = {};
                console.log(this.tableContent);
                json.method = JSONMethod.POST;
                json.datas = this.tableContent;
                json.success = true;
                json.cmd = RequestCmd.ROUTER_TABLE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            clearToast();
                            successLoad()
                        } else {
                            failLoad()
                        }
                    }
                });
            },
            del(){
                vant.Dialog.confirm({
                    message: '是否确认删除',
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(() => {
                        vm.tableContent.splice(key, 1);
                        var json = {};
                        loading();
                        json.method = JSONMethod.POST;
                        json.datas = vm.tableContent;
                        json.success = true;
                        json.cmd = RequestCmd.ROUTER_TABLE;
                        Page.postJSON({
                            json: json,
                            success: function (data) {
                                if (data.success == true) {
                                    clearToast();
                                    successLoad()
                                    $("#app").load("html/device_config/route.html")
                                } else {
                                    failLoad()
                                }
                            }
                        });
                    })
                    .catch(() => {
                      vm.getData();
                    });
            }
        },
        mounted(){
            if(key>=0){
                this.isDel = true
            }else{
                this.isDel = false
            }
            this.getData();
            this.getLanIP();
        },
    })
})
