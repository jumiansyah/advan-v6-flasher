/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 10:02:46
 * @,@LastEditTime: ,: 2021-01-21 16:19:40
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\modelIntnet.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#mobile-net",
        data(){
            return{
                title:DOC.lbl.netMode,
                title2:DOC.lbl.flightMode,
                title3:TAB.advance.dataSwitch,
                title4:DOC.lbl.roaming,
                title5:TAB.advance.networkSet,
                flightMode: DOC.lbl.flightMode,
                dataSwitch:TAB.advance.dataSwitch,
                dataRoaming: TAB.advance.dataRoaming,
                checked:false,
                checked2:false,
                checked3:false,
                title1:fourgInfohtml.helper.title1,
                show:false,
                value:"",
                networkModeValue: "",
                selectIndex:"",
                listName:"",
                list: [
                    {
                        value: "9",
                        text: "TD-LTE/LTE FDD/W/TD/GSM"
                    },
                    {
                        value: "6",
                        text: "TD-LTE/LTE FDD/W/GSM"
                    },
                    {
                        value: "4",
                        text: "LTE FDD/W/GSM"
                    },
                    {
                        value: "5",
                        text: "TD-LTE/W/TD/GSM"
                    },
                    {
                        value: "1",
                        text: "TD-LTE"
                    },
                    {
                        value: "2",
                        text: "LTE FDD"
                    },
                    {
                        value: "3",
                        text: "4G Only"
                    }, //TD-LTE/LTE FDD
                    {
                        value: "7",
                        text: "TD-LTE/TD/GSM"
                    },
                    {
                        value: "8",
                        text: "TD-LTE/LTE FDD/TD/GSM"
                    },
                    {
                        value: "15",
                        text: "GSM"
                    },
                    {
                        value: "11",
                        text: "W"
                    },
                    {
                        value: "14",
                        text: "WG"
                    },
                    {
                        value: "12",
                        text: "TD"
                    },
                    {
                        value: "13",
                        text: "TG"
                    },
                    {
                        value: "131",
                        text: "5G SA+NSA/4G"
                    }, //TD-LTE/LTE FDD
                    {
                        value: "333",
                        text: "5G NSA Only"
                    }, //TD-LTE/LTE FDD
                    {
                        value: "128",
                        text: "5G SA Only"
                    }, //5G
                    {
                        value: "134",
                        text: "5G/TD-LTE/LTE FDD/W/GSM"
                    },
                    {
                        value: "135",
                        text: "5G/TD-LTE/TD/GSM"
                    },
                    {
                        value: "137",
                        text: "5G/TD-LTE/LTE FDD/TD/W/GSM"
                    }
                ],
            }
        },
        methods:{
            
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.FLIGHT_MODE_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked = data.flightMode == "1" ? true:false;
                    }
                });
            },
            submit(){
                var json = {};
                loading();
                json.flightMode = this.checked ? "1" : "0";
                json.cmd = RequestCmd.FLIGHT_MODE_INFO;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.message == "0") {
                            clearToast()
                            successLoad();
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            getData2(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.AUTO_DIAL,
                        method:JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked2 = data.dialMode == "1" ? true:false;
                    }
                });
            },
            submit2(){
                var json = {};
                loading();
                json.dialMode = this.checked2 ? "1" : "0";
                json.cmd = RequestCmd.AUTO_DIAL;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            clearToast();
                            successLoad();
                        }else{
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            getData3(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DATA_ROAMING,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked = data.roamingEnable == "1" ? true:false;
                    }
                });
            },
            submit3(){
                var json = {};
                loading();
                json.roamingEnable = this.checked ? "1" : "0";
                json.cmd = RequestCmd.DATA_ROAMING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.message == "") {
                            clearToast()
                            successLoad();
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            onSelect(item) {
                this.show = false;
                this.networkModeValue = item.value;
                this.listName = item.text;
                loading()
                var json = {}
                json.networkMode = this.networkModeValue;
                if(this.networkModeValue == "131" || this.networkModeValue == "128" || 
                   this.networkModeValue == "134" || this.networkModeValue == "135" ||
                   this.networkModeValue == "137"){
                    json.mode5g = "1";
                }else if(this.networkModeValue == "333"){
                    json.mode5g="0";
                    json.networkMode = "131"
                }else{
                    json.mode5g="0";
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORKSET_MODE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            clearToast()
                            successLoad();
                        }else{
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            getData4: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORKSET_MODE,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if(data.mode5g == "0" && data.networkMode== "131"){
                            vm.networkModeValue = "333";
                        }else{
                            vm.networkModeValue = data.networkMode;
                        }
                        for(var i=0;i<vm.list.length;i++){
                            if(vm.networkModeValue == vm.list[i].value){
                              vm.listName = vm.list[i].text;
                              vm.selectIndex = i;
                            }
                          }
                    }
                });
            },
            onCel(){
                this.show = false;
            },
            openList(){
                this.show = true;
                for(var i=0;i<vm.list.length;i++){
                    if(vm.networkModeValue == vm.list[i].value){
                      vm.selectIndex = i
                    }
                  }
            }

        },
        mounted(){
            this.getData();
            this.getData2();
            this.getData3();
            this.getData4();
            if(Page.level != "1"){
                this.list=[{
                    text:"4G Only",
                    value:"3"
                  },
                  {
                    text:"5G SA+NSA/4G",
                    value:"131"
                  },
                  {
                    text:"5G NSA Only",
                    value:"333"
                  },
                  {
                    text:"5G SA Only",
                    value:"128"
                  }]
            }
        }
    })
})