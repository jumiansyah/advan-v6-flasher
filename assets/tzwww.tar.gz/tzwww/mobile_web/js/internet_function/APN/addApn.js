/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-02 10:46:09
 * @,@LastEditTime: ,: 2021-01-23 14:45:41
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\APN\addApn.js
 */
$(document).ready(function () {
    var index = sessionStorage.getItem("index")
    var vm = new Vue({
        el:"#apn-add",
        data(){
            return{
                title:DOC.apn.addAPN,
                title5:DOC.apn.editAPN,
                title1:CHECK.required.noEmpty,
                title2:DOC.apnHelper.title5,
                title3:DOC.apnHelper.title6,
                title4:DOC.apnHelper.title7,
                save:DOC.vpn.btnSave,
                del:DOC.table.del,
                comfireDel:CHECK.tip.delete,
                show:false,
                showPass:false,
                user: '',
                pass: '',
                name:"",
                apn:"",
                select_authentication: ["NONE", "PAP", "CHAP", "PAP&CHAP"],
                selectAuth:"NONE",
                editNum: 0,
                isDel:false,
                selectIndex:""
            }
        },
        methods:{
            openList(){
                this.show = true;
                this.selectIndex = this.getIndex
            },
            onClickLeft(){
                $("#app").load("html/internet_function/apn.html")
                pageUrl = "html/internet_function/apn.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onSelect(value){
                this.show = false
                this.selectAuth = value
            },
            getData() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_INFO_PROCESS,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.apn_list = datas.apn_list;
                        for (var i = 0; i < datas.apn_list.length; i++) {
                            if (index == i) {
                                vm.name = vm.apn_list[i].name
                                vm.apn = vm.apn_list[i].apnName
                                
                                vm.selectAuth = vm.apn_list[i].selectAuthtication == "0"?"NONE":vm.apn_list[i].selectAuthtication=="1"?"PAP":vm.apn_list[i].selectAuthtication=="2"?"CHAP":"PAP&CHAP" || "NONE"
                                vm.user = vm.apn_list[i].apnUserName || ""
                                vm.pass = vm.apn_list[i].apnUserPassword || ""
                            }
                        }

                    }
                });
            },
            onSubmit(){
                if (index>=0) {
                    this.apn_list[index].name = this.name;
                    this.apn_list[index].apnName = this.apn;
                    this.apn_list[index].selectAuthtication = this.selectAuth == "NONE"?"0":this.selectAuth=="PAP"?"1":this.selectAuth=="CHAP"?"2":"3"
                    this.apn_list[index].apnUserName = this.user;
                    this.apn_list[index].apnUserPassword = this.pass;
                } else {
                    var tmp = {};
                    tmp.name = this.name;
                    tmp.apnName = this.apn;
                    tmp.selectAuthtication = this.selectAuth == "NONE"?"0":this.selectAuth=="PAP"?"1":this.selectAuth=="CHAP"?"2":"3";
                    tmp.apnUserName = this.user;
                    tmp.apnUserPassword = this.pass;
                    tmp.edit_flag = "1";
                    tmp.default_flag = "0";
                    this.apn_list.push(tmp);
                }
                
                if (vm.editNum >= 4) {
                    AlertUtil.alertMsg(DOC.apn.fullAPN);
                    return false;
                }
                var json = {};
                loading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.APN_INFO_PROCESS;
                json.apn_list = this.apn_list;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            vm.editNum += 1;
                            clearToast();
                            successLoad()
                            $("#app").load("html/internet_function/apn.html")
                            pageUrl = "html/internet_function/apn.html"
                            sessionStorage.setItem("pageUrl",pageUrl)
                        } else {
                            failLoad()
                        }
                    }
                });
            },
            deleteApn(){
                vant.Dialog.confirm({
                    message: vm.comfireDel,
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(() => {
                        vm.editNum -= 1;
                        vm.apn_list.splice(index, 1);
                        var json = {};
                        loading();
                        json.method = JSONMethod.POST;
                        json.cmd = RequestCmd.APN_INFO_PROCESS;
                        json.apn_list = this.apn_list;
                        Page.postJSON({
                            json: json,
                            success: function (data) {
                                if (data.success == true) {
                                    vm.editNum += 1;
                                    clearToast();
                                    successLoad()
                                    $("#app").load("html/internet_function/apn.html")
                                    pageUrl = "html/internet_function/apn.html"
                                    sessionStorage.setItem("pageUrl",pageUrl)
                                } else {
                                    failLoad()
                                }
                            }
                        });
                    })
                    .catch(() => {
                      vm.getData();
                    });
            }
        },
        mounted(){
            if(index>=0){
                this.isDel = true
            }else{
                this.isDel = false
            }
            this.getData()
        },
        computed:{
            getIndex(){
                switch(vm.selectAuth){
                    case "NONE":
                        return 0
                    case "PAP":
                        return 1
                    case "CHAP":
                        return 2
                    case "PAP&CHAP":
                        return 3
                }
            }
        }
    })
})