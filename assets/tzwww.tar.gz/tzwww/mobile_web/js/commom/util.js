/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 20:01:51
 * @,@LastEditTime: ,: 2021-01-27 21:05:50
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\commom\util.js
 */
function loading(mes){
    if(mes){
        PROMPT.status.saveing = mes
    }
    vant.Toast.loading({
        message: PROMPT.status.saveing||'保存中...',
        forbidClick: true,
        duration:0
    });
}
function clearToast(){
    vant.Toast.clear();
}
function successLoad(mes){
    if(mes){
        vant.Toast.success(mes);
    }else{
        vant.Toast.success(PROMPT.status.success);
    }
    
}
function failLoad(mes){
    var message = PROMPT.status.fail;
    if(mes){
        message = mes
    }
    vant.Toast.fail(message);
}
// 重启成功 与loading()连用
function successReboot(params){
    var timer = setInterval(() => {
        Page.postJSON({
            json: { cmd: RequestCmd.ROUTER_INFO },
            success: function(res) {
                if(res.success){
                    clearToast();
                    successLoad();
                    clearInterval(timer);
                    location.reload();
                }
            }
        })
    }, 5000);
}

function disconnect(){
    location.href = Page.getUrl(Url.LOGIN);
    vant.Toast(CHECK.format.disconnect);
}

//wifi断开
function wifiConnect(){
    var timer1 = setInterval(() => {
        Page.postJSON({
            json: { cmd: RequestCmd.GET_SYS_STATUS },
            success: function(res) {
                
            },
            error:function(){
                location.href = Page.getUrl("/mobile_web/login.html");
                clearInterval(timer1);
                vant.Toast(CHECK.format.disconnect);
            }
        })
    }, 5000);
}

function loadScript(url, callback) {
    var script = document.createElement("script");
    script.type = "text/javascript";
    if(typeof(callback) != "undefined"){
      if (script.readyState) {
        script.onreadystatechange = function () {
          if (script.readyState == "loaded" || script.readyState == "complete") {
            script.onreadystatechange = null;
            callback();
          }
        };
      } else {
        script.onload = function () {
          callback();
        };
      }
    }
    script.src = url;
    $("head")[0].appendChild(script);
  }

  function wifiValidator1(value){
    var length = value.length;
    var totalLength = 0;
    for(var i = 0; i < length; i++){
        charCode = value.charCodeAt(i);
        if (charCode < 0x007f) {
            totalLength = totalLength + 1;
        } else if ((0x0080 <= charCode) && (charCode <= 0x07ff)) {
            totalLength += 2;
        } else if ((0x0800 <= charCode) && (charCode <= 0xffff)) {
            totalLength += 3;
        }
    }
    return totalLength >= 4 && totalLength <= 31;  
}

function wifiValidator2(value){
    var reg = /[\u4E00-\u9FA5]/g;
    var reg2 = /^.{8,31}$/;
    return !reg.test(value) &&reg2.test(value)
}

function userPassValidator(value){
    var reg2 = /^.{5,20}$/;
    return reg2.test(value)
}
//   function getCurrentLanguage(callback){
//     Page.postJSON({
//         json: {
//             cmd: RequestCmd.INIT_PAGE
//         },
//         success: function (data) {
//             var culanguage = data.language.toUpperCase();
//             sessionStorage.setItem("language",culanguage)
//         }
//     })
//   }