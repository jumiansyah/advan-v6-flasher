$(document).ready(function(){
	var loading = '-';
	var tableName = [DOC.device.imei,DOC.device.firmwareVersion,DOC.device.boardType,DOC.device.hardwareVersion, DOC.device.lanMac,
					DOC.device.configVersion,DOC.lbl.runtime,DOC.net.mask,DOC.net.gateway,DOC.lbl.dns,DOC.device.buildTime];
	var tableValue = new Array(11);
	var vm = new Vue({
		el:"#main_box",
		data:{
			tableArr:[],
			tableName:tableName,
			tableValue:tableValue,
			selfCheckingHtml:''
		},
		methods:{
			getTableData:function(){
				 Page.postJSON({
				 	 json: { cmd: RequestCmd.DEVICE_VERSION_INFO },
				 	 success: function(data) {
				 	    //IMEI
				 	 	vm.$set(tableValue,0,FormatUtil.formatField(data.module_imei || loading));
				 	 	//固件版本
				 	 	vm.$set(tableValue,1,FormatUtil.formatField(data.real_fwversion || loading));
				 	 	// 设备名称
				 	 	vm.$set(tableValue,2,FormatUtil.formatField(data.board_type || loading));
				 	 	//硬件版本
				 	 	vm.$set(tableValue,3,FormatUtil.formatField(data.hwversion || loading));
				 	 	//LAN MAC
				 	 	vm.$set(tableValue,4,FormatUtil.formatField(data.lan_mac || loading));
				 	 	//配置版本
				 	 	vm.$set(tableValue,5,FormatUtil.formatField(data.config_version || loading));
				 	 	//运行时间
				 	 	
				 	 	vm.$set(tableValue,6,ConvertUtil.parseUptime2(data.uptime) || loading);
				 	 	//WAN口子网掩码
				 	 	vm.$set(tableValue,7,FormatUtil.formatField(data.wan_netmask || loading));
				 	 	//WAN口网关
				 	 	vm.$set(tableValue,8,FormatUtil.formatField(data.wan_gateway || loading));
				 	 	//WAN口DNS
				 	 	vm.$set(tableValue,9,FormatUtil.formatField(data.wan_dns || loading));
				 	 	vm.$set(tableValue,10,FormatUtil.formatField(data.build_date || loading));
				 	 	StatusUtil.getSysStatus();
				 	 }
				 })
			}
		},
		mounted:function(){
			this.getTableData();
		}
	})
});
