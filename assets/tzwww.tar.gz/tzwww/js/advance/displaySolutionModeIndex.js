$(document).ready(function () {

    var items = [];
    var id = "DISPLAY_SOLUTION_MODE";

    items.push({ title: TAB.basic.displaySolution, url: 'html/advance/displaySolutionMode.html' })

    secondMenuClick(items,id);
});


