$(document).ready(function () {
    var fm = ["networkForm", "child_container", "networkFormId"];
    var vm = new Vue({
        el: "#child_container",
        data: {
            disabled: false,
            networkModeValue: "1",
            networkMode: DOC.lte.networkMode,
            colon: DOC.colon,
            Btnset: DOC.btn.set,
            mode5gList: [{
                    "index": "0",
                    "name": "NSA Only"
                },
                {
                    "index": "1",
                    "name": "SA/NSA"
                }
            ],
            list: [
                // {
                //     index: "9",
                //     "name": "TD-LTE/LTE FDD/W/TD/GSM"
                // },
                // {
                //     index: "6",
                //     "name": "TD-LTE/LTE FDD/W/GSM"
                // },
                // {
                //     index: "4",
                //     "name": "LTE FDD/W/GSM"
                // },
                // {
                //     index: "5",
                //     "name": "TD-LTE/W/TD/GSM"
                // },
                // {
                //     index: "1",
                //     "name": "TD-LTE"
                // },
                // {
                //     index: "2",
                //     "name": "LTE FDD"
                // },
                {
                    index: "6",
                    "name": "Auto"
                }, //TD LTE/LTE FDD/W/GSM Four mode
                {
                    index: "24",
                    "name": "4G/3G"
                }, //LTE and WCDMA
                {
                    index: "3",
                    "name": "4G Only"
                }, //TD-LTE/LTE FDD
                {
                    index: "11",
                    "name": "3G Only"
                }, //WCDMA only
                
                {
                    index: "10",
                    "name": "2G Only"
                }, //GSM only
              
                // {
                //     index: "7",
                //     "name": "TD-LTE/TD/GSM"
                // },
                // {
                //     index: "8",
                //     "name": "TD-LTE/LTE FDD/TD/GSM"
                // },
                // {
                //     index: "15",
                //     "name": "GSM"
                // },
                // {
                //     index: "11",
                //     "name": "W"
                // },
                // {
                //     index: "14",
                //     "name": "WG"
                // },
                // {
                //     index: "12",
                //     "name": "TD"
                // },
                // {
                //     index: "13",
                //     "name": "TG"
                // },
                // {
                //     index: "131",
                //     "name": "5G SA+NSA/4G"
                // }, //TD-LTE/LTE FDD
                // {
                //     index: "333",
                //     "name": "5G NSA Only"
                // }, //TD-LTE/LTE FDD
                // {
                //     index: "128",
                //     "name": "5G SA Only"
                // }, //5G
                // {
                //     index: "134",
                //     "name": "5G/TD-LTE/LTE FDD/W/GSM"
                // },
                // {
                //     index: "135",
                //     "name": "5G/TD-LTE/TD/GSM"
                // },
                // {
                //     index: "137",
                //     "name": "5G/TD-LTE/LTE FDD/TD/W/GSM"
                // }
            ],
            helps: [
                // {
                //     title: "4G Only",
                //     item: network.helper.item1
                // },
                // {
                //     title: "5G SA+NSA/4G",
                //     item: network.helper.item2
                // },
                // {
                //     title: "5G NSA Only",
                //     item: network.helper.item3
                // },
                // {
                //     title: "5G SA Only",
                //     item: network.helper.item4
                // }
                
            ]
        },
        methods: {
            btnSave: function () {
                this.disabled = true;
                fyAlertMsgLoading();
                var json = {};
                json.networkMode = vm.networkModeValue;
                if (vm.networkModeValue == "131" || vm.networkModeValue == "128" ||
                    vm.networkModeValue == "134" || vm.networkModeValue == "135" ||
                    vm.networkModeValue == "137") {
                    json.mode5g = "1";
                } else if (vm.networkModeValue == "333") {
                    json.mode5g = "0";
                    json.networkMode = "131"
                } else {
                    json.mode5g = "0";
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORKSET_MODE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            StatusUtil.getSysStatus();
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.disabled = false;
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORKSET_MODE,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if (data.mode5g == "0" && data.networkMode == "131") {
                            vm.networkModeValue = "333";
                        } else {
                            vm.networkModeValue = data.networkMode;
                        }
                    }
                });
            },
            isShowMode: function (event) {
                if (Page.level != "1") {
                    if (event == "3" || event == "6" || event == "24" || event == "10"||event=="11") {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
        }
    });
});
