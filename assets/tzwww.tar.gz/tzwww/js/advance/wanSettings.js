$(document).ready(function () {
    var fm = ["childForm", "wanform", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#wanform",
        data: {
            menu_wan: MENU.setting.wan,
            prompt_wan: wirelessconfightml.prompt.wan,
            colon: DOC.colon,
            prompt_lan: wirelessconfightml.prompt.lan,
            prompt_mac: wirelessconfightml.prompt.mac,
            prompt_edit: wirelessconfightml.prompt.edit,
            lbl_example: DOC.lbl.example,
            btn_save: DOC.btn.save,
            picked: '',
            mac: '',
            edit: false,
            bu_sa: false
        },
        methods: {
            btnSaveMac: function () {
                this.bu_sa = true;
                var json = {};
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WAN_MAC_SETTINGS;
                json.mac = this.mac;
                json.model = vm.picked;
                if (json.model == "lan") {
                    delete json.mac;
                }
                if (json.model == "wan") {
                    if (!CheckUtil.checkMac(json.mac)) {
                        AlertUtil.alertMsg(CHECK.format.mac);
                        this.bu_sa = false;
                        return false;
                    }
                    json.mac = json.mac.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                }
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.bu_sa = false;
                        if (data.success == true) {
                            SysUtil.rebootDevice(RENOOTTYPE.CONFIG_CHANGE, PROMPT.tips.rebootMessage);
                        }
                    }
                })

            }
        }
    })
    Page.postJSON({
        json: {
            cmd: RequestCmd.WAN_MAC_GET
        },
        success: function (datas) {
            vm.mac = datas.data.mac;
            vm.picked = datas.data.model;
        }
    });

});