$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            value: "",
            reset: DOC.btn.reset,
            disabled: false,
            qrcord: DOC.lbl.qrcord + DOC.colon,
            officialQrcord: DOC.lbl.officialQrcord,
            resetESIM: DOC.lbl.resetESIM + DOC.colon,
            downESIM: DOC.lbl.downESIM + DOC.colon,
            esimState: DOC.lbl.esimState + DOC.colon,
            btn_save: DOC.btn.save,
            currentState: "-",
            showIccid: false,
            iccidValue: "",
            download: DOC.lbl.download,
            esimTitle: DOC.lbl.esimTitle,
            help: [DOC.lbl.esimTitle1, DOC.lbl.esimTitle2, DOC.lbl.esimTitle3, DOC.lbl.esimTitle4],
            qrcode:'',
            esimUrl: ""
        },
        methods: {
            resetClick: function () {
                if ($(".fy-alert-shadow").length > 0) {
                    return false;
                }
                fyConfirmMsg(DOC.lbl.resetESIMTips1, function () {
                    fyConfirmMsg(DOC.lbl.resetESIMTips2, function () {
                        fyAlertMsgLoading();
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.RESET_ESIM_INFO
                            },
                            success: function (data) {
                                if (data.flag == "1") {
                                    switch (data.isSuccess) {
                                        case "0":
                                            fyAlertMsgSuccess();
                                            vm.makeCode();
                                            break;
                                        case "-1":
                                            fyAlertMsgFail("ESIM ICCID Error: 1200");
                                            break;
                                        case "-2":
                                            fyAlertMsgFail("ESIM ICCID Error: 1201");
                                            break;
                                        case "-3":
                                        case "-4":
                                            fyAlertMsgFail("ESIM ICCID Error: 120C");
                                            break;
                                        case "1":
                                            fyAlertMsgFail("ESIM ICCID: ICCID OrAid Not Found");
                                            break;
                                        case "2":
                                            fyAlertMsgFail("ESIM: Profile Not In Disabled State");
                                            break;
                                        case "3":
                                            fyAlertMsgFail("ESIM ICCID: Disallowed By Policy");
                                            break;
                                        case "4":
                                            fyAlertMsgFail("ESIM: Wrong Profile Reenabling");
                                            break;
                                        case "5":
                                            fyAlertMsgFail("ESIM ICCID: Cat Busy");
                                            break;
                                        case "127":
                                            fyAlertMsgFail("ESIM ICCID: Undefined Error");
                                            break;
                                        default:
                                            fyAlertMsgFail("ESIM Error: Unknow");
                                            break;
                                    }
                                } else {
                                    fyAlertMsgFail();
                                }
                            }
                        });
                    });
                })
            },
            downloadClick: function () {
                if (this.currentState == DOC.lbl.esimStateNo) {
                    fyAlertMsgLoadText(DOC.lbl.uploadEsim);
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.DOWNLOAD_ESIM_INFO
                        },
                        success: function (data) {
                            if (data.flag == "1") {
                                switch (data.isSuccess) {
                                    case "0":
                                        fyAlertMsgSuccess();
                                        setTimeout(vm.makeCode,10000);
                                        break;
                                    case "-1":
                                        fyAlertMsgFail("ESIM Download Error: 1200");
                                        break;
                                    case "-2":
                                        fyAlertMsgFail("ESIM Download Error: 1201");
                                        break;
                                    case "-3":
                                        fyAlertMsgFail("ESIM Download Error: 1202");
                                        break;
                                    case "-4":
                                        fyAlertMsgFail("ESIM Download Error: 1203");
                                        break;
                                    case "-5":
                                        fyAlertMsgFail("ESIM Download Error: 1204");
                                        break;
                                    case "-6":
                                        fyAlertMsgFail("ESIM Download Error: 120A");
                                        break;
                                    case "-15":
                                        fyAlertMsgFail("ESIM Download Error: Net Error");
                                        break;
                                    default:
                                        fyAlertMsgFail("ESIM Download Error: Unknow");
                                        break;
                                }
                            } else {
                                fyAlertMsgFail();
                            }

                        }
                    });
                } else {
                    fyAlertMsgWarn(DOC.sys.isActivatedEsim);
                }
            },
            makeCode: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.GET_ESIM_INFO
                    },
                    success: function (data) {
                        var textInfo = "esim://?e="
                        if (!!data.e) {
                            textInfo = textInfo + data.e;
                        } else if (!!data.iccid) {
                            textInfo = textInfo + data.iccid;
                        }
                        textInfo = textInfo + "&i=" + data.imei + "&m=" + data.m + "&d=" + data.d;
                        vm.qrcode.makeCode(textInfo);
                        if(!data.e){
                            vm.currentState = DOC.lbl.esimEmpty;
                            vm.showIccid = false;
                        } else{
                            if( data.esim_status == "1" ){
                                vm.currentState = DOC.lbl.esimStateYes;
                                vm.showIccid = true;
                                vm.iccidValue = !!data.iccid ? data.iccid.substr(0,data.iccid.length-1) : "-";
                            } else {
                                vm.currentState = DOC.lbl.esimStateNo;
                                vm.showIccid = false;
                            }
                        }
                    }
                });
            },
            SaveUrl: function(){
                if(CheckUtil.isEmpty(this.esimUrl)) {
                    AlertUtil.alertMsg(CHECK.required.url);
                    return false;
                }
                var json = {};
                json.esimUrl = this.esimUrl;
                json.cmd = RequestCmd.ESIM_URL_SETTING;
                json.method = JSONMethod.POST;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.qrcode = new QRCode(document.getElementById(
                "qrcode"), {
                width: 100,
                height: 100,
                render: "table",
                typeNumber: -1,
                correctLevel: 0
            });
            if(Page.level == "1"){
                Page.postJSON({
                    json: { cmd: RequestCmd.ESIM_URL_SETTING },
                    success: function (data) {
                        vm.esimUrl = data.esimUrl;
                    }
                })
            }
            this.makeCode();
        }
    })
});