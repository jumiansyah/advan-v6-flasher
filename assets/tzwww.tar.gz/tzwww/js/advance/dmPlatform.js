$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            dmSwitch: DOC.tr069.dmSwitch,
            colon: DOC.colon,
            disabled: false,
            btn_save: DOC.btn.save,
            dmEnabled: false,
            enable: DOC.status.enable,
            disable: DOC.status.disable
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DM_SETTING,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.dmEnabled = data.dm == "1" ? true : false;
                    }
                })
            },
            clickBtnSave: function () {
                this.disabled = true;
                fyAlertMsgLoading();
                var json = {};
                json.dm = vm.dmEnabled ? "1" : "0";

                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.DM_SETTING;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            }
        },
        mounted: function () {
            this.getData()
        }
    });
});