$(document).ready(function () {
    var rules = {
            lte_lock_freq: {
                required: true,
                range: [0, 16777215],
                digits: true
            },
            lte_lock_pci: {
                lock_pci_4g: true
            }
        },
        messages = {
            lte_lock_freq: {
                required: CHECK.required.freqPoint,
                range: CHECK.required.freqPointMax,
                digits: CHECK.format.digits
            },
            lte_lock_pci: {
               lock_pci_4g: CHECK.required.PhyCellIdMax4g
            }
        };
    var rules2 = {
            nr_lock_freq: {
                required: true,
                range: [0, 16777215],
                digits: true
            },
            nr_lock_pci: {
                lock_pci_5g: true
            }
        },
        messages2 = {
            nr_lock_freq: {
                required: CHECK.required.freqPoint,
                range: CHECK.required.freqPointMax,
                digits: CHECK.format.digits
            },
            nr_lock_pci: {
                lock_pci_5g: CHECK.required.PhyCellIdMax5g
            }
        };
    var fm = ["lockPhyCellForm", "lockPhyCellFormId", "lockPhyCellTable"];
    var fm2 = ["lockPhyCellForm5g", "lockPhyCellFormId5G", "lockPhyCellTable5g"];
    var radioValue = [{
        "name": DOC.lbl.unlock,
        "value": "0"
    }, {
        "name": DOC.lbl.lockSpecific,
        "value": "1"
    }];
    var vm = new Vue({
        el: "#child_container",
        data: {
            currentPoint: "",
            txtFreqPointValue: "",
            txtPhyCellIdValue: "",
            currentPhyCellId: "",
            spanLockedStatus: "",
            checkedNames: "",
            currentPoint5g: "",
            txtFreqPointValue5g: "",
            txtPhyCellIdValue5g: "",
            currentPhyCellId5g: "",
            spanLockedStatus5g: "",
            checkedNames5g: "",
            lockedStatus4g: DOC.lbl.lockedStatus4g,
            lockedStatus5g: DOC.lbl.lockedStatus5g,
            colon: DOC.colon,
            lockTypeList: radioValue,
            lockTypeList5g: radioValue,
            lockedStatus: DOC.lbl.lockedStatus,
            lockTh: DOC.lbl.lockTh,
            freqPoint: DOC.lbl.freqPoint,
            phyCellId: DOC.lbl.phyCellId,
            lockFreqPointTip: DOC.lbl.lockFreqPointTip,
            lockFreqPointTipRange: DOC.lbl.lockFreqPointTipRange,
            lockPhyCellIdTip: DOC.lbl.lockPhyCellIdTip,
            lockPhyCellIdTipRange: DOC.lbl.lockPhyCellIdTipRange,
            lockPhyCellIdTipRange5g: DOC.lbl.lockPhyCellIdTipRange5g,
            btnSave: DOC.lbl.btnSave,
            lock5GFreqPoint: DOC.lbl.lock5GFreqPoint,
            getCurrent: DOC.lbl.getCurrent,
        },
        computed: {
            disabled1: function () {
                return !!this.currentPoint ? false : true;
            },
            disabled2: function () {
                return !!this.currentPhyCellId ? false : true;
            },
            disabled3: function () {
                return !!this.currentPoint5g ? false : true;
            },
            disabled4: function () {
                return !!this.currentPhyCellId5g ? false : true;
            },
            lockShow: function () {
                return this.checkedNames == "1" ? true : false
            },
            lockShow5g: function () {
                return this.checkedNames5g == "1" ? true : false
            }
        },
        methods: {
            setData: function () {
                var $form = $('#lockPhyCellForm');
                var json = JSON.parmsToJSON($form);
                if (json.lte_lock_sw == '1') {
                    if (!CheckUtil.checkForm($form, rules, messages)) {
                        return false;
                    }
                } else if (json.lte_lock_sw == '0') {
                    json.lte_lock_freq = '';
                    json.lte_lock_pci = '';
                };
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.subcmd = 0;
                json.cmd = RequestCmd.LOCK_PHY_CELL;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.getInfo();
                    }
                });
            },
            setData5g: function () {
                var $form = $('#lockPhyCellForm5g');
                var json = JSON.parmsToJSON($form);
                if (json.nr_lock_sw == '1') {
                    if (!CheckUtil.checkForm($form, rules2, messages2)) {
                        return false;
                    }
                } else if (json.nr_lock_sw == '0') {
                    json.nr_lock_freq = '';
                    json.nr_lock_pci = '';
                };
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.subcmd = 1;
                json.cmd = RequestCmd.LOCK_PHY_CELL;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.getInfo();
                    }
                });
            },
            getInfo: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LOCK_PHY_CELL
                    },
                    success: function (datas) {
                        vm.spanLockedStatus = datas.lock_4g_flag == "1" ? DOC.status.locked : datas.lock_4g_flag == "-1" ? DOC.status.lockedFail : DOC.status.unlocked;
                        vm.checkedNames = datas.lte_lock_sw == "1" ? "1" : "0";
                        vm.currentPoint = !!datas.FREQ ? datas.FREQ : "";
                        vm.currentPhyCellId = !!datas.PCI ? datas.PCI : "";
                        vm.txtFreqPointValue = datas.lte_lock_freq ? datas.lte_lock_freq : "";
                        vm.txtPhyCellIdValue = datas.lte_lock_pci ? datas.lte_lock_pci : "";

                        vm.spanLockedStatus5g = datas.lock_5g_flag == "1" ? DOC.status.locked : datas.lock_5g_flag == "-1" ? DOC.status.lockedFail : DOC.status.unlocked;
                        vm.checkedNames5g = datas.nr_lock_sw == "1" ? "1" : "0";
                        vm.currentPoint5g = !!datas.FREQ_5G ? datas.FREQ_5G : "";
                        vm.currentPhyCellId5g = !!datas.PCI_5G ? datas.PCI_5G : "";
                        vm.txtFreqPointValue5g = datas.nr_lock_freq ? datas.nr_lock_freq : "";
                        vm.txtPhyCellIdValue5g = datas.nr_lock_pci ? datas.nr_lock_pci : "";
                    }
                });
            },
            setData1: function () {
                this.txtFreqPointValue = this.currentPoint;
            },
            setData2: function () {
                this.txtPhyCellIdValue = this.currentPhyCellId;
            },
            setData3: function () {
                this.txtFreqPointValue5g = this.currentPoint5g;
            },
            setData4: function () {
                this.txtPhyCellIdValue5g = this.currentPhyCellId5g;
            }
        },
        mounted: function () {
            Page.createForm(fm);
            Page.createForm(fm2);
            this.getInfo();
        }
    });
});