$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var $mask = $('#mask');
    $mask.hide();
    var vm = new Vue({
        el: "#child_container",
        data: {
            plmnList: "",
            array1: [],
            array2: [],
            array3: [],
            array4: [],
            array5: [],
            array6: [],
            array7: [],
            plmnnoAvailable: DOC.lbl.plmnnoAvailable,
            plmnavailable: DOC.lbl.plmnavailable,
            plmncurrentPlmn: DOC.lbl.plmncurrentPlmn,
            plmnscanBut: DOC.lbl.plmnscanBut,
            plmnscan: DOC.lbl.plmnscan,
            plmnscanRes: DOC.lbl.plmnscanRes,
            plmnnumber: DOC.lbl.plmnnumber,
            plmnStatus: DOC.lbl.plmnStatus,
            plmnoperator: DOC.lbl.plmnoperator,
            plmnname: DOC.lbl.plmnname,
            plmnnetwork: DOC.lbl.plmnnetwork,
            plmnselected: DOC.lbl.plmnselected,
            edit_box: false,
            close: DOC.btn.close,
            edit_box2: false,
            plmnReinject: DOC.lbl.plmnReinject,
            plmnRetSuccuss: DOC.lbl.plmnRetSuccuss,
            plmnRetFail: DOC.lbl.plmnRetFail,
            plmnSearch: DOC.lbl.plmnSearch,
            plmnSearch2: DOC.lbl.plmnSearch2,
            plmnRegisterNetwork: DOC.lbl.plmnRegisterNetwork
        },
        methods: {
            sccanPlmn: function () {
                if (sessionStorage["sim_info"] == 0) {
                    fyAlertMsgWarn(PROMPT.tips.simStatus);
                    return false;
                }
                if (!confirm(DOC.lbl.plmnSearch)) {
                    return false;
                }
                vm.array1 = [];
                vm.array2 = [];
                vm.array3 = [];
                vm.array4 = [];
                vm.array5 = [];
                vm.array6 = [];
                vm.edit_box = true;
                $mask.show();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SCCAN_PLMN,
                        sccan_plmn: "1",
                        method: JSONMethod.POST
                    },
                    success: function (datas) {
                        vm.edit_box = false;
                        $mask.hide();
                        if (datas.sccan_plmn_list) {
                            location.reload();
                        } else {
                            vm.$nextTick(function () {
                                SysUtil.processMsg(errorCodeInfo(parseInt(datas.message)));
                            });
                        }
                    }
                });
            },
            sccanPlmn2: function () {
                vm.array1 = [];
                vm.array2 = [];
                vm.array3 = [];
                vm.array4 = [];
                vm.array5 = [];
                vm.array6 = [];

                vm.edit_box = true;
                $mask.show();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SCCAN_PLMN,
                        sccan_plmn: "1",
                        method: JSONMethod.POST
                    },
                    success: function (datas) {
                        vm.edit_box = false;
                        $mask.hide();
                        if (datas.sccan_plmn_list) {
                            location.reload();
                        } else {
                            vm.$nextTick(function () {
                                SysUtil.processMsg(errorCodeInfo(parseInt(datas.message)));
                            });
                        }
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SCCAN_PLMN,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        if (datas.sccan_plmn_list) {
                            vm.array1 = [];
                            vm.array2 = [];
                            vm.array3 = [];
                            vm.array4 = [];
                            vm.array5 = [];
                            vm.array6 = [];
                            vm.plmnList = datas.sccan_plmn_list;
                            var arr = vm.plmnList.split("|");
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i].split(",")[0] == "0" || arr[i].split(",")[0] == "3") {
                                    vm.array1.push(vm.plmnnoAvailable);
                                } else if (arr[i].split(",")[0] == "1") {
                                    vm.array1.push(vm.plmnavailable);
                                } else if (arr[i].split(",")[0] == "2") {
                                    vm.array1.push(vm.plmncurrentPlmn);
                                }
                                vm.array7.push(arr[i].split(",")[0]);
                                vm.array2.push(arr[i].split(",")[1]);
                                vm.array3.push(arr[i].split(",")[2]);
                                vm.array4.push(arr[i].split(",")[3]);
                                vm.array6.push(arr[i].split(",")[4])
                                if(parseInt(arr[i].split(",")[4], 10) < 2){
                                    vm.array5.push("2G")
                                }
                                else if (parseInt(arr[i].split(",")[4], 10) >= 2 && parseInt(arr[i].split(",")[4], 10) < 4) {
                                    vm.array5.push("3G")
                                } else if (parseInt(arr[i].split(",")[4], 10) >= 4 && parseInt(arr[i].split(",")[4], 10) < 10) {
                                    vm.array5.push("4G")
                                } else if (parseInt(arr[i].split(",")[4], 10) >= 10) {
                                    vm.array5.push("5G")
                                }
                            }
                        }
                    }
                });
            },
            disabledFun: function (index) {
                var index = parseInt(index, 10);
                if (vm.array7[index] == "0" || vm.array7[index] == "3") {
                    return true;
                } else {
                    return false;
                }
            },
            selectPlmn: function (event) {
                if (!confirm(DOC.lbl.plmnReinject)) {
                    return false;
                }
                this.edit_box2 = true;
                $mask.show();
                var index = parseInt(event, 10)
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SCCAN_PLMN,
                        plmn_select_cmd: "1",
                        plmn: vm.array4[index],
                        act: vm.array6[index],
                        method: JSONMethod.POST
                    },
                    success: function (datas) {
                        vm.edit_box2 = false;
                        $mask.hide();
                        if (datas.message == "0") {
                            vm.$nextTick(function () {
                                AlertUtil.alertMsg(DOC.lbl.plmnRetSuccuss);
                                vm.sccanPlmn2();
                            });
                        } else {
                            vm.$nextTick(function () {
                                SysUtil.processMsg(DOC.lbl.plmnRetFail + ' , ' + errorCodeInfo(parseInt(datas.message)));
                            });
                        }
                    }
                })
            },
            checkedFun: function (index) {
                var index = parseInt(index, 10)
                if (vm.array7[index] == "2") {
                    return true;
                } else {
                    return false;
                }

            }
        },
        mounted: function () {
            this.getData()
        }
    })
});