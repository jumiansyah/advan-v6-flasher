$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            save: DOC.btn.save,
            band3gSwitch: DOC.net.band3gSwitch,
            band4gSwitch: DOC.net.band4gSwitch,
            band4g: DOC.net.band4g,
            band3g: DOC.net.band3g,
            colon: DOC.colon,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            band_info: "",
            supportAll3gArrayList: [],
            lockBandAll3gArrayList: [],
            band3gRadio: false,
            supportAll4gArrayList: [],
            lockBandAll4gArrayList: [],
            band4gRadio: "",
            helps: [{
                title: DOC.net.band5g,
                item: DOC.net.band5gSupport
            }]
        },
        methods: {
            btnSave: function () {
                var json = {};
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.LOCK_BAND;
                json.band3gRadio = this.band3gRadio ? "1" : "0";
                json.band4gRadio = this.band4gRadio ? "1" : "0";
                //16进制去掉前面多余的0
                json.lock3gBand = this.bin_to_hex(this.lockBandAll3gArrayList.join("").split("").reverse().join("").replace(/\b(0+)/gi, ""));
                json.lock4gBand = this.bin_to_hex(this.lockBandAll4gArrayList.join("").split("").reverse().join("").replace(/\b(0+)/gi, ""));
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            fyAlertMsgSuccess();
                            vm.getDate();
                        } else {
                            fyAlertMsgFail();
                            vm.getDate();
                        }
                    }
                });
            },
            getDate: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LOCK_BAND,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        var supportAll3g, supportAll4g;
                        var lockBandAll3g, lockBandAll4g;
                        vm.band3gRadio = data.band_3g_switch == "1" ? true : false;
                        vm.band4gRadio = data.band_4g_switch == "1" ? true : false;
                        if (data.all_band_3g) {
                            supportAll3g = Page.parseHex(data.all_band_3g);
                            lockBandAll3g = Page.parseHex(data.band_3g_mask);
                            vm.processingData(supportAll3g, lockBandAll3g, "3g");
                        }

                        if (data.all_band_4g) {
                            supportAll4g = Page.parseHex(data.all_band_4g);
                            lockBandAll4g = Page.parseHex(data.band_4g_mask);
                            vm.processingData(supportAll4g, lockBandAll4g, "4g");
                        }


                    }
                });

            },
            processingData: function (supportAll, lockBandAll, networkMode) {
                var supportAllArray, lockBandAllArray;
                var bandList = this.createBandsBit(128);
                if (supportAll && lockBandAll) {
                    if (supportAll.length < 2) {
                        supportAllArray = supportAll[0].split('').reverse();
                    } else {
                        supportAllArray = supportAll.join('').split('').reverse();
                    }

                    if (lockBandAll.length < 2) {
                        lockBandAllArray = lockBandAll[0].split('').reverse();
                    } else {
                        lockBandAllArray = lockBandAll.join('').split('').reverse();
                    }
                    if (networkMode == "3g") {
                        this.supportAll3gArrayList = supportAllArray;
                        for (var i = 0; i < lockBandAllArray.length; i++) {
                            if (lockBandAllArray[i] == "1") {
                                bandList.splice(i, 1, "1");
                            }
                        }
                        this.lockBandAll3gArrayList = bandList;
                    } else if (networkMode == "4g") {
                        this.supportAll4gArrayList = supportAllArray;
                        for (var i = 0; i < lockBandAllArray.length; i++) {
                            if (lockBandAllArray[i] == "1") {
                                bandList.splice(i, 1, "1");
                            }
                        }
                        this.lockBandAll4gArrayList = bandList;

                    }
                }
            },
            bin_to_hex: function (str) { //2进制转16进制
                var hex_array = [{
                        key: "0",
                        val: "0000"
                    }, {
                        key: "1",
                        val: "0001"
                    }, {
                        key: "2",
                        val: "0010"
                    }, {
                        key: "3",
                        val: "0011"
                    }, {
                        key: "4",
                        val: "0100"
                    }, {
                        key: "5",
                        val: "0101"
                    }, {
                        key: "6",
                        val: "0110"
                    }, {
                        key: "7",
                        val: "0111"
                    },
                    {
                        key: "8",
                        val: "1000"
                    }, {
                        key: "9",
                        val: "1001"
                    }, {
                        key: 'a',
                        val: "1010"
                    }, {
                        key: 'b',
                        val: "1011"
                    }, {
                        key: 'c',
                        val: "1100"
                    }, {
                        key: 'd',
                        val: "1101"
                    }, {
                        key: 'e',
                        val: "1110"
                    }, {
                        key: 'f',
                        val: "1111"
                    }
                ];
                var value = ''
                var list = [];
                if (str.length % 4 !== 0) {
                    var a = "0000"
                    var b = a.substring(0, 4 - str.length % 4)
                    str = b.concat(str)
                }
                while (str.length > 4) {
                    list.push(str.substring(0, 4))
                    str = str.substring(4);
                }
                list.push(str)
                for (var i = 0; i < list.length; i++) {
                    for (var j = 0; j < hex_array.length; j++) {
                        if (list[i] == hex_array[j].val) {
                            value = value.concat(hex_array[j].key)
                        }
                    }
                }
                return value
            },
            clickCheckbox: function (index) { //更新5G锁BAND
                if (this.lockBandAll3gArrayList[index] == "1") {
                    this.lockBandAll3gArrayList.splice(index, 1, "0");
                } else {
                    this.lockBandAll3gArrayList.splice(index, 1, "1");
                }
            },
            clickCheckbox4g: function (index) { //更新4G锁BAND
                if (this.lockBandAll4gArrayList[index] == "1") {
                    this.lockBandAll4gArrayList.splice(index, 1, "0");
                } else {
                    this.lockBandAll4gArrayList.splice(index, 1, "1");
                }
            },
            createBandsBit: function (bitNum) {
                var bandsBit = "";
                for (var i = 0; i < bitNum; i++) {
                    bandsBit += "0";
                }

                return bandsBit.split("");
            }
        }
    });
    vm.getDate();
});