$(document).ready(function () {

    var items = [];
    var id = "iptv_CONFIG";

    items.push({ title: MENU.setting.iptv, url: 'html/advance/iptv.html' })

    secondMenuClick(items,id);
});

