$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            ipPassFlag: false,
            colon: DOC.colon,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            ipPassSwitch: TAB.sys.ipPassSwitch,
            save: DOC.btn.save,
            flag: "",
            help:[TAB.sys.ipPassSwitch,TAB.sys.openIpPass]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_PASSTHROUGH
                    },
                    success: function (data) {
                        vm.ipPassFlag = data.ipPassSwitch == "1" ? true : false;
                        vm.flag = vm.ipPassFlag ? "1" : "0";
                    }

                });
            },
            btnSave: function () {
                if (this.flag === this.ipPassFlag) {
                    AlertUtil.alertMsg(TAB.sys.notChange);
                    return false;
                }
                if ($(".fy-alert-shadow").length > 0) {
                    return false;
                }
                var json = {};
                fyAlertMsgLoading();
                json.ipPassSwitch = this.ipPassFlag ? "1" : "0";
                json.cmd = RequestCmd.IP_PASSTHROUGH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.flag == "0") {
                            vm.flag = json.ipPassSwitch;
                            fyAlertMsgSuccess(TAB.sys.activeIpPass);
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });

            }
        },
        mounted: function () {
            this.getData();
        }
    })

});