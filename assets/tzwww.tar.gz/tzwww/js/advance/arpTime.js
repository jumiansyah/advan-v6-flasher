$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data:{
            arpTime:TAB.route.arpTime,
            save:DOC.btn.save,
            digits:CHECK.format.digits,
            time:30,
            rule:true,
        },
        methods:{
            setData:function(){
                var reg = /^[+]{0,1}(\d+)$/;
                var isInt = reg.test(this.time);
                if(!isInt){
                    alert(this.digits);
                    return;
                }
                if(this.time<5||this.time>86400){
                    this.rule = false;
                    return;
                }
                this.rule = true;
                fyAlertMsgLoading();
                var json ={};
                json.value = vm.time;
                json.cmd = RequestCmd.SET_ARP_AGING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.success == true){
                            fyAlertMsgSuccess();
                            vm.getData();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            getData:function(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SET_ARP_AGING,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.time = datas.buffer;
                    }
                });
            }
        },
        mounted:function(){
            this.getData()
        }
    })
})