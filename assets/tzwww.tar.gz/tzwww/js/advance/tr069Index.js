$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "TR069_SETTING";
    var items = [];

    items.push({ title: tabs.tr069, url: 'html/advance/tr069.html' });

    secondMenuClick(items,id);
});