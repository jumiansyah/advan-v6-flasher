$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm2(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            iptvSettingsSwitch: DOC.iptvSettings.iptvSettingsSwitch,
            colon: DOC.colon,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            apn: DOC.iptvSettings.apn,
            apnOption: [{
                    name: DOC.iptvSettings.mainApn,
                    value: "main_apn"
                },
                {
                    name: DOC.iptvSettings.apn1,
                    value: "apn1"
                },
                {
                    name: DOC.iptvSettings.apn2,
                    value: "apn2"
                },
                {
                    name: DOC.iptvSettings.apn3,
                    value: "apn3"
                },
            ],
            save: DOC.btn.save,
            helper_desc: [{
                    name: DOC.iptvSettingsHelper.name0,
                    value: DOC.iptvSettingsHelper.item0
                },
                {
                    name: DOC.iptvSettingsHelper.name1,
                    value: DOC.iptvSettingsHelper.item1
                }
            ],
            btnDis: false,
            iptvSwitch: '',
            iptvApn: ''
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.GET_IPTV_SETTINGS
                    },
                    success: function (datas) {
                        var datas = (!!datas && !!datas.data) ? datas.data : {};
                        vm.iptvSwitch = datas.iptv_switch == "1" ? "1" : "0";
                        vm.iptvApn = datas.iptv_apn || "main_apn";
                    }
                });
            },
            btnSave: function () {
                this.btnDis = true;
                var $form = $('#childForm');
                var json = JSON.parmsToJSON($form);
                json.cmd = RequestCmd.SET_IPTV_SETTINGS;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (datas) {
                        vm.btnDis = false;
                        SysUtil.rebootDevice(RENOOTTYPE.CONFIG_CHANGE, PROMPT.tips.rebootMessage);

                    }
                });
            }
        }
    });
    vm.getData();
    Page.setStripeTable();
});