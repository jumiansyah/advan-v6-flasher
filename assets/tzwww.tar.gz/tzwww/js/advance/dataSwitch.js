$(document).ready(function () {
    var fm = ["networkForm", "child_container", "networkFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
           
        },
        methods: {
           getData:function(){
                  Page.postJSON({
                    json: { 
                        cmd: RequestCmd.DATA_SWITCH,
                        method:JSONMethod.GET},
                    success: function (data) {
                       
                    }
                })
           }
        },
        mounted:function(){
            this.getData();
        }
    });
    
});