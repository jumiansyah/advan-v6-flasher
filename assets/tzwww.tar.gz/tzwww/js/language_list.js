var all_supported_language_info={
	"cn":{
		"bit_offset":"1"
		,"language_id":"LANG.cn"
	}
	,"en":{
		"bit_offset":"2"
		,"language_id":"LANG.en"
	},
	"th":{
		"bit_offset":"3"
		,"language_id":"LANG.th"
  },
  "in":{
    "bit_offset":"4"
		,"language_id":"LANG.in"
  }
};
