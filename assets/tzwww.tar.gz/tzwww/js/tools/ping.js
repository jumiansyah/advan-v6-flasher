$(document).ready(function () {

    var fm = ["childForm", "child_template", "childTable"];
    var rules = {
            txtUrl: {
                url_filter_check: true
            }
        },
        messages = {
            txtUrl: {
                url_filter_check: CHECK.tip.urlOrIp
            }
        };
    Page.createForm(fm);
    var SUB_CMD = 0;
    var $txtPingTimes = $('#txtPingTimes');
    var $chkPingTimes = $('#chkPingTimes');
    var $btnStart = $('#btnStart');
    var $btnStop = $('#btnStop');
    var $btnClear = $('#btnClear');
    var $txtPingResult = $('#txtPingResult');
    var vm = new Vue({
        el: "#child_container",
        data: {
            pingTimesText: DOC.lbl.pingTimes,
            colon: DOC.colon,
            cycle: DOC.lbl.cycle,
            urlOrIp: DOC.lbl.urlOrIp,
            start: DOC.btn.start,
            stop: DOC.btn.stop,
            clear: DOC.btn.clear,
            txtPingTimesBtn: false,
            chkPingTimesCheck: false,
            txtPingTimesValue: 20,
            pingTimes: 20,
            receivedLength: 0,
            startIndex: 0,
            currentId: Page.currentId,
            count: 0,
            startDisable: false,
            stopDisable: true,
            txtPingResultValue: "",
            url: '',
            exit: false,
            timer: ''
        },
        methods: {
            startClick: function () {
                vm.exit = false
                vm.startIndex = 0;
                vm.pingTimes = vm.txtPingTimesValue;
                if (vm.txtPingTimesBtn) {
                    vm.pingTimes = -1;
                } else {
                    var reg =  /^-?[1-9]\d*$/;
                    if (!reg.test(vm.pingTimes)) {
                        AlertUtil.alertMsg(CHECK.format.pingTimes);
                        return false;
                    }
                    if (vm.pingTimes < 1) {
                        AlertUtil.alertMsg(CHECK.min.pingTimes);
                        return false;
                    }
                }

                // var url = $('#txtUrl').val().trim();
                var url = this.url.trim()
                if (url == "") {
                    AlertUtil.alertMsg(CHECK.required.urlOrIp);
                    return false;
                }
                var $form = $('#childForm');
                var json = JSON.parmsToJSON($form);
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    return false;
                }
                vm.startDisable = true;
                vm.stopDisable = false;
                vm.sendCmd(vm.pingTimes, url);
                vm.txtPingResultValue = "";
                vm.timer = setTimeout(vm.loop, 1000);
            },
            // 返回Ping的内容
            getFileData: function () {
                Page.getFileData('/tmp/tzwww/pingrt', RequestCmd.NETWORK_TOOLS, function (data) {
                    vm.receivedLength = data.length;
                    if (vm.startIndex < vm.receivedLength) {
                        var result = data.substring(vm.startIndex) || "...";
                        if (result.startsWith("PING")) {
                            vm.txtPingResultValue = result;
                        } else if (result.startsWith("ping")) {
                            vm.txtPingResultValue = result;
                            vm.stopClick();
                        } else {
                            vm.txtPingResultValue = "...";
                        }
                    }
                    // vm.scrollToBottom()
                });
            },
            chkPingTimesClick: function (ev) {
                if (ev.target.checked) {
                    this.txtPingTimesBtn = true;
                } else {
                    this.txtPingTimesBtn = false;
                }
            },
            // 设置Ping的次数
            sendCmd: function (pingTimes, url) {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_TOOLS,
                        method: JSONMethod.POST,
                        subcmd: SUB_CMD,
                        pingTimes: pingTimes,
                        url: url || ''
                    },
                    success: function (data) {
                        if(!!url){
                            vm.getFileData();
                        }
                    }
                });
            },
            stopClick: function () {
                vm.startDisable = false;
                vm.stopDisable = true;
                vm.sendCmd(0);
                vm.exit = true
                vm.count = 0
            },

            loop: function () {
                clearTimeout(vm.timer)
                if (vm.currentId != Page.currentId || vm.count > 3600 || (vm.count > vm.pingTimes && !vm.txtPingTimesBtn)) {
                    vm.count = 0;
                    vm.startDisable = false;
                    vm.stopDisable = true;
                    vm.sendCmd(0)
                    return;
                }
                if(vm.exit){
                    vm.count = 0 
                    vm.getFileData();
                    vm.sendCmd(0)
                }else{
                    vm.getFileData();
                    $("#txtPingResult")[0].scrollTop = $("#txtPingResult")[0].scrollHeight;
                    vm.count++;
                    vm.timer = setTimeout(vm.loop, 1000);
                }
            },
            btnClearClick: function () {
                vm.startIndex = vm.receivedLength;
                vm.txtPingResultValue = "";
            },
        }
    })
});