$(document).ready(function() {
    var SUB_CMD = 2;
    var fm = ["childForm", "child_template", "childTable"];
    var rules = {
        txtUrl: { url_filter_check: true }
    }, messages = {
        txtUrl: { url_filter_check: CHECK.tip.urlOrIp }
    };
    Page.createForm(fm);
    var stopped = true;
    var oldData = '';
    var isFirst = true;
    var currentId = Page.currentId;
    var count = 0;
    var vm = new Vue({
        el:"#child_container",
        data:{
            urlOrIp:DOC.lbl.urlOrIp,
            colon:DOC.colon,
            portText:DOC.net.port,
            start:DOC.btn.start,
            stop:DOC.btn.stop,
            txtUrlValue:"",
            txtPortValue:"",
            txtResultValue:"",
            port:"",
            btnStartDis:false,
            btnStopDis:true
        },
        methods:{
            getFileData:function(){
                Page.getFileData('/tmp/tzwww/tracepathrt', RequestCmd.NETWORK_TOOLS, function(data) {
                    if (data == oldData) {
                        if (!stopped) {
                            //$txtResult.val(PROMPT.status.processing);
                        }
                    } else {
                        if(data.startsWith("traceroute")){
                            oldData = data;
                            vm.txtResultValue = data;
                        }
                        if (data.indexOf('Resume') > 0) {
                            stopped = true;
                        }
                    }
                });
            },
            btnStartClick:function(){
                 vm.port = parseInt(vm.txtPortValue, 10);
                if (isNaN(vm.port)) {
                    vm.port = -1;
                } else if (vm.port < 1 || vm.port > 65535) {
                    AlertUtil.alertMsg(CHECK.range.port);
                    return false;
                }
                
                var url = vm.txtUrlValue;
                if (url == "") {
                    AlertUtil.alertMsg(CHECK.required.urlOrIp);
                    return false;
                }
                var $form = $('#childForm');
                var json = JSON.parmsToJSON($form);
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    return false;
                }
                vm.btnStartDis = true;
                vm.btnStopDis = false;
                vm.sendCmd(false, vm.port, url);
                vm.txtResultValue = "";
                setTimeout(vm.loop, 1000);
            },
            btnStopClick:function(){
                vm.btnStartDis = false;
                vm.btnStopDis = true;
                vm.sendCmd(true);
            },
            sendCmd:function(stopped, port, url){
                if(typeof(port) == 'undefined') {
                    port = -1;
                }
                Page.postJSON({
                    json: { 
                        cmd: RequestCmd.NETWORK_TOOLS, 
                        method: JSONMethod.POST,
                        subcmd: SUB_CMD,
                        stopped: stopped ? "1" : "0",
                        port: port,
                        url: url || ''
                    },
                    success: function(data) {
                        vm.getFileData();
                    }
                });
            },
            getStatus:function(){
                Page.postJSON({
                json: { 
                    cmd: RequestCmd.NETWORK_TOOLS, 
                    method: JSONMethod.GET,
                    subcmd: SUB_CMD
                },
                success: function(data) {
                    if (isFirst) {
                        isFirst = false;
                        return;
                    }
                    var isRunning = (parseInt(data.message, 10) == 1);
                    if (!isRunning) {
                        vm.btnStopClick();
                    }
                }
            });
            },
            loop:function(){
                if (currentId != Page.currentId || count > 3600) {
                    count = 0;
                    vm.btnStopClick();
                    return;
                }
                vm.getFileData();
                vm.getStatus();

                count++;
                setTimeout(vm.loop, 5000);
            }
        }
    })
});
