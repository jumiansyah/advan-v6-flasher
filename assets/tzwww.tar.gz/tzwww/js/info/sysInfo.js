/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-01-25 11:00:58
 * @,@LastEditTime: ,: 2021-06-08 10:59:23
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\js\info\sysInfo.js
 */
var loading = "-";
var values_sysInfo = new Array(21);

// === PRIVACY MASKING SYSTEM ===
var _sensitiveData = {};
var _sensitiveVisible = {};

function maskValue(val) {
    if (!val || val === '-' || val === loading) return val;
    var s = String(val);
    if (s.length < 4) return '••••';
    return s.substring(0, 2) + s.substring(2).replace(/[0-9a-fA-F]/g, '•');
}

function toggleSensitive(key) {
    _sensitiveVisible[key] = !_sensitiveVisible[key];
    var displayed = _sensitiveVisible[key] ? _sensitiveData[key] : maskValue(_sensitiveData[key]);
    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, key, displayed);
    setTimeout(function() { injectShowButtons(); }, 50);
}

function injectShowButtons() {
    var allTd = document.querySelectorAll('#net_info td');
    var sensitiveKeys = Object.keys(_sensitiveData);
    if (!sensitiveKeys.length) return;

    allTd.forEach(function(td) {
        var prevTd = td.previousElementSibling;
        if (!prevTd) return;
        var label = prevTd.textContent.trim().replace(/[:：\s]*$/, '');

        sensitiveKeys.forEach(function(key) {
            if (label === key) {
                // Hapus tombol lama jika ada (re-inject)
                var oldBtn = td.querySelector('.priv-toggle');
                if (oldBtn) oldBtn.remove();
                
                var isVisible = !!_sensitiveVisible[key];
                var btn = document.createElement('span');
                btn.className = 'priv-toggle';
                btn.style.cssText = 'cursor:pointer; font-size:10px; margin-left:6px; color:#17a2b8; border:1px solid #17a2b8; padding:1px 5px; border-radius:3px; font-family:sans-serif; vertical-align:middle; user-select:none; display:inline-block;';
                btn.textContent = isVisible ? '🔓 HIDE' : '🔒 SHOW';
                btn.onclick = function(e) { e.stopPropagation(); toggleSensitive(key); };
                td.appendChild(btn);
            }
        });
    });
}

var vm_sysInfo = new Vue({
    el: "#net_info",
    data: {
        values_sysInfo: {},
        title: DOC.title.network,
        explanation: HELP.head.explanation,
        sysInfo: HELP.head.sysInfo,
        colon: DOC.colon,
        text: [{
            title: fourgInfohtml.helper.title2,
            item: fourgInfohtml.helper.item2
        }]
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SYS_INFO_NETWORK
                },
                success: function (datas) {
                    var mcs_info, pci_info, bandwidth_info, sinr_info, cell_id_info, cqi_info, currentband_info, freq_info, enodebid_info, mcs_info_5g, bandwidth_info_5g, sinr_info_5g, cqi_info_5g, currentband_info_5g, cell_id_info_5g, enodebid_info_5g, pci_info_5g, freq_info_5g;
                    mcs_info = datas.dl_mcs;
                    pci_info = datas.PCI;
                    // CA band: coba berbagai kemungkinan field name secondary band
                    var secBand = datas.currentband_ca || datas.ca_band || datas.sec_band || datas.currentband_5g_ca || '';
                    var secBw   = datas.bandwidth_ca   || datas.ca_bw   || datas.sec_bandwidth || '';
                    bandwidth_info = secBw
                        ? (datas.bandwidth + '+' + secBw + 'MHz')
                        : (datas.bandwidth ? datas.bandwidth + 'MHz' : datas.bandwidth);
                    sinr_info = datas.SINR;
                    cell_id_info = datas.CELL_ID;
                    cqi_info = datas.CQI;
                    currentband_info = secBand
                        ? ('B' + datas.currentband + '+B' + secBand)
                        : (datas.currentband ? 'B' + datas.currentband : datas.currentband);
                    freq_info = datas.FREQ;
                    enodebid_info = datas.ENODEBID;
                    mcs_info_5g = datas.dl_mcs_5g==0&&datas.RSSI?"-":datas.dl_mcs_5g;
                    ul_mcs_5g = datas.ul_mcs_5g==0&&datas.RSSI?"-":datas.ul_mcs_5g;
                    bandwidth_info_5g = datas.bandwidth_5g;
                    sinr_info_5g = datas.SINR_5G;
                    cqi_info_5g = datas.CQI_5G ==0&&datas.RSSI?"-":datas.CQI_5G;
                    currentband_info_5g = datas.currentband_5g;
                    cell_id_info_5g = datas.CELL_ID_5G;
                    enodebid_info_5g = datas.ENODEBID_5G;
                    pci_info_5g = datas.PCI_5G;
                    freq_info_5g = datas.FREQ_5G;
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.netMode, datas.network_type_str || loading);
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.signal, StatusUtil.formatSingalLevel(datas.signal_lvl,datas.network_type_str ));

                    // === OPERATOR NAME: PLMN-based mapping + cleanup ===
                    var plmnMap = {
                        '51010': 'Telkomsel', '510010': 'Telkomsel',
                        '51011': 'XL Axiata', '510011': 'XL Axiata',
                        '51001': 'Indosat Ooredoo', '510001': 'Indosat Ooredoo',
                        '51021': 'Indosat Ooredoo', '510021': 'Indosat Ooredoo',
                        '51089': 'Tri', '510089': 'Tri',
                        '51009': 'Smartfren', '510009': 'Smartfren',
                        '51028': 'Smartfren', '510028': 'Smartfren',
                        '51008': 'AXIS', '510008': 'AXIS',
                        '51027': 'Net1', '510027': 'Net1',
                        '51000': 'STI', '510000': 'STI'
                    };
                    function cleanOperatorName(raw) {
                        if (!raw) return '';
                        return raw.replace(/[-\s]*(WAP|Unlimited|Internet|Data|Prabayar|Pascabayar|HALO|Ooredoo Hutchison|Hutchison|Telecom)$/gi, '')
                                  .replace(/^\s+|\s+$/g, '');
                    }
                    var plmnId = (datas.PLMN || datas.plmn_id || datas.plmn || '').replace(/\s/g, '');
                    var operatorName = plmnMap[plmnId] || '';
                    if (!operatorName) {
                        var spnOp = datas.spn_network_operator;
                        var validSpn = spnOp && spnOp !== '(null)' && spnOp !== 'null' && spnOp !== '-';
                        var netOp = cleanOperatorName(datas.network_operator || '') || loading;
                        if (datas.is_use_spn_set_operator === '1' && validSpn) {
                            operatorName = cleanOperatorName(spnOp);
                        } else {
                            operatorName = netOp;
                        }
                    }
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.plmn, operatorName || loading);

                    // === NON-SENSITIVE FIELDS ===
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rsrp, (datas.RSRP || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rssi, (datas.RSSI || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rsrq, (datas.RSRQ || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.sinr, (sinr_info || loading));

                    // === SENSITIVE FIELDS: masked by default ===
                    var sensitiveFields = {};
                    sensitiveFields[DOC.lte.phyCellId] = pci_info || loading;
                    sensitiveFields[DOC.lte.enodeB] = enodebid_info || loading;
                    sensitiveFields[DOC.lte.cellId] = cell_id_info || loading;
                    sensitiveFields["ECGI"] = datas.ECGI || loading;

                    for (var sKey in sensitiveFields) {
                        _sensitiveData[sKey] = sensitiveFields[sKey];
                        if (_sensitiveVisible[sKey]) {
                            vm_sysInfo.$set(vm_sysInfo.values_sysInfo, sKey, sensitiveFields[sKey]);
                        } else {
                            vm_sysInfo.$set(vm_sysInfo.values_sysInfo, sKey, maskValue(sensitiveFields[sKey]));
                        }
                    }

                    // === REMAINING NON-SENSITIVE FIELDS ===
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.freqPoint, (freq_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.cqi, (cqi_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.ULMCS, (datas.ul_mcs || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.DLMCS, (mcs_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.bandwidth, (bandwidth_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lockband.currentBand, (currentband_info || loading));
                    if(Page.level == "1")
                    {
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.qam64, datas.ul64qam_support == "1" ? "YES" : "NO");
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.qam256, datas.ul256qam_support == "1" ? "YES" : "NO");
                    }
                    if (Page.level != "3") {
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.maxQamUl, (datas.max_ul_qam || loading));
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.maxQamDl, (datas.max_dl_qam || loading));
                    }
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rank, (datas.rank_4g || loading) );
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.DL_BLER, (datas.bler_4g || loading));
                    
                    var historyFlow = 0,currentFlow = 0;
                    if(!isNaN(datas.flow_dl)) {
                        currentFlow += Number(datas.flow_dl);
                    }
                    if(!isNaN(datas.flow_ul)) {
                        currentFlow += Number(datas.flow_ul);
                    }
                    if(!isNaN(datas.history_flow_dl)) {
                        historyFlow += Number(datas.history_flow_dl);
                    }
                    if(!isNaN(datas.history_flow_ul)) {
                        historyFlow += Number(datas.history_flow_ul);
                    }
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.flow_current, currentFlow.toFixed(2) + "MB");
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.flow_history, historyFlow.toFixed(2) + "MB");

                    // Inject tombol SHOW/HIDE setelah Vue render selesai
                    Vue.nextTick(function() { injectShowButtons(); });
                }
            })
        }
    },
    mounted: function () {
        this.getData();
        Page.timer = setInterval(function () {
            vm_sysInfo.getData();
        }, 10000);
    }
});