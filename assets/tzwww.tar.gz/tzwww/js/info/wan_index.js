$(document).ready(function () {
    
    var tabs = TAB.advance;
    var id = "WAN_INFO";
    var items = [];

    items.push({ title: DOC.title.network, url: 'html/info/sysInfo.html' });
    items.push({ title: DOC.title.apnInfo, url: 'html/info/wan_info.html' });
    if(Page.pageHideCheck(0))
        items.push({ title: DOC.title.apn1Info, url: 'html/info/wan1_info.html' });
    if(Page.pageHideCheck(1))
        items.push({ title: DOC.title.apn2Info, url: 'html/info/wan2_info.html' });
    
    
    secondMenuClick(items,id);
});
