$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "Telnet",
            statusText: "Status",
            statusValue: "Checking...",
            buttonText: "Enable Now",
            isClick: false,
            enabled: false
        },
        methods: {
            requestCgi: function (url, method, body, callback, dataType) {
                $.ajax({
                    url: url,
                    type: method || "GET",
                    data: body || "",
                    processData: false,
                    contentType: "text/plain; charset=UTF-8",
                    dataType: dataType || "text",
                    timeout: 8000,
                    success: function (resp) {
                        callback(null, resp);
                    },
                    error: function (xhr, textStatus) {
                        callback(textStatus || "request_error", "");
                    }
                });
            },
            applyRuntimeStatus: function (isRunning) {
                if (isRunning) {
                    this.enabled = true;
                    this.statusValue = "Enabled";
                    this.buttonText = "Disable Now";
                } else {
                    this.enabled = false;
                    this.statusValue = "Disabled";
                    this.buttonText = "Enable Now";
                }
            },
            refreshStatus: function () {
                this.requestCgi("/cgi-bin/extra.cgi?action=telnet&detail=1", "GET", "", function (err, resp) {
                    if (err) {
                        vm.applyRuntimeStatus(false);
                        vm.statusValue = "Unknown";
                        return;
                    }
                    var data = null;
                    if (resp && typeof resp === "object") {
                        data = resp;
                    } else {
                        try {
                            data = JSON.parse((resp || "").toString());
                        } catch (e) {}
                    }

                    if (data && data.success !== false && typeof data.running !== "undefined") {
                        vm.applyRuntimeStatus(!!data.running);
                        return;
                    }

                    // Legacy fallback (old telnet CGI response format).
                    var text = (resp || "").toString().trim();
                    vm.applyRuntimeStatus(text === "1");
                }, "json");
            },
            toggleTelnet: function () {
                var action = this.enabled ? "disable" : "enable";
                vm.isClick = true;
                fyAlertMsgLoading();
                vm.requestCgi("/cgi-bin/extra.cgi?action=telnet", "POST", action, function (err, resp) {
                    vm.isClick = false;
                    if (err) {
                        fyAlertMsgFail("Request failed");
                        return;
                    }
                    var text = (resp || "").toString().trim();
                    if (text.indexOf("OK") !== 0) {
                        fyAlertMsgFail(text || "Failed");
                        return;
                    }
                    fyAlertMsgSuccess();
                    vm.refreshStatus();
                });
            }
        },
        mounted: function () {
            this.refreshStatus();
        }
    });
});
