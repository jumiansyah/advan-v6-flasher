$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "IMEI Change",
            currentImeiText: "Current IMEI",
            imeiInputText: "New IMEI",
            submitText: "Submit",
            isClick: false,
            currentImei: "-",
            imeiValue: ""
        },
        methods: {
            requestCgi: function (url, method, body, callback) {
                $.ajax({
                    url: url,
                    type: method || "GET",
                    data: body || "",
                    processData: false,
                    contentType: "text/plain; charset=UTF-8",
                    timeout: 8000,
                    success: function (resp) {
                        callback(null, (resp || "").toString().trim());
                    },
                    error: function (xhr, textStatus) {
                        callback(textStatus || "request_error", "");
                    }
                });
            },
            refreshCurrentImei: function () {
                this.requestCgi("/cgi-bin/extra.cgi?action=imei", "GET", "", function (err, text) {
                    if (err) {
                        vm.currentImei = "-";
                        return;
                    }
                    if (/^[0-9]{15}$/.test(text)) {
                        vm.currentImei = text;
                    } else {
                        vm.currentImei = "-";
                    }
                });
            },
            submitImei: function () {
                var imei = (this.imeiValue || "").toString().trim();
                if (!/^[0-9]{15}$/.test(imei)) {
                    AlertUtil.alertMsg("IMEI must be exactly 15 digits.");
                    return;
                }

                vm.isClick = true;
                fyAlertMsgLoading();
                vm.requestCgi("/cgi-bin/extra.cgi?action=imei", "POST", imei, function (err, text) {
                    vm.isClick = false;
                    if (err) {
                        fyAlertMsgFail("Request failed");
                        return;
                    }
                    if (text.indexOf("OK") !== 0) {
                        fyAlertMsgFail(text || "Failed");
                        return;
                    }
                    fyAlertMsgSuccess();
                    vm.refreshCurrentImei();
                });
            }
        },
        mounted: function () {
            this.refreshCurrentImei();
        }
    });
});
