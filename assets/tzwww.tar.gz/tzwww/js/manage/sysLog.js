$(document).ready(function() {
	var vm = new Vue({
		el:"#child_container",
		data:{
			sysLog:MENU.sys.sysLog,
			clearLogData:DOC.btn.clear,
			clearLogIsshow:false,
			syslogContent:""
		},
		methods:{
			getData:function(){
				Page.postJSON({
					returnHtml: true,
			        json: {
			            cmd: RequestCmd.SYS_LOG
			        },
			        success: function(data) {
			            vm.syslogContent = data.replace(/\n/g, "<br />");
			            $("#syslog").height($('#right').height() - 105);
			            vm.clearLogIsshow = true;

			        }
		    	});
			},
			clearLog:function(){
				Page.postJSON({
			        json: {
			            cmd: RequestCmd.SYS_LOG,
			            method: JSONMethod.POST
			        },
			        success: function(data) {
			        	vm.getData();
			        }
			    });
			}
		},
		mounted:function(){
			this.getData();
		}
	})
	
});
