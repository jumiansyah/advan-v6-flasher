$(document).ready(function () {
    var tabs = TAB.advance;
    var id = "FW_RULE";
    var items = [];
    items.push({ title: TAB.fw.defaultSetting, url: 'html/firewall/default.html' });
    items.push({ title: DOC.title.addPortFiltering, url: 'html/firewall/portFilter.html' });
    items.push({ title: TAB.fw.ipPortFiltering, url: 'html/firewall/ipFilter.html' });
    items.push({ title: TAB.fw.macFiltering, url: "html/firewall/macFilter.html" });
    secondMenuClick(items,id);

});

