$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46,DOC.net.protocol, dialconfightml.vpnTable.vpnIpTh,
    DOC.net.targeIp,DOC.net.sourcePort,DOC.net.targePort,DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule];
    var htmlData = []
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            protocol: DOC.net.protocol,
            ipAddress: dialconfightml.vpnTable.vpnIpTh,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            confirm: DOC.lbl.confirm,
            close: DOC.btn.close,
            ipFiltering: TAB.fw.ipPortFiltering,
            radioModelValue: false,
            ProtocolValue: "All",
            ipAddressValue: "",
            commentValue: "",
            flag: "",
            isWork: false,
            ipproValue: "IPV4",
            sourcePort: DOC.net.sourcePort,
            targePort: DOC.net.targePort,
            targeIp: DOC.net.targeIp,
            srcPort: "",
            destPort: "",
            destIp: "",
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_PORT_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.ProtocolValue = "All";
                this.ipAddressValue = "";
                this.commentValue = "";
                this.srcPort = "";
                this.destPort = "";
                this.destIp = "";
            },
            btnCloseClick: function () {
                this.flag = "";
                $box.removeClass('edit_box').hide();
                $mask.hide();
            },
            applyRulesClick: function () {
                this.isWork = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_PORT_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isWork = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules,function(){
                        fyAlertMsgLoading();
                        vm.value = [];
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.IP_PORT_FILTER,
                                method: JSONMethod.POST,
                                success: true,
                                datas: vm.value
                            },
                            success: function (data) {
                                vm.showTip = false;
                                if (data.success == true) {
                                    Page.applyFilter();
                                }else{
                                    fyAlertMsgFail();
                                }
                            }
                        });
                })
            },
            btnSave: function () {
                var checkPort = /^-?[1-9]\d*$/
                if ((this.srcPort != ''&&!checkPort.test(this.srcPort)) || (this.destPort != ''&&!checkPort.test(this.destPort))) {
                    AlertUtil.alertMsg(CHECK.format.port);
                    return false;
                }
                if (this.ipAddressValue != '' && !CheckUtil.checkIpRange(this.ipAddressValue,this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.destIp != '' && !CheckUtil.checkIpRange(this.destIp,this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.srcPort != '' && !CheckUtil.checkPort(this.srcPort).isValid) {
                    AlertUtil.alertMsg(CHECK.format.port);
                    return false;
                }
                if (this.destPort != '' && !CheckUtil.checkPort(this.destPort).isValid) {
                    AlertUtil.alertMsg(CHECK.format.port);
                    return false;
                }
                var arr = {
                    enableLink: this.radioModelValue,
                    remark: this.commentValue,
                    ip: this.ipAddressValue,
                    destIp: this.destIp,
                    srcPort: this.srcPort,
                    destPort: this.destPort,
                    protocol: this.ProtocolValue,
                    ippro:this.ipproValue
                }
                for(var i=0;i<this.value.length;i++){
                    var flag = 0;
                    if(this.value[i].ippro == this.ipproValue){
                        flag+=1;
                    }
                    if(this.value[i].ip == this.ipAddressValue){
                        flag+=1;
                    }
                    if(this.value[i].destIp == this.destIp){
                        flag+=1;
                    }
                    if(this.value[i].srcPort == this.srcPort){
                        flag+=1;
                    }
                    if(this.value[i].destPort == this.destPort){
                        flag+=1;
                    }
                    if(this.value[i].protocol == this.ProtocolValue){
                        flag+=1;
                    }
                    if(flag == 6){
                        if(this.flag === i && (this.value[i].remark != arr.remark || this.value[i].enableLink != arr.enableLink)){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.flag === "number"){
                    arr.enableRule = this.value[this.flag].enableRule,
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true,
                    this.value.push(arr);
                }
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
                this.btnCloseClick();
            },
            editClick: function (index) {
                this.flag = index;
                this.ProtocolValue = this.value[this.flag].protocol;
                this.ipAddressValue = this.value[this.flag].ip;
                this.commentValue = this.value[this.flag].remark;
                this.ipproValue = this.value[this.flag].ippro;
                this.destIp = this.value[this.flag].destIp;
                this.srcPort = this.value[this.flag].srcPort;
                this.destPort = this.value[this.flag].destPort;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules,function(){
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
               })
            }
        },
        mounted:function(){
            this.getData();
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEFAULT_FILTER,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    if(!!data.datas){
                        vm.radioModelValue = !data.datas[0].acceptAll;
                    } else {
                        vm.radioModelValue = false;
                    }
                }
            });
        },
        computed:{
            editPort:function(){
                var flag = this.ProtocolValue == "All" || this.ProtocolValue == "ICMP";
                if(flag){
                    this.srcPort = "";
                    this.destPort = "";
                }
                return flag;
            }
        }
    });
    var $box = $('#edit_box'), $mask = $('#mask');
});