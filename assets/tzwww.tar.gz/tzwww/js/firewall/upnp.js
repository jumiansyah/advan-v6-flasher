$(document).ready(function () {
    Page.render();
    var loading = '-';
    var title = [DOC.table.rowNo, TAB.fw.upnpprotocol, TAB.fw.upnpport, TAB.fw.mappingip, TAB.fw.mappingport];
    var values = [loading, loading, loading, loading, loading];
    var vm = new Vue({
        el: "#child_container",
        data: {
            upnpDescribe: TAB.fw.upnpDescribe,
            upnpStatus: TAB.fw.upnpStatus,
            open: wirelessconfightml.form1.open,
            disable: DOC.status.disable,
            upnpList: TAB.fw.upnpList,
            btnSetting: networktoolhtml.form5.btnSetting,
            title: title,
            value: "",
            disabled: false,
            broadcast: false
        },
        methods: {
            createTable: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.FW_UPNP
                    },
                    success: function (datas) {
                        vm.$data.value = datas.data.upnuList;
                        vm.$data.broadcast = datas.data.status == "enable" ? true : false;
                    }
                });
            },
            saveData: function () {
                this.disabled = true;
                var json = {};
                json.cmd = this.broadcast ? RequestCmd.FW_UPNP_ENABLE : RequestCmd.FW_UPNP_DISABLE;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            AlertUtil.alertMsg(PROMPT.saving.success);
                        }
                    }
                });
            }
        }
    })
    vm.createTable()
});