$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "FW_PORT_MAPPING";
    var items = [];

    items.push({ title: MENU.fw.portMapping, url: 'html/firewall/portMapping.html' });
    
    secondMenuClick(items,id);
});
