$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "FW_SPEED_LIMIT";
    var items = [];

    items.push({ title: DOC.title.addSpeedLimit, url: 'html/firewall/speedLimit.html' });
    
    secondMenuClick(items,id);
});