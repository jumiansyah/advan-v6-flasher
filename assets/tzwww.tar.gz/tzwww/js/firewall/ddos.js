$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            ackFloodSwich: false,
            ddosSwich: false,
            disabled: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DDOS_PROTECTION,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.ddosSwich = data.ddosSwich == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                this.disabled = true;
                var json = {};
                fyAlertMsgLoading();
                if(this.ddosSwich){
                    json.ddosSwich = "1";
                } else {
                    json.ddosSwich = "0";
                }
                json.cmd = RequestCmd.DDOS_PROTECTION;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted:function(){
            this.getData();
        }
    })

});