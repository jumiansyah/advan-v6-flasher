$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "FW_ACL_FILTER";

    items.push({ title: DOC.title.addAclFiltering, url: 'html/firewall/aclFilter.html' });
    
    secondMenuClick(items,id);
});