$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, DOC.net.protocol, DOC.net.port,
        DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule
    ];
    var htmlData = []
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            protocol: DOC.net.protocol,
            all: DOC.lbl.all,
            tcp: DOC.net.tcp,
            udp: DOC.net.udp,
            port: DOC.net.port,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            save: DOC.btn.save,
            close: DOC.btn.close,
            addPortFiltering: DOC.title.addPortFiltering,
            radioModelValue: true,
            ProtocolValue: "all",
            portValue: "",
            commentValue: "",
            flag: "",
            ipproValue: "IPV4",
            isWork: false,
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.PORT_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.$data.value = data.datas;
                        }

                    }
                });
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.ProtocolValue = "all";
                this.ipproValue = "IPV4";
                this.portValue = "";
                this.commentValue = ""
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            applyRulesClick: function () {
                this.isWork = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.PORT_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isWork = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.PORT_FILTER,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })

            },
            btnSave: function () {
                var portCheck = /[0-9-<>]+$/;
                if (this.portValue == "") {
                    AlertUtil.alertMsg(CHECK.required.port);
                    return false;
                }
                var portValue = this.portValue;
                if (!(portCheck.test(portValue)) || parseInt(portValue,10) > 65535 || parseInt(portValue,10) < 0) {
                    AlertUtil.alertMsg(CHECK.range.port);
                    return false;
                }
                var checkPort = /^-?[1-9]\d*$/
                if (!checkPort.test(this.portValue)) {
                    AlertUtil.alertMsg(CHECK.format.port);
                    return false;
                }
                var arr = {
                    enableLink: this.radioModelValue,
                    remark: this.commentValue,
                    port: this.portValue,
                    protocol: this.ProtocolValue,
                    ippro: this.ipproValue
                }
                for(var i=0;i<this.value.length;i++){
                    var flag = 0;
                    if(this.value[i].ippro == arr.ippro){
                        flag+=1;
                    }
                    if(this.value[i].port == arr.port){
                        flag+=1;
                    }
                    if(this.value[i].protocol == arr.protocol){
                        flag+=1;
                    }
                    if(flag == 3){
                        if(this.flag === i && (this.value[i].remark != arr.remark || this.value[i].enableLink != arr.enableLink)){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.flag === "number"){
                    arr.enableRule = this.value[this.flag].enableRule;
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true;
                    this.value.push(arr);
                }
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
                this.btnCloseClick();
            },
            editClick: function (event, index) {
                this.flag = index;
                this.ProtocolValue = event.protocol;
                this.portValue = event.port;
                this.commentValue = event.remark;
                this.ipproValue = event.ippro;

                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                })
            }
        },
        mounted:function(){
            this.getData();
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEFAULT_FILTER,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    if(!!data.datas){
                        vm.radioModelValue = !data.datas[0].acceptAll;
                    } else {
                        vm.radioModelValue = false;
                    }
                }
            });
        }
    });
    var $box = $('#edit_box'),
        $mask = $('#mask');
});