$(document).ready(function () {
	// if(!IsPC()){
	// 	vant.Dialog.confirm({
	// 		message: PROMPT.confirm.deviceInfo,
	// 		confirmButtonText:DOC.btn.confirm,
	// 		cancelButtonText:PROMPT.tips.cancel
	// 	  })
	// 		.then(function() {
	// 			window.location.href = Page.getUrl("/mobile_web/login.html");
	// 		})
	// 		.catch(function() {
	// 			return 
	// 		});
        
  //   }
	if (navigator.appName == "Microsoft Internet Explorer" && parseInt(navigator.appVersion.split(";")[1].replace(/[ ]/g, "").replace("MSIE", "")) < 9) {
		AlertUtil.alertMsg(DOC.login.Browser);
		return false;
	};
	//禁止右键和键盘复制功能
	 document.oncontextmenu = function (event) {
                if (window.event) {
                    event = window.event;
                }
                try {
                    var the = event.srcElement;
                    if (!((the.tagName == "INPUT" && the.type.toLowerCase() == "text") || the.tagName == "TEXTAREA")) {
                        return false;
                    }
                    return true;
                } catch (e) {
                    return false;
                }
            }
        document.onkeydown = function () {
            if (window.event.ctrlKey && window.event.keyCode == 85) {
                event.keyCode = 0;
                event.returnValue = false;
                return false;
            }

        }
	Page.postJSON({
		json: {
			cmd: RequestCmd.INIT_PAGE
		},
		success: function (data) {
			// ConvertUtil.parseHexPageHide(data.web_page_hide)
			sessionStorage['theme'] = data.user_web_theme;
			var themeWeb = "";
			if (!data.user_web_theme) {
				themeWeb = "main.css";
			} else {
				themeWeb = data.user_web_theme;
			}
			vm.showHarvard = themeWeb === "main.Indonesia.css" ? true:false
			Page.themeWeb = themeWeb;
			if (!!data.web_browser_title) {
				vm.web_browser_title = data.web_browser_title;
			}
			var styleTag = document.createElement("link");
			styleTag.setAttribute('href', 'css/' + themeWeb+"?t="+Math.random());
			styleTag.setAttribute('type', 'text/css');
			styleTag.setAttribute('rel', 'stylesheet');
			$("head")[0].appendChild(styleTag);
			if( data.web_logo_path == "logo_t3.png") {
				var styleTag = document.createElement("link");
				styleTag.setAttribute('href', 't3_favicon.ico');
				styleTag.setAttribute('type', 'image/x-icon');
				styleTag.setAttribute('rel', 'shortcut icon');
				$("head")[0].appendChild(styleTag);
			}
		}
	})
	var vm = new Vue({
		el: "#login_box",
		data: {
			loginLan: "",
			colon: DOC.colon,
			loginUsername: "",
			loginPasswd: "",
			btnLogin: "",
			timerFlag: false,
			login_times_text: "",
			loginTimesIsShow: false,
			accountLock: "",
			isLoginLanguage: false,
			// isShowLogin:false,
			isShowInfo: true,
			languageSelectValue: "",
			languageSelectList: [],
			languageSelectShow: false,
			autoUpgradeName: "",
			showAutoUp: false,
			autoUpgrade: false,
			passSrc: "/images/close.png",
			passType: "password",
			web_browser_title: '',
			checkbox:false,
			usernameVal:"",
			passwordVal:"",
      refresh: DOC.btn.refresh,
      passError:false,
			showHarvard:false
		},
		methods: {
      validateClick:function(){
        if(this.passwordVal.length>64){
          this.passError = true;
        }else{
          this.passError = false;
        }
      },
			initPage: function () {
				function init() {
					Page.initPage(true);
					$(window).resize(function () {
						Page.initPage(true);
					});
					document.title = vm.web_browser_title || DOC.head;
					vm.loginLan = DOC.login.language;
					vm.loginUsername = DOC.login.username;
					vm.loginPasswd = DOC.login.passwd;
					vm.btnLogin = DOC.btn.login;
					vm.accountLock = CHECK.format.accountLock;
					vm.isLoginLanguage = true;
					vm.languageSelectValue = Page.language.toLowerCase()
					vm.autoUpgradeName = DOC.btn.loginAuto;
					var $username = $('#username').focus(),
						$passwd = $('#passwd'),
						$btnLogin = $('#btnLogin');
					var loginText = $btnLogin.val();
					var login_times = sessionStorage.getItem("login_times") || 3
					if (parseInt(login_times, 10) < 1 || parseInt(login_times, 10)==3) {
						vm.getNextText();
					}
					//登陆处理
					$btnLogin.click(function () {
						Page.postJSON({
							json: {
								cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
								method: JSONMethod.GET,
								sessionId: ""
							},
							success: function (data) {
								var token = data.token
								localStorage.setItem("flag1", "false")
								localStorage.setItem("index1", "0-0")
								var username = $username.val(),
									passwd = $passwd.val();
								if (username == "") {
									AlertUtil.alertMsg(CHECK.required.username);
									$username.focus();
									return false;
								}
								if (passwd == "") {
									AlertUtil.alertMsg(CHECK.required.passwd);
									$passwd.focus();

									return false;
								}
								$btnLogin.disable();
								var loginSuccess = false;
								Page.postJSON({
									json: {
										cmd: RequestCmd.LOGIN,
										method: JSONMethod.POST,
										sessionId: getSessionId(),
										username: username,
                    passwd: sha256_digest(token + passwd),
										isAutoUpgrade: vm.autoUpgrade ? "1" : "0"
									},
									success: function (data) {
										if (data.login_fail == "fail") {
											sessionStorage.setItem("login_times", data.login_times)
											fyConfirmMsg2(String.format("<span class=\"fail\" style='font-size:16px;'>{0}{1}</span>", CHECK.format.attempts, data.login_times))
											var loginTimer = null;
											if (parseInt(data.login_times, 10) < 1) {
												loginTimer = setInterval(function () {
													Page.postJSON({
														json: {
															cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
															method: JSONMethod.GET,
															sessionId: ""
														},
														success: function (data) {
															vm.loginTimesIsShow = true;
															var times = 180 - data.netx_login_time;
															vm.login_times_text = String.format("<span class=\"fail\" style='font-size:16px;'>{0}{1}</span>", vm.accountLock, times);
															if (parseInt(times, 10) < 1) {
																vm.loginTimesIsShow = false;
																clearInterval(loginTimer);
															}
														}
													})
												}, 1000)
											}
										} else {
											sessionStorage.setItem("login_times", 3)
											loginSuccess = data.success;
											sessionStorage['sessionId'] = data.sessionId;
											sessionStorage['canLogin'] = data.AUTH;
											sessionStorage["level"] = data.user_level;
											location.href = Page.getUrl("index.html");
											if (vm.checkbox) {
												localStorage.setItem("usernameValue", vm.usernameVal);
												localStorage.setItem("passwordValue", Base64.encode(vm.passwordVal))
											} else {
												localStorage.setItem("usernameValue", "");
												localStorage.setItem("passwordValue", "")
											}
										}

									},
									complete: function () {
										$btnLogin.enable();
									}
								});
							}
						})
					});

					$username.keydown(function (e) {
						if (e.which == 13) {
							$passwd.focus();
						}
					});

					$passwd.keydown(function (e) {
						if (e.which == 13) {

							if (!$btnLogin.attr("disabled") && $(".fy-alert-shadow").length == 0) {
								$btnLogin.click();
							}
						}
					});

					function getSessionId() {
						return Md5.md5(Math.random().toString()) + Md5.md5(Math.random().toString());
					}

					sessionStorage['canLogin'] = ""; //清除权限，不然可以直接登录。前进后退时
					getOpenInfo();
					StatusUtil.getSysStatus();
				}

				Page.postJSON({
					json: {
						cmd: RequestCmd.INIT_PAGE
					},
					success: function (data) {
						var language = data.language.toUpperCase();
						var supportLanguage = []
						if (data.language_support) {
							supportLanguage = parseInt(data.language_support, 16).toString(2).split("").reverse();
							for (var i = 0; i < supportLanguage.length; i++) {
								if (supportLanguage[i] == "1") {
									vm.languageSelectList.push(Page.getSupportlanguageList[i])
								}
							}
						} else {
							vm.languageSelectList = Page.getSupportlanguageList;
						}
						if (data.iad_ready_status == "0") {
							$("#wifiInfo").detach();
							$("#wifiInfo5g").detach();
							$("#lan1").detach();
							$("#lan2").detach();
							$("#lan3").detach();
							$("#lan4").detach();
							$("#wan1").detach();
						}
						if (data.language_show == "1") {
							vm.languageSelectShow = true;
						} else {
							vm.languageSelectShow = false;
						}
						if (data.showAutoUpgrade == "1") {
							vm.showAutoUp = true;
						} else {
							vm.showAutoUp = false;
						}
						vm.autoUpgrade = data.isAutoUpgrade == "1" ? true : false;
						if (!!data.web_browser_title) {
							vm.web_browser_title = data.web_browser_title;
						}
						if (Page.requireChangeLang(language)) {
							Page.language = language;
							Page.postJSON({
								json: {
									cmd: RequestCmd.CHANGE_LANGUAGE,
									method: JSONMethod.POST,
									sessionId: "",
									languageSelect: language
								},
								success: function (data) {
									$("script[src^='js/language/']").remove();
									$.getScript('js/language/' + language.toLowerCase() + '.js', init);
								}
							});
						} else {
							init();
						}
					}
				});
			},
			changeLanguageSelect: function () {
				Page.postJSON({
					json: {
						cmd: RequestCmd.CHANGE_LANGUAGE,
						method: JSONMethod.POST,
						sessionId: "",
						languageSelect: vm.languageSelectValue
					},
					success: function (data) {},
					complete: function () {
						var href = location.href;
						if (href.indexOf('#') > -1) {
							href = href.substring(0, href.indexOf('#'));
						}
						if (href.indexOf('?') > -1) {
							href = href.substring(0, href.indexOf('?'));
						}
						location.href = Page.getUrl(href);
					}
				});
			},
			getNextText: function () {
				Page.postJSON({
					json: {
						cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
						method: JSONMethod.GET,
						sessionId: ""
					},
					success: function (data) {
						if (data.buffer == "0") {
							var times = 180 - data.netx_login_time;
							vm.login_times_text = String.format("<span class=\"fail\" style='font-size:16px;'>{0}{1}</span>", vm.accountLock, times);
							if (times < 1) {
								vm.loginTimesIsShow = false;
							} else {
								vm.loginTimesIsShow = true;
							}
							setTimeout(vm.getNextText, 1000);
						}

					}
				})
			},
			clickLogin: function () {
				this.isShowLogin = true;
				this.isShowInfo = false;
				$("#login_template").show();
				$("#username").focus();
			},
			changePage:function(){
				location.reload();
			},
			showPsw: function () {
				if (this.passType == "password") {
					this.passSrc = "/images/open.png";
					this.passType = "text";
				} else {
					this.passSrc = "/images/close.png";
					this.passType = "password";
				}
			}
		},
		mounted: function () {
			this.usernameVal = localStorage.getItem("usernameValue") || "";
			if(localStorage.getItem("passwordValue")){
				this.passwordVal = Base64.decode(localStorage.getItem("passwordValue"));
			}else{
				this.passwordVal = "";
			}
			
			if(this.usernameVal&&this.passwordVal){
				this.checkbox = true
			}else{
				this.checkbox = false
			}
			this.initPage();

		}

	})
});