$(document).ready(function() {
    var fm = ["childFormId", "child_container"];
    Page.createForm(fm);

    var vm = new Vue({
        el: "#child_container",
        data: {
            selectedTheme: ""
        },
        mounted: function() {
            // Detect current theme from loaded CSS
            var links = parent.document.querySelectorAll('link[rel="stylesheet"]');
            for (var i = 0; i < links.length; i++) {
                var href = links[i].href || "";
                if (href.indexOf("main.") > -1 && href.indexOf(".css") > -1) {
                    var match = href.match(/main\.[^/]+\.css/);
                    if (match) this.selectedTheme = match[0];
                }
            }
        },
        methods: {
            applyTheme: function(themeFile) {
                this.selectedTheme = themeFile;
                $.post("cgi-bin/custom.cgi", {
                    action: "set_theme",
                    theme: themeFile
                }, function(data) {
                    if (data && data.success) {
                        AlertUtil.alertMsg("Tema diterapkan! Halaman akan reload...");
                        setTimeout(function() {
                            parent.location.reload();
                        }, 1500);
                    } else {
                        AlertUtil.alertMsg("Gagal: " + (data.message || "Unknown error"));
                    }
                }, "json").fail(function() {
                    AlertUtil.alertMsg("Gagal menghubungi server");
                });
            }
        }
    });
});
