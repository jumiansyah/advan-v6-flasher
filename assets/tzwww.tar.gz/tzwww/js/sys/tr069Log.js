$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            tr069LogValue: false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            disabled: false,
            tr069Switch:DOC.greSettingsHelper.name0,
            save: DOC.btn.save
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.TR069_LOG_SWITCH
                    },
                    success: function (data) {
                        vm.tr069LogValue = data.switch == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.switch = this.tr069LogValue ? "1" : "0";
                json.cmd = RequestCmd.TR069_LOG_SWITCH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })

});