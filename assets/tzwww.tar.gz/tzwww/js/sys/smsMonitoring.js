new Vue({
    el: '#child_container',
    data: {
        config: {
            enabled: false,
            autostart: false,
            autostart_monitoring: false,
            autostart_sms_command: false,
            sms_command_enabled: false,
            ping_target: "8.8.8.8",
            ping_interval: 30,
            timeout_threshold: 300,
            sms_number: "",
            sms_message: "ALERT: Network down selama %duration%"
        },
        isSaving: false,
        isTesting: false,
        showSmsNumber: false,
        statusMessage: "",
        progressMessage: ""
    },
    mounted: function() {
        this.loadConfig();
    },
    methods: {
        loadConfig: function() {
            var self = this;
            fetch('/cgi-bin/custom.cgi?action=sms_monitoring_get')
                .then(function(response) {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(function(data) {
                    if (data.status === 'success') {
                        // Merge dengan default config
                        self.config = Object.assign(self.config, data.config);

                        // Backward compatibility untuk config lama
                        if (typeof self.config.autostart_monitoring === 'undefined') {
                            self.config.autostart_monitoring = !!self.config.autostart;
                        }
                        if (typeof self.config.autostart_sms_command === 'undefined') {
                            self.config.autostart_sms_command = !!self.config.autostart;
                        }
                    } else {
                        console.log('Using default config');
                    }
                })
                .catch(function(error) {
                    console.error('Error loading config:', error);
                    self.statusMessage = '⚠️ Gagal memuat konfigurasi, menggunakan default';
                });
        },

        saveConfig: function() {
            var self = this;
            
            // Validasi input
            if (!this.config.ping_target.trim()) {
                this.$message.error('Target ping tidak boleh kosong');
                return;
            }
            
            if (this.config.ping_interval < 5 || this.config.ping_interval > 300) {
                this.$message.error('Interval ping harus antara 5-300 detik');
                return;
            }
            
            if (this.config.timeout_threshold < 60 || this.config.timeout_threshold > 3600) {
                this.$message.error('Timeout threshold harus antara 60-3600 detik');
                return;
            }
            
            if ((this.config.enabled || this.config.sms_command_enabled) && !this.config.sms_number.trim()) {
                this.$message.error('Nomor SMS harus diisi jika Monitoring atau SMS Command diaktifkan');
                return;
            }

            // Legacy key tetap disimpan untuk kompatibilitas firmware lama.
            this.config.autostart = !!(this.config.autostart_monitoring || this.config.autostart_sms_command);
            
            this.isSaving = true;
            this.progressMessage = "Menyimpan konfigurasi...";
            
            // Use XMLHttpRequest instead of fetch for better compatibility
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/cgi-bin/custom.cgi?action=sms_monitoring_save', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onload = function() {
                self.isSaving = false;
                self.progressMessage = "";
                
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.status === 'success') {
                            self.$message.success('Konfigurasi berhasil disimpan');
                            self.statusMessage = '✅ Konfigurasi tersimpan pada ' + new Date().toLocaleString();
                            
                            if (self.config.enabled) {
                                self.statusMessage += '<br/>📡 Monitoring aktif untuk target: ' + self.config.ping_target;
                            } else {
                                self.statusMessage += '<br/>⏸️ Monitoring dinonaktifkan';
                            }
                        } else {
                            self.$message.error('Gagal menyimpan: ' + (data.message || 'Unknown error'));
                            self.statusMessage = '❌ Gagal menyimpan konfigurasi: ' + (data.message || 'Unknown error');
                        }
                    } catch (e) {
                        self.$message.error('Error parsing response: ' + e.message);
                        self.statusMessage = '❌ Response error: ' + e.message;
                    }
                } else {
                    self.$message.error('HTTP Error: ' + xhr.status);
                    self.statusMessage = '❌ HTTP Error: ' + xhr.status;
                }
            };
            
            xhr.onerror = function() {
                self.isSaving = false;
                self.progressMessage = "";
                self.$message.error('Network error occurred');
                self.statusMessage = '❌ Network error occurred';
            };
            
            // Send config as JSON string
            var configJson = JSON.stringify(this.config);
            xhr.send('config=' + encodeURIComponent(configJson));
        },

        testSMS: function() {
            var self = this;
            
            if (!this.config.sms_number.trim()) {
                this.$message.error('Nomor SMS harus diisi untuk test');
                return;
            }
            
            this.isTesting = true;
            this.progressMessage = "Mengirim test SMS...";
            
            // Use XMLHttpRequest
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/cgi-bin/custom.cgi?action=sms_monitoring_test', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onload = function() {
                self.isTesting = false;
                self.progressMessage = "";
                
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.status === 'success') {
                            self.$message.success('Test SMS berhasil dikirim');
                            self.statusMessage = '✅ Test SMS dikirim ke ' + self.config.sms_number + ' pada ' + new Date().toLocaleString();
                        } else {
                            self.$message.error('Gagal kirim SMS: ' + (data.message || 'Unknown error'));
                            self.statusMessage = '❌ Test SMS gagal: ' + (data.message || 'Unknown error');
                        }
                    } catch (e) {
                        self.$message.error('Error parsing response: ' + e.message);
                        self.statusMessage = '❌ Response parse error: ' + e.message;
                    }
                } else {
                    self.$message.error('HTTP Error: ' + xhr.status);
                    self.statusMessage = '❌ HTTP Error: ' + xhr.status;
                }
            };
            
            xhr.onerror = function() {
                self.isTesting = false;
                self.progressMessage = "";
                self.$message.error('Network error occurred');
                self.statusMessage = '❌ Network error occurred';
            };
            
            xhr.send('number=' + encodeURIComponent(this.config.sms_number));
        },

        updateStatus: function() {
            // Real-time update status ketika toggle
            var monitoringState = this.config.enabled ? 'Monitoring: AKTIF' : 'Monitoring: NON-AKTIF';
            var smsCmdState = this.config.sms_command_enabled ? 'SMS Command: AKTIF' : 'SMS Command: NON-AKTIF';
            var autoMonState = this.config.autostart_monitoring ? 'Autostart Monitoring: ON' : 'Autostart Monitoring: OFF';
            var autoSmsState = this.config.autostart_sms_command ? 'Autostart SMS Command: ON' : 'Autostart SMS Command: OFF';
            this.statusMessage = '🟡 Menunggu simpan konfigurasi<br/>' + monitoringState + '<br/>' + smsCmdState + '<br/>' + autoMonState + '<br/>' + autoSmsState;
        }
    }
});