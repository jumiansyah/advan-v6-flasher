/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-05-25 16:43:40
 * @,@LastEditTime: ,: 2021-05-25 17:03:09
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\sys\sysConfigIndex.js
 */
$(document).ready(function() {
	var tabs = TAB.sys;
	var items = [];
	var id = "SYS_SET";
	items.push({title: tabs.timeSetting, url: 'html/sys/timeSetting.html'});
	items.push({title: tabs.restoreFactory, url: 'html/sys/restoreFactory.html'});
	if(Page.pageHideCheck(42)){
		items.push({title: tabs.exportOrLoadConfig, url: 'html/sys/exportOrLoadConfig.html'});
	}
	items.push({title:tabs.adbSwitch, url: 'html/sys/adbSwitch.html'});
	if(Page.level == "1"){
		items.push({title:DOC.registerStatus.item7, url: 'html/sys/service.html'});
		items.push({title:tabs.modemlogSwitch, url: 'html/sys/modemlogSwitch.html'});
		// items.push({title:tabs.sfpIpaSwitch, url: 'html/sys/sfpIPA.html'});
		items.push({title:tabs.commlogBackup, url: 'html/sys/commlog.html'});
	}
	if(Page.pageHideCheck(46))
	{
		items.push({title:TAB.sys.tr069Log, url: 'html/sys/tr069Log.html'});
	}
	if(Page.pageHideCheck(51))
	{
		items.push({title:TAB.sys.yoctoLog, url: 'html/sys/yoctoLog.html'});
	}
	secondMenuClick(items,id);
});
