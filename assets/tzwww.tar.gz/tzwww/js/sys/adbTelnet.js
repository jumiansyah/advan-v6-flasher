var vm = new Vue({
    el: "#child_container",
    data: {
        telnet_status: false,
        adb_status: false,
        isToggling: false,
        logMessage: "Menunggu koneksi..."
    },
    methods: {
        /**
         * Fetch current true system status of adbd and telnetd
         * by polling pidof from custom.cgi
         */
        fetchStatus: function() {
            var self = this;
            fetch('/cgi-bin/custom.cgi?action=adb_telnet_status')
                .then(function(response) {
                    if (!response.ok) throw new Error('Network error');
                    return response.json();
                })
                .then(function(data) {
                    if(data.success) {
                        self.telnet_status = data.telnet;
                        self.adb_status = data.adb;
                        self.logMessage = "Sinkronisasi status mesin berhasil.";
                    }
                })
                .catch(function() {
                    self.logMessage = "Gagal membaca status sistem dari router.";
                });
        },
        
        /**
         * Handle manual user click
         */
        handleToggle: function(targetName) {
            var currentState = (targetName === 'telnet') ? this.telnet_status : this.adb_status;
            var targetState = !currentState;
            this.toggleService(targetName, targetState);
        },

        /**
         * Trigger the CGI backend to start/stop the service
         */
        toggleService: function(targetName, newState) {
            var self = this;
            self.isToggling = true;
            self.logMessage = "Mengeksekusi " + targetName.toUpperCase() + "...";
            
            var stateNum = newState ? "1" : "0";
            
            fetch('/cgi-bin/custom.cgi', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=adb_telnet_toggle&target=' + targetName + '&state=' + stateNum
            })
            .then(function(response) {
                if (!response.ok) throw new Error('Network error');
                return response.json();
            })
            .then(function(data) {
                self.isToggling = false;
                if(data.success) {
                    self.logMessage = data.message;
                    if(targetName === 'telnet') self.telnet_status = newState;
                    if(targetName === 'adb') self.adb_status = newState;
                } else {
                    self.logMessage = "KESALAHAN: " + data.message;
                    self.fetchStatus(); // Revert UI
                }
            })
            .catch(function() {
                self.isToggling = false;
                self.logMessage = "Gagal berkomunikasi dengan CGI.";
                self.fetchStatus(); // Revert UI
            });
        }
    },
    mounted: function() {
        this.fetchStatus();
    }
});
