$(document).ready(function () {
    Page.render();
    // Page.setStripeTable();
    var $btnSave = $('#btnSave');
    var vm = new Vue({
        el: "#child_container",
        data: {
            restoreFactory: DOC.sys.restoreFactory,
            colon: DOC.colon,
            btnRestoreFactory: DOC.btn.restoreFactory
        },
        methods: {
            btnRestoreFactoryClick: function () {
                fyConfirmMsg(PROMPT.confirm.restoreFactory, function () {
                    var datas = null;
                    SysUtil.showProgress(150, PROMPT.status.restoringFactory,
                        function () {
                            return datas != null;
                        },
                        function () {
                            SysUtil.reboot2({
                                rebootType: RENOOTTYPE.RESTORE_SETTING,
                                callback: function (canceled) {
                                    if (canceled) {
                                        SysUtil.restoreRebootCancel();
                                    } else {
                                        location.reload();
                                    }
                                    closeBox();
                                }
                            });
                        }
                    );

                    setTimeout(function () {
                        datas = {};
                        $btnSave.enable();
                    }, 40000);

                    Page.postJSON({
                        $id: $btnSave,
                        json: {
                            cmd: RequestCmd.RESTORE_DEFAULT,
                            method: JSONMethod.POST
                        },
                        success: function (data) {
                            datas = data;
                        }
                    });

                })


            }
        }
    })
    $btnSave.bind('click', function () {});
});