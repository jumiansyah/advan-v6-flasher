$(document).ready(function() {
    var fm = ["childFormId", "child_container"];
    Page.createForm(fm);

    var vm = new Vue({
        el: "#child_container",
        data: {
            modemModel: "Loading...",
            modemImei: "Loading...",
            showImei: false,
            showDonationInfo: false
        },
        mounted: function() {
            this.loadInfo();
        },
        methods: {
            loadInfo: function() {
                var self = this;
                $.getJSON("cgi-bin/custom.cgi?action=modem_info", function(data) {
                    self.modemModel = data.model || "Advan V6";
                    self.modemImei = data.imei || "-";
                });
            },
            maskImei: function(imei) {
                if (!imei || imei === "Loading..." || imei === "-") return imei;
                if (imei.length < 8) return "****";
                // Tampilkan 2 angka depan dan 2 angka belakang, sisanya sensor
                return imei.substring(0, 2) + "***********" + imei.substring(imei.length - 2);
            }
        }
    });
});
