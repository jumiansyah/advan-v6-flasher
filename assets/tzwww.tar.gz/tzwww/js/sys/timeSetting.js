var $btnSave = $('#btnSave');
var fm = ["form1", "child_container", "child_template"];
Page.createForm(fm);
var rules = {
        datetime: {
            required: true,
            datetime: true
        }
    },
    messages = {
        datetime: {
            required: CHECK.required.systemTime,
            datetime: CHECK.format.systemTime
        }
    };
var vm = new Vue({
    el: "#child_container",
    data: {
        systemTime: DOC.sys.systemTime,
        colon: DOC.colon,
        timezone: DOC.sys.timezone,
        ntp: DOC.sys.ntp,
        clientTime: DOC.sys.clientTime,
        getClientTime: DOC.btn.getClientTime,
        save: DOC.btn.save,
        timezoneHtml: [{
                name: DOC.timezone.item,
                value: " UTC12"
            },
            {
                name: DOC.timezone.halfitem1,
                value: "UTC11:30"
            },
            {
                name: DOC.timezone.item1,
                value: "UTC11"
            },
            {
                name: DOC.timezone.halfitem2,
                value: "UTC10:30"
            },
            {
                name: DOC.timezone.item2,
                value: "UTC10"
            },
            {
                name: DOC.timezone.halfitem3,
                value: "UTC9:30"
            },
            {
                name: DOC.timezone.item3,
                value: "UTC9"
            },
            {
                name: DOC.timezone.halfitem4,
                value: "UTC8:30"
            },
            {
                name: DOC.timezone.item4,
                value: "UTC8"
            },
            {
                name: DOC.timezone.halfitem5,
                value: "UTC7:30"
            },
            {
                name: DOC.timezone.item5,
                value: "UTC7"
            },
            {
                name: DOC.timezone.halfitem6,
                value: "UTC6:30"
            },
            {
                name: DOC.timezone.item6,
                value: "UTC6"
            },
            {
                name: DOC.timezone.halfitem7,
                value: "UTC5:30"
            },
            {
                name: DOC.timezone.item7,
                value: "UTC5"
            },
            {
                name: DOC.timezone.halfitem8,
                value: "UTC4:30"
            },
            {
                name: DOC.timezone.item8,
                value: "UTC4"
            },
            {
                name: DOC.timezone.halfitem9,
                value: "UTC3:30"
            },
            {
                name: DOC.timezone.item9,
                value: "UTC3"
            },
            {
                name: DOC.timezone.halfitem10,
                value: "UTC2:30"
            },
            {
                name: DOC.timezone.item10,
                value: "UTC2"
            },
            {
                name: DOC.timezone.halfitem11,
                value: "UTC1:30"
            },
            {
                name: DOC.timezone.item11,
                value: "UTC1"
            },
            {
                name: DOC.timezone.halfitem12,
                value: "UTC0:30"
            },
            {
                name: DOC.timezone.item12,
                value: "UTC0"
            },
            {
                name: DOC.timezone.halfitem13,
                value: "UTC-0:30"
            },
            {
                name: DOC.timezone.item13,
                value: "UTC-1"
            },
            {
                name: DOC.timezone.halfitem14,
                value: "UTC-1:30"
            },
            {
                name: DOC.timezone.item14,
                value: "UTC-2"
            },
            {
                name: DOC.timezone.halfitem15,
                value: "UTC-2:30"
            },
            {
                name: DOC.timezone.item15,
                value: "UTC-3"
            },
            {
                name: DOC.timezone.halfitem16,
                value: "UTC-3:30"
            },
            {
                name: DOC.timezone.item16,
                value: "UTC-4"
            },
            {
                name: DOC.timezone.halfitem17,
                value: "UTC-4:30"
            },
            {
                name: DOC.timezone.item17,
                value: "UTC-5"
            },
            {
                name: DOC.timezone.halfitem18,
                value: "UTC-5:30"
            },
            {
                name: DOC.timezone.item18,
                value: "UTC-6"
            },
            {
                name: DOC.timezone.halfitem19,
                value: "UTC-6:30"
            },
            {
                name: DOC.timezone.item19,
                value: "UTC-7"
            },
            {
                name: DOC.timezone.halfitem20,
                value: "UTC-7:30"
            },
            {
                name: DOC.timezone.item20,
                value: "UTC-8"
            },
            {
                name: DOC.timezone.halfitem21,
                value: "UTC-8:30"
            },
            {
                name: DOC.timezone.item21,
                value: "UTC-9"
            },
            {
                name: DOC.timezone.halfitem22,
                value: "UTC-9:30"
            },
            {
                name: DOC.timezone.item22,
                value: "UTC-10"
            },
            {
                name: DOC.timezone.halfitem23,
                value: "UTC-10:30"
            },
            {
                name: DOC.timezone.item23,
                value: "UTC-11"
            },
            {
                name: DOC.timezone.halfitem24,
                value: "UTC-11:30"
            },
            {
                name: DOC.timezone.item24,
                value: "UTC-12"
            }
        ],
        datetimeValue: "",
        lblTimeText: "",
        timeServerValue: "",
        timeServer2Value: "",
        timeServer3Value: "",
        timeServer4Value: "",
        timezoneValue: "",
        timeValue:"",
    },
    methods: {
        selectTime:function(value){
            this.timeValue = value;
        },
        getDateTime: function () {
            return new Date().format('yyyy-mm-dd HH:MM');
        },
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SET_DATETIME,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    vm.lblTimeText = data.systime;

                    vm.timeServerValue = FormatUtil.formatField(data.timeServer).trim();
                    vm.timeServer2Value = FormatUtil.formatField(data.timeServer2).trim();
                    vm.timeServer3Value = FormatUtil.formatField(data.timeServer3).trim();
                    vm.timeServer4Value = FormatUtil.formatField(data.timeServer4).trim();
                    var timezone = FormatUtil.formatField(data.timezone);
                    if (timezone.length == 0) {
                        timezone = "UTC-8";
                    }
                    for(var i=0;i<vm.timezoneHtml.length;i++){
                        if(timezone==vm.timezoneHtml[i].value){
                            vm.timezoneValue = vm.timezoneHtml[i].name
                        }
                    }
                    vm.timeValue = timezone;
                }
            });

        },
        getTime: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SET_DATETIME,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    vm.lblTimeText = data.systime;
                }
            });
        },
        btnSave: function () {
            var $form = $('#form1');
            // if(!CheckUtil.checkForm($form, rules, messages)){
            //     return false;
            // }

            fyAlertMsgLoading();
            var json = JSON.parmsToJSON($form);
            json.timezone = this.timeValue
            json.method = JSONMethod.POST;
            json.cmd = RequestCmd.SET_DATETIME;

            try {
                var theDateTime = json.datetime;
                var datetime = theDateTime.replace(/[\-|\:|\s]/g, "");
                json.datetime = datetime.slice(4) + datetime.substring(0, 4);

                Page.postJSON({
                    $id: $btnSave,
                    json: json,
                    success: function (data) {
                        $('#lblTime').text(theDateTime + ":00");
                        if (data.success == true) {
                            setTimeout(function(){
                                vm.getTime();
                                fyAlertMsgSuccess();
                            },1000);
                        } else {
                            fyAlertMsgFail()
                        }
                    }
                });
            } catch (ex) {
                AlertUtil.alertMsg(CHECK.format.systemTime);
            }
        },
        autoTimeClick: function () {
            this.datetimeValue = this.getDateTime()
        }
    },
    mounted: function () {
        this.datetimeValue = this.getDateTime();
        this.getData();
        Page.timer = setInterval(function () {
            vm.getTime();
        }, 1000);
    }
});