var AlertUtil = {
	alertMsg: function (msg) {
		unFocus();
		if (typeof Page !== 'undefined' && Page.language && Page.language !== 'CN') {
			var isId = Page.language === 'IN';
			var dict = {
				"发送成功": isId ? "Berhasil Terkirim" : "Send Success",
				"发送失败": isId ? "Gagal Mengirim" : "Send Failed",
				"删除成功": isId ? "Berhasil Dihapus" : "Delete Success",
				"删除失败": isId ? "Gagal Menghapus" : "Delete Failed",
				"保存成功": isId ? "Berhasil Disimpan" : "Save Success",
				"保存失败": isId ? "Gagal Menyimpan" : "Save Failed",
				"操作成功": isId ? "Operasi Berhasil" : "Operation Success",
				"操作失败": isId ? "Operasi Gagal" : "Operation Failed"
			};
			if (dict[msg]) {
				msg = dict[msg];
			}
		}
		alert(msg);
	},
	confirm: function (msg) {
		unFocus();
		return confirm(msg);
	}
};
var ProgressTime = {
	REBOOT: 120,
	FIND_AP: 15,
	UPDATE_UBOOT: 10,
	UPDATE_PARTIAL: 150,
	UPLOAD_FILE: 3,
	SEARCH_PLMN: 120,
	UPGRADE_CHECK: 60,
	REMOTE_UPGRADE: 240
};

var RequestCmd = {
	SYS_INFO: 0,
	WIRELESS_INFO: 1,

	WIRELESS_CONFIG: 2,
	NETWORK_CONFIG: 3,
	USER_INFO: 4,
	SYS_UPDATE: 5,
	SYS_REBOOT: 6,
	PING_TEST: 7,
	WIRELESS_CONFIG_ADVANCED: 8,

	BASIC_CONFIG: 9,
	FIREWALL: 10,

	SET_DATETIME: 11,
	SMS_INFO: 12,
	SMS_SEND: 13,
	SMS_DELETE: 14,
	SMS_DELETE_ALL: 15,

	SYS_HELPER: 16,
	SYS_LOG: 17,
	FLOW_INFO: 18,
	MODULE_LOG: 19,

	APPLY_FILTER: 20,
	PORT_FILTER: 21,
	IP_FILTER: 22,
	MAC_FILTER: 23,
	IP_MAC_BINDING: 24,
	SPEED_LIMIT: 25,
	URL_FILTER: 26,
	OTHER_FILTER: 27,
	DEFAULT_FILTER: 28,
	URL_DEFAULT_FILTER: 29,
	MAC_DEFAULT_FILTER: 30,
	FIRWALL_ACL_FILTER: 31,
	IP_PORT_FILTER: 32,
	FIRWALL_UPNP: 33,
	CLEAN_ALL_FILTER: 39,

	DM_CONFIG: 40,
	MTU_CONFIG: 41,
	WATCHDOG_CONFIG: 42,

	DEVICE_VERSION_INFO: 43,

	LTE_LOG_CONFIG: 44,

	LTE_AT: 45,

	EXE_CMD: 46,
	SYSLOG_FUNCTION_CONFIG: 47,

	NET_CONNECT: 48,
	NET_DISCONNECT: 49,
	GET_HTML: 50,
	MODEM_CMD: 51,
	GET_DHTML: 52,
	FAST_SET_WIFI: 53,

	INIT_PAGE: 80,
	SET_ANTENNA: 81,
	GET_LTE_STATUS: 82,
	ARP_BINDING: 83,

	CHANGE_LANGUAGE: 97,
	CHANGE_USERNAME: 98,
	REBOOT: 99,
	LOGIN: 100,
	LOGOUT: 101,
	CHANGE_PASSWD: 102,
	FIND_AP: 103,
	GET_DEVICE_NAME: 104,
	UPDATE_UBOOT: 105,
	UPDATE_PARTIAL: 106,

	BRIDGED_INFO: 107,
	NAT_INFO: 108,
	GET_SPEED_MODE: 109,

	GET_MTU: 110,
	GET_CFG_FILENAMES: 111,
	RESTORE_DEFAULT: 112,

	GET_SYS_STATUS: 113,
	GET_PLMN_NUMBERS: 114,
	STATIC_LEASE: 115,
	SEARCH_PLMN: 116,
	MAC_CONTROL_INFO: 117,
	IPV6_CONFIG: 118,
	DIAL_CONFIG: 119,

	FIND_CLIENT_LIST_WLAN: 120,
	FIND_CLIENT_LIST_DUM: 121,
	FIND_CLIENT_LIST_CLIENT: 122,

	GET_SMS_STATUS_REPORT: 125,
	SET_SMS_STATUS_REPORT: 126,

	APN_LIST: 130,
	IMSI_PREFIX_LIST: 131,
	WPS_CONFIG: 132,
	ROUTER_INFO: 133,
	QUERY_SIM_STATUS: 134,

	GET_SUPPORT_BANDS: 157,
	SYS_REBOOT_PAGE: 159,
	LOCK_PHY_CELL: 160,
	LOCK_BAND: 161,
	LOCK_ONE_CELL: 162,

	BACKUP_FIREWALL: 163,
	ROUTER_TABLE: 164,
	ROUTER_MODE: 165,
	TR069_REG: 166,
	PPTP_VPN: 167,
	NETWORK_TOOLS: 168,
	DDNS: 169,
	WRITE_TIME: 170,
	ART_CHECK: 171,
	NETWORK_SERVICE: 172,
	GRE_VPN: 135,
	GET_SERVER_INFO: 173,
	LAN_SPEED_LIMIT: 174,
	DNS_CONFIG: 175,
	LNS_LIST: 176,
	GET_ART: 177,
	UPDATE_ART: 178,

	SYS_FILE_INFO: 179,
	CONFIG_EXPORT: 180,
	SIM_LOCKING: 181,

	CLOSE_MANAGE: 182,
	PPPOE_LOG: 183,
	CONFIG_UPDATE: 184,
	GET_PPPOE_LIST: 185,
	LTE_AT_ARRAY: 186,
	LTE_AT_P500: 187,
	FLOW_STATISTICS_SWITCH: 188,
	L2TP_DIAL_STATE_CHECK: 189,
	SYS_FILE_CHECK: 190,
	BACKUP_ART: 191,
	CHECK_BACKUP_ART: 192,
	IS_RUKU_VERSION: 193,
	UPLOAD_MODULE: 194,
	GET_UPLOAD_MODULE_RESULT_CODE: 195,

	ONLINE_UPGRADE_AUTO: 196,
	GET_UPGRADE_RESULT_CODE: 197,
	REMOTE_UPGRADE: 198,

	CONFIG_LOADER: 199,

	WRITE_FLASH: 200,
	EARFCNPCILOCK: 201,
	UPNP: 202,
	FLOW_MONITORING: 203,
	GET_FILE_DATA: 204,
	SYS_INFO_NETWORK: 205,
	WAN_INFO: 206,
	DEVICE_INFO: 207,
	LAN_INFO: 208,
	WIFI_INFO: 209,
	WIFI5G_INFO: 210,
	WIRELESS5G_CONFIG: 211,
	TR069_CONFIG: 212,
	APN_CONFIG: 213,
	GET_DMZ: 214,
	FW_UPNP: 215,
	STATIC_ARP_BINDING: 216,
	ACL_FILTER: 217,
	NETWORKSET_MODE: 218,
	LOCK_PLMN: 219,
	DATA_ROAMING: 220,
	DDNS_DATA: 221,
	AUTO_DIAL: 222,
	DHCPCLIENT_INFO: 223,
	WIFI24G_LIST_INFO: 224,
	WIFI5G_LIST_INFO: 225,
	FLIGHT_MODE_INFO: 226,
	DATA_SWITCH: 227,
	SCCAN_PLMN: 228,
	INPUT_8198D_LOGIN: 229,
	WIRELESS_ADVANCE: 230,
	WIRELESS5G_ADVANCE: 231,
	GET_NEXT_LOGIN_TIME: 232,
	RESET_LOGIN_TIME: 233,
	SYS_SERVICE_SET: 234,
	DISPLAY_SOLUTION_MODE: 235,
	MODEM_LOG_SWITCH: 236,
	ADB_SWITCH: 237,
	DETECTION_VERSION_INFO: 238,
	UPGRADE_IMMEDIATELY: 239,
	SYS_AUTO_UPGRADE: 240,
	EXPORT_LOG: 241,
	WLAN_5G_TPC: 242,
	WPS_PIN_CODE: 243,
	OPEN_RANDOM_PIN: 244,
	REMOTE_PACKET_CAPTURE: 245,
	CHANGE_CARD_TYPE: 246,
	GET_ESIM_INFO: 247,
	APN_INFO_PROCESS: 248,
	RESET_ESIM_INFO: 249,
	DOWNLOAD_ESIM_INFO: 250,
	IP_PASSTHROUGH: 251,
	ONENET_SETTING: 252,
	L2TP_SETTING: 253,
	SLICE_CONIFIG: 254,
	SFP_IPA_SETTING: 255,
	DM_SETTING: 257,
	SET_ARP_AGING: 258,
	PPTP_SETTING: 259,
	GRE_SETTING: 260,
	ESIM_URL_SETTING: 261,
	COMMLOG_BACKUP_TIME: 262,
	TIME_TO_RESTART: 263,
	LTE_CALIBRATION: 266,
	NR_CALIBRATION: 267,
	TR069_LOG_SWITCH: 268,
	SET_HASH: 269,
	SEND_AT: 270,
	TELECOM_DM: 271,
	VPN_CONFIG: 272,
	GET_ENDC_INFO: 273,
	GET_MOUNT_INFO: 274,
	DDOS_PROTECTION: 275,
	YOCTO_LOG_SWITCH: 276,
	NETWORKMODE_SWITCH: 277,
	WIRELESS_MACFILTER: 278,
	L2TPV3_CONFIG: 279,
	QoS_CONFIG: 280,
	IPSEC_CONFIG: 281,
	BROADBAND_SETTING: 302,
	WEB_LIST:323,
	GET_PING_LIST:324
};

var RENOOTTYPE = {
	NORMAL_REBOOT: 1,
	CONFIG_CHANGE: 2,
	RESTORE_SETTING: 3,
	RESTORE_REBOOT_CANCEL: 4,
	UPDATE_REBOOT: 5
};

var Url = {
	LOGIN: '/login.html',
	INDEX: '/index.html',
	PASSWD: '/html/changePasswd.html',
	DEFAULT_CGI: '/cgi-bin/http.cgi'
	// DEFAULT_CGI: 'http://192.168.0.1/cgi-bin/http.cgi'
	//DEFAULT_CGI: 'xml_action.cgi?method=set&module=duster&file=http'
};

var SmsType = {
	RECEIVE: 0,
	SEND: 1,
	DRAFT: 2
};

var MenuItem = {
	SYS_INFO: {
		cmd: RequestCmd.SYS_INFO,
		url: "html/info/sysInfo.html"
	},
	WAN_INFO: {
		cmd: RequestCmd.WAN_INFO,
		url: "html/info/wan_index.html"
	},
	DHCP_INFO: {
		cmd: RequestCmd.DHCP_INFO,
		url: "html/info/lan_index.html"
	},
	WIFI24G_INFO: {
		cmd: RequestCmd.WIFI_INFO,
		url: "html/info/wifi24g_index.html"
	},
	WIFI5G_INFO: {
		cmd: RequestCmd.WIFI_INFO,
		url: "html/info/wifi5g_index.html"
	},
	DEVICE_INFO: {
		cmd: RequestCmd.SYS_INFO,
		url: "html/info/deviceInfo.html"
	},
	CALIBRATION_INFO: {
		cmd: RequestCmd.LTE_CALIBRATION,
		url: "html/info/calibrationInfo.html"
	},

	DEMO_CONFIG: {
		cmd: RequestCmd.BASIC_CONFIG,
		url: "html/demo/demoIndex.html"
	},
	QUICK_SETTINGS: {
		cmd: RequestCmd.BASIC_CONFIG,
		url: "html/config/quickSettings.html"
	},
	BASIC_CONFIG: {
		cmd: RequestCmd.BASIC_CONFIG,
		url: "html/basic/basicConfig.html"
	},

	WIRELESS_CONFIG: {
		cmd: RequestCmd.WIRELESS_CONFIG,
		url: "html/config/wlan24gIndex.html"
	},
	WIRELESS_ADVANCE: {
		cmd: RequestCmd.WIRELESS_ADVANCE,
		url: "html/config/wlan24gAdvanceIndex.html"
	},
	WIRELESS5G_CONFIG: {
		cmd: RequestCmd.WIRELESS5G_CONFIG,
		url: "html/config/wlan5gIndex.html"
	},
	WIRELESS5G_ADVANCE: {
		cmd: RequestCmd.WIRELESS5G_ADVANCE,
		url: "html/config/wlan5gAdvanceIndex.html"
	},
	WPS_CONFIG: {
		cmd: RequestCmd.WPS_CONFIG,
		url: 'html/config/wirelessWpsSettingIndex.html'
	},
	WIRELESS_MACFILTER: {
		cmd: RequestCmd.WIRELESS_MACFILTER,
		url: 'html/config/wifiListIndex.html'
	},
	NETWORK_CONFIG: {
		cmd: RequestCmd.NETWORK_CONFIG,
		url: "html/config/dhcpIndex.html"
	},
	ROUTER_TABLE: {
		cmd: RequestCmd.ROUTER_TABLE,
		url: "html/advance/routeIndex.html"
	},
	IP_PASSTHROUGH: {
		cmd: RequestCmd.IP_PASSTHROUGH,
		url: "html/advance/ipPassIndex.html"
	},
	APN_CONFIG: {
		cmd: RequestCmd.APN_CONFIG,
		url: "html/config/apnConfigIndex.html"
	},
	PIN_CONFIG: {
		cmd: RequestCmd.WAN_INFO,
		url: "html/advance/pinSetIndex.html"
	},
	ESIM_MANAGE: {
		cmd: RequestCmd.WAN_INFO,
		url: "html/advance/esimIndex.html"
	},
	DISPLAY_SOLUTION_MODE: {
		cmd: RequestCmd.DISPLAY_SOLUTION_MODE,
		url: "html/advance/displaySolutionModeIndex.html"
	},
	SLICE_CONIFIG: {
		cmd: RequestCmd.SLICE_CONIFIG,
		url: "html/advance/sliceConfigurationIndex.html"
	},
	NETWORK_SET: {
		cmd: RequestCmd.WAN_INFO,
		url: "html/advance/networkSetIndex.html"
	},
	IPV6_CONFIG: {
		cmd: RequestCmd.IPV6_CONFIG,
		url: "html/config/ipv6Config.html"
	},
	DIAL_CONFIG: {
		cmd: RequestCmd.DIAL_CONFIG,
		url: "html/config/dialConfig.html"
	},
	LAN_SPEED_LIMIT: {
		cmd: RequestCmd.LAN_SPEED_LIMIT,
		url: "html/config/lanConfig.html"
	},
	NETWORK_SERVICE: {
		cmd: RequestCmd.NETWORK_SERVICE,
		url: "html/config/networkServiceConfig.html"
	},
	GRE_VPN: {
		cmd: RequestCmd.GRE_VPN,
		url: "html/config/greVpn.html"
	},
	DDNS_CONFIG: {
		cmd: RequestCmd.NETWORK_SERVICE,
		url: "html/ddns/ddnsIndex.html"
	},
	PPTP_VPN: {
		cmd: RequestCmd.PPTP_VPN,
		url: "html/config/pptpVpn.html"
	},
	TR069_SETTING: {
		cmd: RequestCmd.TR069_CONFIG,
		url: "html/advance/tr069Index.html"
	},
	VPN_SETTING: {
		cmd: RequestCmd.L2TP_SETTING,
		url: "html/vpn/vpnIndex.html"
	},
	ONENET_SETTING: {
		cmd: RequestCmd.ONENET_SETTING,
		url: "html/advance/onenetIndex.html"
	},
	QoS_CONFIG: {
		cmd: RequestCmd.QoS_CONFIG,
		url: "html/advance/qosIndex.html"
	},
	ADVANCED_CONFIG: {
		cmd: RequestCmd.BASIC_CONFIG,
		url: "html/advance/advancedConfig.html"
	},
	DM_CONFIG: {
		cmd: RequestCmd.DM_CONFIG,
		url: "html/config/dmConfig.html"
	},
	LTE_LOG_CONFIG: {
		cmd: RequestCmd.LTE_LOG_CONFIG,
		url: "html/config/lteLogConfig.html"
	},
	LTE_LOCK_FREQUENCY: {
		cmd: RequestCmd.LTE_AT,
		url: "html/config/lteLockFrequencyConfig.html"
	},
	LTE_LOCK_FREQUENCY_P500: {
		cmd: RequestCmd.LTE_AT,
		url: "html/config/lteLockFrequencyConfigP500.html"
	},
	LTE_LOCK_FREQUENCY_SIM5360: {
		cmd: RequestCmd.LTE_AT,
		url: "html/config/lteLockFrequencyConfigSim5360.html"
	},
	LTE_LOCK_FREQUENCY_ZTE: {
		cmd: RequestCmd.LTE_AT,
		url: "html/config/lteLockFrequencyConfigZTE.html"
	},
	LTE_AT: {
		cmd: RequestCmd.LTE_AT,
		url: "html/config/lteATConfig.html"
	},
	SYSTEM_MANAGE: {
		cmd: RequestCmd.EXE_CMD,
		url: "html/manage/systemManage.html"
	},
	FW_RULE: {
		cmd: RequestCmd.PORT_FILTER,
		url: "html/firewall/ipFilterIndex.html"
	},
	URL_FILTER: {
		cmd: RequestCmd.URL_FILTER,
		url: "html/firewall/urlFilterIndex.html"
	},
	FW_MAC_FILTER: {
		cmd: RequestCmd.MAC_FILTER,
		url: "html/firewall/macIndex.html"
	},
	//FW_MAC_FILTER: { cmd: RequestCmd.MAC_FILTER, url: "html/firewall/firewall.html" },
	FW_IP_MAC_BINDING: {
		cmd: RequestCmd.IP_MAC_BINDING,
		url: "html/firewall/ipMacBindingIndex.html"
	},
	FW_URL_FILTER: {
		cmd: RequestCmd.URL_FILTER,
		url: "html/firewall/urlFilterIndex.html"
	},
	FW_PORT_MAPPING: {
		cmd: RequestCmd.OTHER_FILTER,
		url: "html/firewall/portMappingIndex.html"
	},
	FW_ACL_FILTER: {
		cmd: RequestCmd.ACL_FILTER,
		url: "html/firewall/aclFilterIndex.html"
	},
	FW_SPEED_LIMIT: {
		cmd: RequestCmd.SPEED_LIMIT,
		url: "html/firewall/speedLimitIndex.html"
	},
	STATIC_ARP_BINDING: {
		cmd: RequestCmd.STATIC_ARP_BINDING,
		url: "html/firewall/staticArpBindingIndex.html"
	},
	FW_UPNP: {
		cmd: RequestCmd.FW_UPNP,
		url: "html/firewall/upnpIndex.html"
	},
	FW_DMZ: {
		cmd: RequestCmd.GET_DMZ,
		url: "html/firewall/dmzIndex.html"
	},

	SMS_NEW: {
		cmd: RequestCmd.SMS_INFO,
		smsType: SmsType.SEND,
		title: MENU.sms.add,
		url: "html/sms/smsNew.html"
	},
	SMS_RECEIVE: {
		cmd: RequestCmd.SMS_INFO,
		smsType: SmsType.RECEIVE,
		title: MENU.sms.inbox,
		url: "html/sms/smsInfo.html"
	},
	SMS_SEND: {
		cmd: RequestCmd.SMS_INFO,
		smsType: SmsType.SEND,
		title: MENU.sms.outbox,
		url: "html/sms/smsInfo.html"
	},
	SMS_DRAFT: {
		cmd: RequestCmd.SMS_INFO,
		smsType: SmsType.DRAFT,
		title: MENU.sms.drafts,
		url: "html/sms/smsInfo.html"
	},

	SYS_SET: {
		cmd: RequestCmd.CHANGE_PASSWD,
		url: "html/sys/sysConfigIndex.html"
	},
	TIME_TO_RESTART: {
		cmd: RequestCmd.TIME_TO_RESTART,
		url: "html/sys/timeToRestart.html"
	},
	SYS_CHECK: {
		cmd: RequestCmd.SYS_INFO,
		url: "html/check/checkIndex.html"
	},
	SYS_HELPER: {
		cmd: RequestCmd.SYS_HELPER,
		url: "html/manage/sysHelper.html"
	},
	SYS_LOG: {
		cmd: RequestCmd.SYS_LOG,
		url: "html/manage/sysLog.html"
	},
	EXPORT_LOG: {
		cmd: RequestCmd.EXPORT_LOG,
		url: "html/manage/exportLog.html"
	},
	MODULE_LOG: {
		cmd: RequestCmd.MODULE_LOG,
		url: "html/manage/moduleLog.html"
	},

	SYS_UPDATE: {
		cmd: RequestCmd.SYS_UPDATE,
		url: "html/update/sysUpdate.html"
	},
	SYS_AUTO_UPGRADE: {
		cmd: RequestCmd.SYS_AUTO_UPGRADE,
		url: "html/update/sysAutoUpdate.html"
	},
	CONFIG_UPDATE: {
		cmd: RequestCmd.CONFIG_UPDATE,
		url: "html/update/configUpdate.html"
	},

	CHECKING_STATUS: {
		cmd: RequestCmd.LTE_AT,
		url: "html/manage/checkingStatus.html"
	},
	SYS_ART: {
		cmd: RequestCmd.BACKUP_ART,
		url: "html/manage/sysArt.html"
	},
	SYS_FILE_CHECK: {
		cmd: RequestCmd.SYS_FILE_CHECK,
		url: "html/manage/sysFileCheck.html"
	},
	SIM_LOCKING: {
		cmd: RequestCmd.SIM_LOCKING,
		url: "html/isp/ispConfig.html"
	},
	MODULE_UPDATE: {
		cmd: RequestCmd.UPLOAD_MODULE,
		url: "html/manage/moduleUpdate.html"
	},
	MODULE_UPDATE_ML7810: {
		cmd: RequestCmd.UPLOAD_MODULE,
		url: "html/manage/moduleUpdateML7810.html"
	},
	SYS_FILE_INFO: {
		cmd: RequestCmd.SYS_FILE_INFO,
		url: "html/manage/sysFileInfo.html"
	},
	SEND_AT: {
		cmd: RequestCmd.SEND_AT,
		url: "html/manage/sysAt.html"
	},
	NETWORK_TOOLS: {
		cmd: RequestCmd.NETWORK_TOOLS,
		url: "html/tools/toolsIndex.html"
	},
	SYS_REBOOT: {
		cmd: RequestCmd.SYS_REBOOT,
		url: ""
	},
	SYS_REBOOT_PAGE: {
		cmd: RequestCmd.SYS_REBOOT_PAGE,
		url: "html/manage/reboot.html"
	},
	DDOS_PROTECTION: {
		cmd: RequestCmd.DDOS_PROTECTION,
		url: "html/firewall/ddosIndex.html"
	},
	FIX_TTL: {
		cmd: RequestCmd.EXE_CMD,
		url: "html/sys/fixTtl.html"
	},
	CHANGE_IMEI: {
		cmd: RequestCmd.SEND_AT,
		url: "html/sys/changeImei.html"
	},
	ADB_TELNET: {
		cmd: 0,
		url: "html/sys/adbTelnet.html"
	},
	ABOUT_MOD: {
		cmd: 0,
		url: "html/sys/aboutMod.html"
	},
	LED_CONTROL: {
		cmd: 0,
		url: "html/sys/ledControl.html"
	},
	SPEED_LIMITER: {
		cmd: 0,
		url: "html/sys/limiter.html"
	},
	THEMES: {
		cmd: 0,
		url: "html/sys/themes.html"
	},
	UNINSTALLER: {
		cmd: 0,
		url: "html/sys/uninstaller.html"
	},
	SMS_MONITORING: {
		cmd: 0,
		url: "html/sys/smsMonitoring.html"
	}
};

var SortDirection = {
	ASC: "asc",
	DESC: "desc"
};

var UpdateType = {
	CLIENT: "CLIENT",
	SERVER: "SERVER"
};

var Network = {
	LAN: "LAN",
	WAN: "WAN"
};

var JSONMethod = {
	GET: "GET",
	POST: "POST"
};

var WlanPara = "";
$.getJSON("wlan_para.json?t=" + Math.floor(Math.random() * 10000000), function (result) {
	WlanPara = result;
});

var ConvertUtil = {
	ip4ToNum: function (ipStr) {
		var ips = this.ip4ToBytes(ipStr);
		var ip = "0x";
		var value, i;
		for (i = 0; i < 4; i++) {
			value = ips[i].toString(16);
			if (value.length == 1) {
				value = "0" + value;
			}
			ip += value;
		}

		return parseInt(ip, 16);
	},
	ip4ToBytes: function (ipStr) {
		var ips = ipStr.split(".");
		var length = ips.length;

		if (length != 4) {
			return null;
		}

		var temp, ip = [];
		for (var i = 0; i < length; i++) {
			temp = parseInt(ips[i], 10);
			if (isNaN(temp) || temp < 0 || temp > 255) {
				return null;
			}
			ip[i] = temp;
		}
		return ip;
	},
	parseSingalLevel: function (singalLevel) {
		var singalStd = [-94, -80, -75, -70, -65];
		var singalDesc = ["无信号", "非常差", "差", "一般", "好", "非常好"];
		var singalStdLength = singalStd.length;
		var singalLevelNum = parseInt(singalLevel, 10);
		var singalFlag = 1;
		if (!isNaN(singalLevelNum)) {
			if (singalLevelNum >= singalStd[singalStdLength - 1]) {
				singalFlag = singalStdLength;
			} else {
				for (var j = 0; j < singalStdLength; j++) {
					if (singalLevelNum < singalStd[j]) {
						singalFlag = j;
						break;
					}
				}
			}
		}
		return {
			level: singalFlag,
			desc: singalDesc[singalFlag]
		};
	},
	parseHex: function (hex) {
		if (!hex) return "0000";

		var bits = ['0000', '0001', '0010', '0011',
			'0100', '0101', '0110', '0111',
			'1000', '1001', '1010', '1011',
			'1100', '1101', '1110', '1111'
		];
		var sb = new StringBuilder();
		var length = hex.length;
		for (var i = 0, len = length; i < len; i++) {
			sb.append(bits[parseInt(hex.charAt(i), 16)]);
		}
		return sb.toString();
	},
	parseFindAp: function (datas, arrName) {
		var indexFlag = '"' + arrName + '":["';
		var index = datas.indexOf(indexFlag);
		if (index > 0) {
			var theData = datas.substring(index + indexFlag.length);
			index = theData.indexOf('"]');
			if (index > 0) {
				var arr = theData.substring(0, index).split('","');
				for (var i = 0; i < arr.length; i++) {
					arr[i] = arr[i].replaceQuote();
				}
				return arr;
			}
		}

		return [];
	},
	parseUptime: function (uptime, unit) {
		var runTime = "",
			runStatus = "";
		var uptimeReg = /^(.*)up(.*)\,\s*load\s*average\:(.*)$/;
		if (uptimeReg.test(uptime)) {
			runTime = RegExp.$2.replace('days', 'day').replace('day', unit.day).replace(':', unit.hour);
			if (runTime.indexOf('min') > 0) {
				runTime = runTime.replace('min', unit.min);
			} else {
				runTime = runTime + unit.min;
			}
			runStatus = RegExp.$3;
		}
		return {
			runTime: runTime,
			runStatus: runStatus
		};
	},
	parseUptime2: function (s) {
		var day = Math.floor(s / (24 * 3600)); // Math.floor()向下取整 
		var hour = Math.floor((s - day * 24 * 3600) / 3600);
		var minute = Math.floor((s - day * 24 * 3600 - hour * 3600) / 60);
		var second = s - day * 24 * 3600 - hour * 3600 - minute * 60;
		if (day > 0) {
			return day + DOC.unit.day + "," + hour + ":" + minute + ":" + second;
		} else {
			return hour + ":" + minute + ":" + second;
		}

	}
};

var SysUtil = {
	deviceName: null,
	rebootMessage: PROMPT.tips.rebootMessage,
	defaultRebootSettings: {
		rebootType: RENOOTTYPE.CONFIG_CHANGE,
		msg: PROMPT.saving.success,
		callback: null,
		hideConfirm: false
	},
	reboot: function (options) {
		var opts = $.extend({}, SysUtil.defaultRebootSettings, options);
		var msg = opts.msg.trim();
		var lastChar = msg.charAt(msg.length - 1);
		if (".,?!:;。？：！，；".indexOf(lastChar) < 0) {
			msg = msg + ', ';
		}
		SysUtil.rebootDevice(opts.rebootType, msg + SysUtil.rebootMessage, opts.callback, opts.hideConfirm);
	},
	reboot2: function (options) {
		var opts = $.extend({}, SysUtil.defaultRebootSettings, options);
		var msg = opts.msg.trim();
		var lastChar = msg.charAt(msg.length - 1);
		if (".,?!:;。？：！，；".indexOf(lastChar) < 0) {
			msg = msg + ', ';
		}
		SysUtil.rebootDevice2(opts.rebootType, msg + SysUtil.rebootMessage, opts.callback, opts.hideConfirm);
	},
	rebootDevice: function (rebootType, msg, callback, hideConfirm) {
		if (!rebootType) {
			rebootType = RENOOTTYPE.CONFIG_CHANGE;
		}

		if (!msg) msg = /*PROMPT.saving.success + */ this.rebootMessage;

		if (!hideConfirm) {
			fyConfirmMsg(msg, function () {
				if ($.isFunction(callback)) {
					callback(true);
				}
				fyAlertMsgLoading(PROMPT.status.rebooting + "," + CHECK.format.waiting);

				setTimeout(reboot, 3000);
				setTimeout(function () {
					location.reload();
				}, 120000);

				function reboot() {
					// 发送重启命令
					Page.postJSON({
						json: {
							cmd: RequestCmd.SYS_REBOOT,
							rebootType: rebootType,
							method: JSONMethod.POST
						},
						success: function () {}
					});
				}
			})
		}
	},
	rebootDevice2: function (rebootType, msg, callback, hideConfirm) {
		if (!rebootType) {
			rebootType = RENOOTTYPE.CONFIG_CHANGE;
		}

		if (!msg) msg = /*PROMPT.saving.success + */ this.rebootMessage;

		if (!hideConfirm) {
			if ($.isFunction(callback)) {
				callback(true);
			}
			fyAlertMsgLoading(PROMPT.status.rebooting + "," + CHECK.format.waiting);

			setTimeout(reboot, 3000);
			setTimeout(function () {
				location.reload();
			}, 120000);

			function reboot() {
				// 发送重启命令
				Page.postJSON({
					json: {
						cmd: RequestCmd.SYS_REBOOT,
						rebootType: rebootType,
						method: JSONMethod.POST
					},
					success: function () {}
				});
			}
		}
	},
	restoreRebootCancel: function () {
		Page.postJSON({
			json: {
				cmd: RequestCmd.SYS_REBOOT,
				rebootType: RENOOTTYPE.RESTORE_REBOOT_CANCEL,
				method: JSONMethod.POST
			},
			success: function () {}
		});
	},
	showProgress: function (seconds, message, checkStatus, callback) {
		var $mask = $('#mask'),
			$box = $('#progress_box');
		var $progress = $('#progress_status'),
			$info = $('#progress_info');
		var h = document.documentElement.clientHeight;
		var w = document.documentElement.clientWidth;
		$mask.height(h);
		$mask.show();
		$box.show();
		SysUtil.setBoxStyle($box, w, h);

		var count = 1,
			delayCount = 2,
			maxCount = seconds * 10,
			ratio;
		var width = $('#progress_bar').width();

		function loop() {
			if (checkStatus()) {
				count += parseInt((maxCount - count) / delayCount) + 1;
			} else {
				ratio = maxCount / count;
				if (ratio >= 3) count += 3;
				else if (ratio >= 2) count += 2;
				else if (ratio > 1 && maxCount - count > delayCount) count++;
			}
			if (count <= maxCount) {
				$info.text(message + DOC.comma + PROMPT.status.progress + " " + parseInt((100 * count) / maxCount) + "%");
				$progress.width(parseInt((width * count) / maxCount));
				setTimeout(loop, 250);
			} else {
				callback();
			}
		}

		loop();
	},
	showProgress_2: function (message, checkStatus, callback) {
		var $mask = $('#mask'),
			$box = $('#progress_box');
		var $progress = $('#progress_status'),
			$info = $('#progress_info');
		var h = document.documentElement.clientHeight;
		var w = document.documentElement.clientWidth;
		$mask.height(h);
		$mask.show();
		$box.show();
		SysUtil.setBoxStyle($box, w, h);

		var count = 0;
		var width = $('#progress_bar').width();

		function loop() {
			count = checkStatus();
			$info.text(message + DOC.comma + PROMPT.status.progress + " " + count + "%");
			$progress.width(parseInt((width * count) / 100));
			if (count < 100) {
				setTimeout(loop, 500);
			} else {
				callback();
			}
		}
		loop();
	},
	setBoxStyle: function ($box, w, h) {
		$box.css({
			"left": parseInt(((w || document.documentElement.clientWidth) - $box.width()) / 2, 10) + "px",
			"top": parseInt(((h || document.documentElement.clientHeight) - $box.height()) / 2, 10) + "px"
		});
	},
	parseJSON: function (data) {
		var index = data.indexOf("{");
		if (index < 0) return {};

		// 从大括号开始计算json起始位置
		if (index > 0) {
			data = data.substring(data.indexOf("{"));
		}
		return JSON.parse(data);
	},
	getModule: function () {
		if (Page.imei && Page.modelVersion != "" && Page.modelVersion != "NULL") return true;

		var count = 0;

		function loop() {
			Page.postJSON({
				json: {
					cmd: RequestCmd.DEVICE_VERSION_INFO
				},
				success: function (data) {
					Page.module = data.module;
					Page.modelVersion = data.modversion;
					Page.imei = data.imei;
					if (data.modversion == "" || data.modversion == "NULL" || count++ < 20) {
						setTimeout(loop, 10000);
					}
				}
			});
		}
		loop();

		return false;
	},
	saveGuideState: function (requiredSave) {
		if (!requiredSave) return;

		Page.postJSON({
			json: {
				cmd: RequestCmd.IS_RUKU_VERSION,
				method: 'SAVE',
				configGuide: 'yes'
			},
			success: function (data) {}
		});
	},
	processMsg: function (message) {
		if (message == "NO_AUTH") {
			AlertUtil.alertMsg(PROMPT.status.noAuth);
			location.href = Page.getUrl(Url.LOGIN);
		} else {
			AlertUtil.alertMsg(message);
		}
	},
	upload: function ($form, $file, command, callback) {
		var url = String.format("{0}?cmd={1}&method=POST&sessionId={2}&language={3}", Url.DEFAULT_CGI, RequestCmd.SYS_UPDATE, sessionStorage['sessionId'], Page.language);

		//var url = "xml_action.cgi?Action=Upload&file=upgrade&command=" + command;

		var datas = null;
		$form.ajaxSubmit({
			url: url,
			type: 'POST',
			dataType: 'json',
			beforeSubmit: function () {
				var updateFileName = $file.val();
				if (updateFileName.length == 0) {
					AlertUtil.alertMsg(CHECK.required.uploadFile);
					return false;
				}
				if (/[\\\/]/.test(updateFileName)) {
					var matchs = updateFileName.match(/(.*)?[\\\/](.*)/);
					updateFileName = matchs[2];
				}
				if (!confirm(PROMPT.confirm.uploadFile + updateFileName)) {
					callback("");
					return false;
				}
				SysUtil.showProgress(ProgressTime.UPLOAD_FILE, PROMPT.status.uploading,
					function () {
						return datas != null;
					},
					function () {
						if (datas.success) {
							AlertUtil.alertMsg(PROMPT.status.uploadSuccess);
						} else {
							if(typeof datas.message === 'object')
							{
								SysUtil.processMsg("Error");
							}else
							{
								SysUtil.processMsg(datas.message);
							}
							
						}
						if ($.isFunction(callback)) {
							callback(updateFileName);
						}
					}
				);
				return true;


			},
			success: function (data, statusText) {
				datas = data;
			},
			error: function (responseText, statusText) {
				datas = {
					success: false,
					message: responseText
				};
			}
		});
	}
};

var FormatUtil = {
	formatValue: function (value) {
		if (!value || value == "NULL") {
			return '';
		}
		return value;
	},
	formatField: function (value, unit) {
		if (unit) {
			unit = unit;
		} else {
			unit = "";
		}
		if (value == "NULL") {
			//isNULLToSpace设置为false 此模式可以取消，注意在各页面使用完后要恢复默认值
			if (Page.isNULLToSpace) {
				return '';
			}
			return String.format("<span class=\"fail\">{0}</span>", DOC.status.getFailed);
		} else {
			return String.format("{0}{1}", value, unit).replaceQuote();
		}
	},
	formatNetState: function (value) {
		if (!value || value.trim() == "" || value == "NULL") {
			return "-";
		}
		return this.formatField(value);
	},
	/*此函数为搜网时调用，不是显示系统状态时调用*/
	formatSingalLevel: function (singalLevel, encryptionKey, requiredTitle) {
		var isEncrypted = (!!encryptionKey && encryptionKey == "on");
		var singal = ConvertUtil.parseSingalLevel(singalLevel);
		var title = String.format("信号强度：{0} &nbsp; {1}", singal.desc, singal.level > 0 ? (isEncrypted ? "是否加密：已加密" : "是否加密：未加密") : "");
		return {
			isEncrypted: isEncrypted,
			text: String.format("<span class=\"singal singal{0}{1}\"{2}>{3}&nbsp;dBm</span>",
				singal.level, isEncrypted ? "_lock" : "",
				(requiredTitle || false) ? String.format(" title=\"{0}\"", title) : "",
				singalLevel),
			title: title
		};
	},
	KB: 1024,
	MB: 1024 * 1024,
	GB: 1024 * 1024 * 1024,
	formatByteSize: function (size) {
		if (size < this.KB) {
			return size + ' B';
		} else if (size < this.MB) {
			return (size / this.KB).toFixed(2) + ' KB';
		} else if (size < this.GB) {
			return (size / this.MB).toFixed(2) + ' MB';
		} else {
			return (size / this.GB).toFixed(2) + ' GB';
		}
	},
	formatMaskBit: function (mask) {
		var tmp = mask.split(".");
		var bit = 0;
		for (var i = 0; i < 4; i++) {
			if (tmp[i] === "0") {
				break;
			}
			switch (tmp[i]) {
				case '255':
					bit += 8;
					break;
				case '254':
					bit += 7;
					break;
				case '252':
					bit += 6;
					break;
				case '248':
					bit += 5;
					break;
				case '240':
					bit += 4;
					break;
				case '224':
					bit += 3;
					break;
				case '192':
					bit += 2;
					break;
				case '128':
					bit += 1;
					break;
				default:
					bit = 0;
			}
		}
		return bit;
	}
};

var Page = {
	isTest: false,
	isNULLToSpace: false,
	connectStatus: true,
	currentId: 0,
	sessionId: "",
	webPageFlag: "0",
	language: DOC.language || "CN",
	allLanguage: "",
	languageList: "110",
	timer: null,
	getHash: "",
	onenet: "0",
	dm_platform: "0",
	themeWeb:"main.css",
	getSupportlanguageList: [{
		value: "cn",
		name: "中文"
	}, {
		value: "en",
		name: "English"
	}, {
		value: "th",
		name: "ไทย"
	},{
    value:"in",
    name:"Indonesia"
  }], //cn,中文；en,英文；th，泰文；in:印尼语
	current_card_type: "0",
	esim_show: "0",
	iad_ready_status: "0",
  level: "3",
  wifiCountrySelect:"1", //wifi国家码是否禁用选择 0-是 1-否
	getLanguageList: function (language) {
		var theLanguageList = Page.languageList;
		var length = theLanguageList.length;
		if (length <= 0) return '';
		var requiredDefault = (theLanguageList.charAt(length - 1) == "1");
		var sb = new StringBuilder();
		var langs = all_supported_language_info;
		var defaultLang = language.toLowerCase();
		var allLang = '';
		$.each(langs, function (name, value) {
			allLang += name.toUpperCase() + ',';
			var offset = parseInt(value.bit_offset, 10);
			if (offset < length && theLanguageList.charAt(length - offset - 1) == "1") {
				if (name === defaultLang) {
					sb.append(String.format('<option value="{0}" selected="selected">{1}</option>', name.toUpperCase(), LANG[name]));
				} else {
					if (requiredDefault) {
						sb.append(String.format('<option value="{0}">{1}({2})</option>', name.toUpperCase(), LANG[name], LANG[name + '_' + defaultLang]));
					} else {
						sb.append(String.format('<option value="{0}">{1}</option>', name.toUpperCase(), LANG[name]));
					}
				}
			}
		});
		Page.allLanguage = allLang;

		return sb.toString();
	},
	changeLanguage: function ($languageSelect) {
		var languageSelect = $languageSelect.val();
		Page.postJSON({
			json: {
				cmd: RequestCmd.CHANGE_LANGUAGE,
				method: JSONMethod.POST,
				sessionId: "",
				languageSelect: languageSelect
			},
			success: function (data) {},
			complete: function () {
				var href = location.href;
				if (href.indexOf('#') > -1) {
					href = href.substring(0, href.indexOf('#'));
				}
				if (href.indexOf('?') > -1) {
					href = href.substring(0, href.indexOf('?'));
				}
				location.href = Page.getUrl(href);
			}
		});
	},
	requireChangeLang: function (language) {
		if (!Page.allLanguage) {
			Page.getLanguageList('CN');
		}
		return language.length > 0 && Page.allLanguage.indexOf(language) >= 0 && language != Page.language;
	},
	isChinese: function () {
		return Page.language == "CN";
	},
	alertTimes: 0,
	defaultAlertTimes: 100,
	$iframe: null,
	menuItem: null,
	module: "",
	itemHide: "0000",
	itemDisable: "0000",
	isItemHide: function (itemHideTable) {
		var itemHide = Page.itemHide;
		var lastIndex = itemHideTable.index;
		if (lastIndex >= itemHide.length) return itemHideTable.emptyHide;

		if (itemHide.charAt(itemHide.length - 1 - lastIndex) == itemHideTable.hideFlag)
			return true;
		else
			return false;
	},
	isSupported: function (lastIndex, supportFlag) {
		if (supportFlag) {
			var supported = Page.supported || "0000";
			if (lastIndex >= supported.length) return false;
			return supported.charAt(supported.length - 1 - lastIndex) == "1" ? true : false;
		} else {
			var unsupported = Page.unsupported || "0000";
			if (lastIndex >= unsupported.length) return true;
			return unsupported.charAt(unsupported.length - 1 - lastIndex) == "0" ? true : false;
		}
	},

	setMenu: function (id, itemHideTable) {
		if (Page.isItemHide(itemHideTable)) {
			$(id).detach();
		} else {
			$(id).show();
		}
	},
	parseHex: function (hex) {
		// 进制转换parseInt()函数有最大２的５３次方位限制
		if (!hex) return ['0000'];
		var bits = ['0000', '0001', '0010', '0011',
			'0100', '0101', '0110', '0111',
			'1000', '1001', '1010', '1011',
			'1100', '1101', '1110', '1111'
		];
		var arr = [];
		var length = hex.length;
		for (var i = 0, len = length; i < len; i++) {
			arr.push(bits[parseInt(hex.charAt(i), 16)]);
		}
		return arr;
	},
	parseHexPageHide: function (hex) {
		if (!hex) return ["00"];
		var bits = ["00", "01", "02", "03",
			"10", "11", "12", "13",
			"20", "21", "22", "23",
			"30", "31", "32", "33"
		];
		var arr = [];
		var length = hex.length;
		for (var i = 0, len = length; i < len; i++) {
			arr.push(bits[parseInt(hex.charAt(i), 16)]);
		}
		return arr.join("").split("").reverse();
	},
	pageHideCheck: function (index) {
		var arr = Page.webPageFlag;
		if (arr[index] == "1") {
			if (Page.level == "1" || Page.level == "2") {
				return true;
			} else {
				return false;
			}
		} else if (arr[index] == "2") {
			if (Page.level == "1" || Page.level == "2" || Page.level == "3") {
				return true;
			} else {
				return false;
			}
		} else if (arr[index] == "3") {
			return true;
		} else {
			if (Page.level == "1") {
				return true;
			} else {
				return false;
			}
		}
	},
	createForm: function (arr) {
		if (!arr) return;
		if (arr.length <= 0) return;
		var form = document.createElement("form");
		$(form).attr('id', arr[0]);
		$(form).appendTo('#' + arr[1]);
		$("#" + arr[2]).appendTo(form);
	},
	createForm2: function (arr) {
		if (!arr) return;
		if (arr.length <= 0) return;
		var form = document.createElement("form");
		$(form).attr('id', arr[0]);
		$(form).appendTo('#' + arr[1]);
		$("#" + arr[2]).appendTo(form);
	},
	initPage: function (isLogin) {
		var $header = $('#header');
		if (!Page.hasGetLogo) {
			Page.postJSON({
				json: {
					cmd: RequestCmd.INIT_PAGE
				},
				success: function (data) {
					Page.hasGetLogo = true;
					Page.enableChannelOneToFour = (data.channelOneToFour == "yes");
					Page.disableChannelEnds = (data.hideChannel12And13 == "yes");
					var logoPath = (data.web_logo_path || "").trim();
					if (logoPath != "NULL" && logoPath.length > 0) {
						var background = String.format("url(/images/{0})", logoPath);
						$header.css({
							"background-image": background,
							"background-repeat": "no-repeat",
							"background-position": "20px center"
						});
					} else {
						if (data.isLogoExists == "1") {
							$header.addClass("header_logo");
						} else {
							$header.addClass("header_default");
						}
					}
					if (data.deviceType == 'NULL') {
						data.deviceType = '';
					}
					Page.displayedVersion = data.displayedVersion;
					if (Page.displayedVersion == 'NULL') {
						Page.displayedVersion = '';
					}
				}
			});

			if (!isLogin) {
				Page.killSearchPlmn();
			}
		}
		var headerH = 68,
			footerH = 30;
		var w = Math.max(document.documentElement.clientWidth, 1000);
		var h = Math.max(document.documentElement.clientHeight - headerH - footerH, 450);
		$('#main').height(h);
		$('#left').height(h);
		$('#left_m').height(h - 30);

		var $right = $('#right');
		$right.css({
			"padding-top": "15px"
		});
		var left = $('#left').width() + 1;
		var right = w - left;
		$right.width(right);
		$right.height(h - 15);

		if (isLogin) {
			var left = (((w - 402) / 2) - 400);
			left = Math.max(left, 0);
			$('#login').css({
				"left": left + "px",
				"top": ((h - 302) / 2 - 50) + "px"
			});
			$('#check_box_left .check_info').css({
				"width": (right / 2 - 40) + "px"
			});
			$('#check_box_right .check_info').css({
				"width": (right / 2 - 30) + "px"
			});
			$('#device_check').css({
				"left": "20px",
				"width": (right - 40) + "px",
				"height": (h - 20) + "px"
			});
		} else {}

		$header.width(w);
		$('#footer').width(w);

		var $mask = $('#mask');
		if ($mask.is(":visible")) {
			$mask.width(document.documentElement.clientWidth);
			$mask.height(document.documentElement.clientHeight);
		}

		var $box = $('#info_box');
		if ($box.is(":visible")) {
			SysUtil.setBoxStyle($box, w, h);
		}

		$box = $('#progress_box');
		if ($box.is(":visible")) {
			SysUtil.setBoxStyle($box, w, h);
		}
	},
	setStripeTable: function (id) {
		var $tab = $(id || 'table.detail');
		$('tr:odd', $tab).addClass("odd");
		$('tr:even', $tab).addClass("even");
		// $('tr:first', $tab).removeClass("even");
	},
	getRandomParam: function () {
		return "_t=" + Math.floor(Math.random() * 10000000);
	},
	getUrl: function (url) {
		return String.format("{0}?{1}", url, Page.getRandomParam());
	},
	getHtml: function (url, subcmd, callback) {
		Page.postJSON({
			returnHtml: true,
			json: {
				cmd: RequestCmd.GET_HTML,
				url: url,
				subcmd: subcmd || 0
			},
			success: function (data) {
				if (data.indexOf('"message":"NO_AUTH"') > 0) {
					location.href = Page.getUrl(Url.LOGIN);
				} else {
					callback(data);
				}
			}
		});
	},
	getFileData: function (url, subcmd, callback) {
		Page.postJSON({
			returnHtml: true,
			json: {
				cmd: RequestCmd.GET_FILE_DATA,
				url: url,
				subcmd: subcmd || 0
			},
			success: function (data) {
				if (data.indexOf('"message":"NO_AUTH"') > 0) {
					location.href = Page.getUrl(Url.LOGIN);
				} else {
					callback(data);
				}
			}
		});
	},
	writeTime: function (subcmd) {
		Page.postJSON({
			json: {
				cmd: RequestCmd.WRITE_TIME,
				method: JSONMethod.POST,
				subcmd: subcmd,
				time: new Date().format('yyyy-mm-dd HH:MM')
			},
			success: function (data) {}
		});
	},
	postJSON: function (options, timeout) {
		var settings = $.extend({}, Page.defaultSetting, options);
		var json = settings.json;
		if (!json.method) {
			json.method = JSONMethod.GET;
		}

		if (!json.language) {
			json.language = Page.language;
		}
		if (!json.sessionId) {
			json.sessionId = sessionStorage['sessionId'] || "";

		}
		if (Page.isTest) {
			return;
		} else {
			var $id = settings.$id;
			if ($id) {
				$id.disable();
			}
			$.ajax({
				url: settings.url,
				type: 'POST',
				timeout: timeout || settings.timeout,
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(json),
				dataType: 'text',
				beforeSend: function (xhr) {
					//xhr.setRequestHeader("Authorization", 'Digest username="admin", realm="Highwmg", nonce="1000", uri="/cgi/xml_action.cgi", response="c4a96d6622ef9a7ec485afcdb82c4459", qop=auth, nc=00000015, cnonce="e7dace847a70f733"');
				},
				success: function (datas) {
					try {
						var data;
						if (json.cmd == RequestCmd.FIND_AP && datas.indexOf("ssids") > 0) {
							// 单独解析FIND_AP
							data = {};
							data.success = true;
							data.cmd = RequestCmd.FIND_AP;
							data.macs = ConvertUtil.parseFindAp(datas, "macs");
							data.ssids = ConvertUtil.parseFindAp(datas, "ssids");
							data.frequencys = ConvertUtil.parseFindAp(datas, "frequencys");
							data.singalLevels = ConvertUtil.parseFindAp(datas, "singalLevels");
							data.encryptionKeys = ConvertUtil.parseFindAp(datas, "encryptionKeys");
							data.encryptionModes = ConvertUtil.parseFindAp(datas, "encryptionModes");
							data.groupCiphers = ConvertUtil.parseFindAp(datas, "groupCiphers");
							data.pairwiseCiphers = ConvertUtil.parseFindAp(datas, "pairwiseCiphers");
							data.authenticationSuites = ConvertUtil.parseFindAp(datas, "authenticationSuites");
						} else {
							if (!settings.returnHtml) {
								data = SysUtil.parseJSON(datas);
							} else {
								// 返回HTML不用解析
								data = datas;
							}
						}
						Window.isOther = false;
						if (!settings.returnHtml) {
							if (data.cmd == undefined) return;

							if (data.success) {
								settings.success(data);
							} else {
								if (data.message == "NO_AUTH") {
									sessionStorage.clear();
									Window.isOther = true;
									if(!IsPC()){
										// location.href = Page.getUrl("/mobile_web/login.html");
									}else{
										// fyAlertMsgFail(PROMPT.status.linkTimeout,true);
										location.href = Page.getUrl(Url.LOGIN);
										// AlertUtil.alertMsg(PROMPT.status.loginTimeout)

									}
									
									return;
								}else if(data.message == "LOGIN_TIMEOUT"){
									sessionStorage.clear();
									Window.isOther = true;
									location.href = Page.getUrl(Url.LOGIN);
									AlertUtil.alertMsg(PROMPT.status.loginTimeout);
									return;
								}
								if ($.isFunction(settings.fail)) {
									settings.fail(data);
								} else {
									if (data.message)
										AlertUtil.alertMsg(data.message);
								}
							}
						} else {
							settings.success(data);
						}
					} catch (ex) {
						//AlertUtil.alertMsg("[EXCEPTION]" + ex.message);
					}
				},
				error: function (xhr, textStatus, error) {
					if ($.isFunction(settings.error)) {
						settings.error(xhr, textStatus, error);
					}
				},
				complete: function () {
					settings.complete();
					if ($id) {
						$id.enable();
					}
				}
			});
		}
	},
	defaultSetting: {
		url: Url.DEFAULT_CGI,
		timeout: 0,
		returnHtml: false,
		success: function () {},
		complete: function () {}
	},
	killSearchPlmn: function () {
		
	},
	setHash: function (hash) {
		var dataHash;
		Page.postJSON({
			json: {
				cmd: RequestCmd.SET_HASH,
				method: JSONMethod.POST,
				setHash: hash
			},
			success: function (data) {}
		});
	},
	getHash: function () {
		var dataHash;
		var json = {};
		json.cmd = RequestCmd.SET_HASH;
		json.method = JSONMethod.GET;
		json.sessionId = sessionStorage['sessionId'];
		$.ajax({
			url: Url.DEFAULT_CGI,
			type: 'POST',
			contentType: 'application/json; charset=UTF-8',
			data: JSON.stringify(json),
			dataType: 'text',
			async: false,
			success: function (data) {
				var datas = SysUtil.parseJSON(data);
				dataHash = datas.setHash;
			}
		})
		return dataHash;
	},
	destory: function () {
		Page.currentId++;
		if (Page.isSearchingPlmn) {
			Page.isSearchingPlmn = false;
			Page.killSearchPlmn();
		}
	},
	createTable: function (title, names, values, count, columnNum, css) {
		var sb = new StringBuilder();
		sb.append(Page.createTableHead(title, css));

		if (count <= 0 || columnNum <= 0) return sb.toString();

		Page.createTableBody(sb, names, values, count, columnNum, css);

		return sb.toString();
	},
	createTableHead: function (title, css) {
		if (!css) {
			css = "detail";
		} else {
			css = "detail " + css;
		}

		return String.format("<div class=\"{0}\">{1}</div>", css, title);
	},
	createTableBody: function (sb, names, values, count, columnNum, css) {
		if (!css) {
			css = "detail";
		} else {
			css = "detail " + css;
		}

		sb.append(String.format("<table class=\"{0}\" cellspacing=\"0\">", css));

		var columnCount = 0;
		var colon = (Page.isChinese() ? "：" : ":");
		for (var i = 0; i < count; i++) {
			if (i % columnNum == 0) {
				sb.append("<tr>");
			}

			// 输出th
			sb.append("<th>");
			if (!names[i]) {
				sb.append("&nbsp;</th>");
			} else {
				sb.append(names[i]);
				sb.append(colon);
				sb.append("</th>");
			}

			// 输出td
			var colspan = false;
			if (columnNum == 2 && (i + 1) < count && !names[i + 1]) {
				// colspan
				colspan = true;
				sb.append('<td colspan="3">');
			} else {
				sb.append("<td>");
			}
			if (values[i].length == 0) {
				sb.append("&nbsp;</td>");
			} else {
				sb.append(values[i]);
				sb.append("</td>");
			}

			columnCount++;
			if (colspan || columnCount == columnNum) {
				sb.append("</tr>");
				columnCount = 0;
			}
			if (colspan) {
				i++;
			}
		}
		if (columnCount != 0) {
			// 补充输出th,td
			for (var i = columnCount; i < columnNum; i++) {
				sb.append("<th>&nbsp;</th><td>&nbsp;</td>");
			}
			sb.append("</tr>");
		}
		sb.append("</table>");
	},
	sortAp: function (data, field, sortDirection) {
		var count = data.ssids.length;
		var ssids = data.ssids,
			macs = data.macs,
			frequencys = data.frequencys,
			singalLevels = data.singalLevels,
			encryptionKeys = data.encryptionKeys,
			encryptionModes = data.encryptionModes,
			groupCiphers = data.groupCiphers,
			pairwiseCiphers = data.pairwiseCiphers,
			authenticationSuites = data.authenticationSuites;

		for (var i = 0; i < count - 1; i++) {
			singalLevels[i] = parseInt(singalLevels[i], 10);
		}

		var fields = eval(field);
		var isAsc = (sortDirection == SortDirection.ASC);
		for (var i = 0; i < count - 1; i++) {
			for (var j = i + 1; j < count; j++) {
				if (isAsc) {
					if (fields[j] < fields[i]) {
						swapAll(i, j);
					}
				} else {
					if (fields[j] > fields[i]) {
						swapAll(i, j);
					}
				}
			}
		}

		var min;

		function swap(arr, i, j) {
			min = arr[j];
			arr[j] = arr[i];
			arr[i] = min;
		}

		function swapAll(i, j) {
			swap(ssids, i, j);
			swap(macs, i, j);
			swap(frequencys, i, j);
			swap(singalLevels, i, j);

			swap(encryptionKeys, i, j);
			swap(encryptionModes, i, j);
			swap(groupCiphers, i, j);
			swap(pairwiseCiphers, i, j);
			swap(authenticationSuites, i, j);
		}
	},
	getDeviceName: function () {
		Page.postJSON({
			json: {
				cmd: RequestCmd.GET_DEVICE_NAME,
				method: JSONMethod.GET,
				sessionId: ""
			},
			success: function () {},
		});
	},
	render: function (containerId, templateId, datas) {
		if (!containerId) containerId = '#child_container';
		if (!templateId) templateId = '#child_template';
		if (!datas) datas = DOC;

		$(containerId).html(_.template($(templateId).html(), datas));
	},
	applyFilter: function (flag) {
    if(!flag){
      flag = 0;
    }
		Page.postJSON({
			json: {
				cmd: RequestCmd.APPLY_FILTER,
				method: JSONMethod.POST
			},
			success: function (data) {
				if (data.success == true) {
          if(flag != 1){
					  fyAlertMsgSuccess();
          }
				} else {
					fyAlertMsgFail();
				}
			}
		});
	}
};

var CheckUtil = {
	isEmpty: function (value) {
		return !value || value.length == 0 || value == 'NULL';
	},
	checkIp: function (ip, ipType) {
		var ipv4 = /^((\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.){4}$/;
		var ipv6 = /^(?:(?:(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))|\[(?:(?:(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))\](?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/i
		if (ipType == "IPV4") {
			return ipv4.test(ip + ".");
		} else if (ipType == "IPV6") {
			return ipv6.test(ip + ":");
		} else {
			return ipv6.test(ip + ":") || ipv4.test(ip + ".");
		}
	},
	checkIpRange: function (ip, isIpv6) {
		if (isIpv6 != "IPV6") {
			var reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])((\/\d|\/1\d|\/2\d|\/3[0-2]){0,1}|((-)(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){0,1})$/;
			return reg.test(ip);
		} else {
			return (/::/g.test(ip) && ip.match(/::/g).length == 1 &&
					(/^([\da-f]{1,4}(:|::)){1,6}[\da-f]{1,4}$/i.test(ip) ||
						/^([\da-f]{1,4}(:|::)){1,6}[\da-f]{1,4}\/\d{1,3}$/i.test(ip) ||
						/^::[\da-f]{1,4}$/i.test(ip) ||
						/^::[\da-f]{1,4}\/\d{1,3}$/i.test(ip))) ||
				/^([\da-f]{1,4}:){7}[\da-f]{1,4}$/i.test(ip) ||
				/^([\da-f]{1,4}:){7}[\da-f]{1,4}\/\d{1,3}$/i.test(ip);
		}

	},
	checkMac: function (mac) {
		var reg = /^([0-9a-f]{2}[\:\-]{0,1}){5}[0-9a-f]{2}$/i;
		return reg.test(mac);
	},
	checkPort: function (port) {
		var thePort = parseInt(port, 10);
		if (isNaN(thePort) || thePort < 0 || thePort > 65535) return {
			isValid: false
		};
		return {
			isValid: true,
			port: thePort
		};
	},
	checkIpPort: function (ipPort) {
		var reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\:(\d+)$/;
		if (!reg.test(ipPort)) return false;
		var port = parseInt(RegExp.$5, 10);
		if (isNaN(port) || port < 0 || port > 65535) return false;
		return true;
	},
	checkNumber: function (num) {
		var reg = /^\d+$/;
		return reg.test(num);
	},
	checkHex: function (hex) {
		var reg = /^[0-9A-F]*$/gi;
		return reg.test(hex);
	},
	checkASCII: function (ascii) {
		var reg = /[\x00-\xff]/g;
		return reg.test(ascii);
	},
	checkAPNName: function (value) {
		var reg = /^[0-9a-zA-Z!#$&()*\+,\-\.\/%:;<=>?@\[\]^_\{|\}~ ]*$/;
		return reg.test(value);
	},
	checkForm: function ($form, rules, messages) {
		var validate = $form.validate({
			ignore: ".ignore",
			rules: rules,
			messages: messages
		});

		return validate.form();
	},
	checkPwd: function (pwd) {
		var asciiReg = /^[\x00-\xff]{8,63}$/;
		var hexReg = /^[0-9A-F]{64}$/;
		return asciiReg.test(pwd) || hexReg.test(pwd);
	},
	checkeWepPwd68: function (pwd) {
		var asciiReg = /^[\x00-\xff]{5}$/;
		var hexReg = /^[0-9A-F]{10}$/;
		return asciiReg.test(pwd) || hexReg.test(pwd);
	},
	checkeWepPwd128: function (pwd) {
		var asciiReg = /^[\x00-\xff]{13}$/;
		var hexReg = /^[0-9A-F]{26}$/;
		return asciiReg.test(pwd) || hexReg.test(pwd);
	},
	checkNetSegment: function (lanip, netMask, ip) {
		var lanips = ConvertUtil.ip4ToNum(lanip);
		var netMasks = ConvertUtil.ip4ToNum(netMask);
		var ips = ConvertUtil.ip4ToNum(ip);

		return (lanips & netMasks) == (ips & netMasks);
	},
	checkExeCmd: function (value) {
		var reg = /.*/;
		return reg.test(value);
	},
	checkPlmn: function (value) {
		var reg = /^[1-9][0-9]{4}/;
		return reg.test(value);
	},
	checkMask: function (value) {
		var reg = /^(254|252|248|240|224|192|128|0)\.0\.0\.0|255\.(254|252|248|240|224|192|128|0)\.0\.0|255\.255\.(254|252|248|240|224|192|128|0)\.0|255\.255\.255\.(255|254|252|248|240|224|192|128|0)$/;
		return reg.test(value);
	},
	checkRange: function (interval, min, max) {
		var key = parseInt(interval, 10);
		if (isNaN(key) || key < min || key > max) return false;
		return true;
	},
};

var CookieUtil = {
	getCookie: function (name) {
		var str = document.cookie;
		if (!str || str.indexOf(name + '=') < 0) {
			return;
		}
		var cookies = str.split(';');
		for (var i = 0; i < cookies.length; i++) {
			var cookie = cookies[i].trim();
			if (cookie.indexOf(name + '=') == 0) {
				return decodeURI(cookie.substring(name.length + 1));
			}
		}
	},
	setCookie: function (name, value, option) {
		var str = String.format("{0}={1}", name, encodeURI(value));

		if (option) {
			if (option.expireHours) {
				var date = new Date();
				date.setTime(date.getTime() + option.expireHours * 3600 * 1000);
				str += String.format("; expires={0}", date.toGMTString());
			}
			if (option.path) {
				str += String.format("; path={0}", option.path);
			}
			if (option.domain) {
				str += String.format("; domain={0}", option.domain);
			}
			if (option.secure) {
				str += '; true';
			}
		}

		document.cookie = str;
	},
	deleteCookie: function (name, option) {
		this.setCookie(name, '', option);
	}
};

var DivUtil = {
	showDiv: function ($id) {
		$id.width(document.documentElement.clientWidth);
		$id.height(document.documentElement.clientHeight);
		$id.show();
	},
	clearDiv: function ($id) {
		$id.html("");
		$id.hide();
	},
	moveEvent: function (e, $id) {
		var isIE = (document.all) ? true : false;
		var drag = true;
		var xPoint = isIE ? event.x : e.pageX;
		var yPoint = isIE ? event.y : e.pageY;
		offLeft = $id.offset().left;
		offTop = $id.offset().top;

		$(document).mousemove(function (e) {
			if (drag) {
				var x = isIE ? event.x : e.pageX;
				if (x < 200) {
					x = 200;
				}
				if (x > document.documentElement.clientWidth) {
					x = document.documentElement.clientWidth;
				}
				var y = isIE ? event.y : e.pageY;
				if (y < 100) {
					y = 100;
				}
				if (y > document.documentElement.clientHeight) {
					y = document.documentElement.clientHeight;
				}
				$id.css({
					'top': offTop - yPoint + y - 100 + 'px',
					'left': offLeft - xPoint + x - 200 + 'px'
				});
			}
		});
		$(document).mouseup(function () {
			drag = false;
		});
	}
};

var SmsUtil = {
	createTable: function (options) {
		var datas = options.datas,
			smsType = options.smsType;
		var beginIndex = options.pageIndex * options.pageSize;
		var lang = DOC.sms;

		var sb = new StringBuilder();
		sb.append('<table class="sms" cellspacing="0" cellpadding="0">');
		sb.append(String.format('<tr><th class="indexNo">{0}</th>', DOC.table.rowNo));
		sb.append(String.format('<th>{0}<input type="checkbox" id="chkAllSms" /></th>', lang.tab));

		var editText;
		if (smsType == SmsType.RECEIVE) {
			editText = lang.transmit;
			sb.append(String.format('<th>{0}</th>', lang.state));
			sb.append(String.format('<th>{0}</th>', lang.sender));
		} else {
			editText = DOC.table.edit;
			sb.append(String.format('<th>{0}</th>', lang.receiver));
		}
		sb.append(String.format('<th class="content">{0}</th><th>{1}</th>', lang.content, lang.time));
		if (smsType == SmsType.SEND) {
			sb.append(String.format('<th>{0}</th>', lang.sendState));
		}

		if (smsType == SmsType.RECEIVE) {
			sb.append(String.format('<th>{0}</th>', lang.reply));
		}

		sb.append(String.format('<th>{0}</th><th>{1}</th></tr>', editText, DOC.table.del));
		if (datas != null) {
			var length = datas.length;
			for (var i = 0; i < length; i++) {
				var item = datas[i];
				var id = beginIndex + i + 1;
				sb.append('<tr>');
				sb.append(String.format('<td class="indexNo">{0}', id));
				sb.append(String.format('<input id="hddSmsId{0}" type="hidden" value="{1}" /></td>', id, item.smsId));
				sb.append(String.format('<input id="hddSmsIndex{0}" type="hidden" value="{1}" /></td>', id, item.smsIndex));

				sb.append(String.format('<td><input id="chkSms{0}" type="checkbox" /></td>', id));
				if (smsType == SmsType.RECEIVE) {
					sb.append(String.format('<td>{0}</td>', item.status == 1 ? lang.read : ("<span style=\"color:red;\">" + lang.unread + "</span>")));
				}
				sb.append(String.format('<td id="phoneNo{0}">{1}</td>', id, item.phoneNo));
				sb.append(String.format('<td id="content{0}" class="content"><table class="content"><tr style="height:20px;display:none;"><tr><td>{1}</td></tr></table></td>', id, item.content));
				sb.append(String.format('<td>{0}</td>', item.datetime));
				if (smsType == SmsType.SEND) {
					if (item.status == 1)
						sb.append(String.format('<td class="ok">{0}</td>', lang.sendSuccess));
					else
						sb.append(String.format('<td class="fail">{0}</td>', lang.sendFailed));
				}
				if (smsType == SmsType.RECEIVE) {
					sb.append(String.format('<td><a id="reply{0}" class="edit" href="javascript:;">{1}</a></td>', id, lang.reply));
				}
				sb.append(String.format('<td><a id="edit{0}" class="edit" href="javascript:;">{1}</a></td>', id, editText));
				sb.append(String.format('<td><a id="del{0}" class="edit" href="javascript:;">{1}</a></td>', id, DOC.table.del));
				sb.append('</tr>');
			}
		}
		sb.append('</table>');

		$(options.id).html(sb.toString());
		Page.setStripeTable('table.sms');

		$('#chkAllSms').click(function () {
			var checked = $(this).prop('checked');
			$('input[id^=chkSms]').prop('checked', checked);
		});

		$('a[id^=edit]').click(function () {
			var id = this.id.slice(4);
			var phoneNo = (smsType == SmsType.RECEIVE) ? "" : $('#phoneNo' + id).text().trim();

			options.edit($('#hddSmsId' + id).val(), phoneNo, $('#content' + id).text().trim());
		});

		$('a[id^=reply]').click(function () {
			var id = this.id.slice(5);
			//var phoneNo = (smsType == SmsType.RECEIVE) ? "" : $('#phoneNo' + id).text().trim();
			var phoneNo = $('#phoneNo' + id).text().trim();
			options.edit("-1", phoneNo, "");
		});

		$('a[id^=del]').click(function () {
			var id = this.id.slice(3);
			options.del($('#hddSmsId' + id).val(), $('#hddSmsIndex' + id).val());
		});
	}
};

var StatusUtil = {
	formatSingalLevel: function (signalLevel, preCss, content) {
		var ddl = DOC.ddl;
		var signals = [ddl.signalLevelNone, ddl.signalLevel0, ddl.signalLevel1, ddl.signalLevel2, ddl.signalLevel3, ddl.signalLevel4, ddl.signalLevel5];
		var theSignalLevel = parseInt(signalLevel, 10);
		if (isNaN(theSignalLevel) || theSignalLevel > 5 || theSignalLevel < 0 || theSignalLevel == 0) {
			theSignalLevel = -1;
		}
		if (theSignalLevel == -1 && !!preCss) {
			theSignalLevel = 0
		}
		var title = DOC.lte.signalLevel + DOC.colon + signals[theSignalLevel + 1];

		return String.format("<div class=\"singal singal{0}\" title=\"{1}\">{2}</div>", theSignalLevel + 1, title, content || "");
	},
	// Map network_type_str ke label yang tampil di status bar (4G, 4G+, 3G, dll)
	getNetworkTypeDisplay: function(network_type_str) {
		var lblMap = {
			'LTE': '4G', 'LTE_CA': '4G+', 'LTE_CA_PLUS': '4G+',
			'4G': '4G', '4G+': '4G+',
			'NR': '5G', 'NR_CA': '5G+', 'ENDC': '5G',
			'WCDMA': '3G', 'HSPA': 'H+', 'HSDPA': 'H', 'HSUPA': 'H',
			'UMTS': '3G', 'EDGE': 'E', 'GPRS': 'G', 'GSM': 'G',
			'NO_SERVICE': '', 'NOSERVICE': '', 'LIMITED_SERVICE': 'L'
		};
		var label = lblMap[network_type_str] !== undefined
			? lblMap[network_type_str]
			: (network_type_str || '');
		return label;
	},
	formatAtAssert: function (assert, modem_at) {
		var assertImg = "",
			title = "";
		if (assert == "1" || modem_at == "1") {
			assertImg = "invalid";
			title = PROMPT.status.abnormal;
		} else {
			assertImg = "normal";
			title = PROMPT.status.normal;
		}
		return String.format("<div class=\"{0}\" title=\"{1}\">{2}</div>", assertImg, title, "AT");
	},
	formatSimInfo: function (state, type) {
		var theState = parseInt(state, 10);
		var title, css, codeType;
		if (type == "1") {
			codeType = "ESIM";
		} else {
			codeType = "SIM"
		}
		$('#simInfo').show();
		if (theState == 0) {
			css = "invalid";
			title = DOC.status.noSim;
		} else if (theState == 1) {
			css = "normal";
			title = DOC.status.existSim;
		} else {
			css = "invalid";
			title = DOC.status.noSim;
			$('#simInfo').hide();
		}

		return String.format("<div class=\"{0}\" title=\"{1}\">{2}</div>", css, title, codeType);
	},
	formatWiFiInfo: function (state) {
		var title, css;
		//alet(state);
		if (state == "0") {
			css = "unnormal";
			title = DOC.status.disabled;
		} else if (state == "part") {
			css = "partnormal";
			title = DOC.status.wifiPartEnabled;
		} else {
			css = "normal";
			title = DOC.status.enabled;
		}

		return String.format("<div class=\"{0}\" title=\"{1}\">2.4G Wi-Fi</div>", css, title);
	},
	format5gWiFiInfo: function (state) {
		var title, css;
		//alet(state);
		if (state == "0") {
			css = "unnormal";
			title = DOC.status.disabled;
		} else if (state == "part") {
			css = "partnormal";
			title = DOC.status.wifiPartEnabled;
		} else {
			css = "normal";
			title = DOC.status.enabled;
		}


		return String.format("<div class=\"{0}\" title=\"{1}\">5G Wi-Fi</div>", css, title);
	},
	formatLanWanInfo: function (lbl) {
		var toLower = lbl.toLowerCase();
		if (toLower == "lan4/wan") {
			toLower = "lan4";
		}
		var $id = "#" + toLower;
		var title, css;
		$($id).show();
		css = "link";
		title = DOC.status.connected;
		$($id).html(String.format("<div class=\"{0}\" title=\"{1}\">{2}</div>", css, title, lbl));
		// return ;
	},
	hasNewSmsPrompt: false,
	smsIntervalId: null,
	setSmsInfo: function (state) {
		var theState = parseInt(state, 10);
		var title, css;
		if (theState == 1) {
			css = "newsms";
			title = DOC.status.newMessage;
		} else {
			css = "normal";
			title = DOC.status.message;
		}

		function setHtml() {
			$('#smsInfo').html(String.format("<div class=\"{0}\" title=\"{1}\">{1}</div>", css, title));
		}

		function clearSmsInterval() {
			if (StatusUtil.smsIntervalId != null)
				clearInterval(StatusUtil.smsIntervalId);
		}

		if (theState == 1) {
			// 新消息是否已经提示
			if (!StatusUtil.hasNewSmsPrompt) {
				StatusUtil.hasNewSmsPrompt = true;

				var count = 0;
				StatusUtil.smsIntervalId = setInterval(function () {
					css = (count % 2 == 0) ? "newsms" : "newsms2";
					setHtml();
					if (count > 10) {
						clearSmsInterval();
					}
					count++;
				}, 500);
			}
		} else {
			StatusUtil.hasNewSmsPrompt = false;
			clearSmsInterval();
			setHtml();
		}
	},

	getSysStatus: function () {
		var sysStatus = null;

		function loop() {
			Page.postJSON({
				json: {
					cmd: RequestCmd.GET_SYS_STATUS,
					method: JSONMethod.GET,
					sessionId: ""
				},
				success: function (data) {
					sysStatus = data;
					sessionStorage.setItem("wlan2g_switch",sysStatus.wlan2g_switch_0);
					sessionStorage.setItem("wlan5g_switch",sysStatus.wlan5g_switch_0);
				},
				complete: function () {
					
					var wifi2gState, wifi5gState;
					// setTimeout(loop, 10000);
					var _time = setTimeout(function(){
						loop();
						clearTimeout(_time);
						_time = null;
					},10000);
					var netInfo;
					if (!!sysStatus.signal_lvl) {
						netInfo = StatusUtil.formatSingalLevel(sysStatus.signal_lvl, sysStatus.network_type_str, sysStatus.network_type_str);
					}
					sessionStorage["signal_lvl"] = parseInt(sysStatus.signal_lvl) || 0;
					sessionStorage["sim_info"] = sysStatus.sim_status == "1" ? 1 : 0;
					sessionStorage["equipment_model"] = sysStatus.board_type;
					if(sysStatus.flag == "ok")
					{
						$("#isShowRefresh").show();
					}else
					{
						$("#isShowRefresh").hide();
					}
					$('#netInfo').html(netInfo);
					$('#simInfo').html(StatusUtil.formatSimInfo(sysStatus.sim_status, sysStatus.current_card_type));
					// if (sysStatus.lock_puk_flag == "1") {
					// 	$("#simRemind").show();
					// 	$("#simRemind").html(PROMPT.status.simRemindPuk);
					// } else if (sysStatus.lock_pin_flag == "1") {
					// 	$("#simRemind").show();
					// 	$("#simRemind").html(PROMPT.status.simRemindPin);
					// } else 
					if (sysStatus.lock_device_flag == "1") {
						$("#simRemind").show();
						$("#simRemind").html(PROMPT.status.simRemindDevice);
					} else if (sysStatus.lock_plmn_flag == "1") {
						$("#simRemind").show();
						$("#simRemind").html(PROMPT.status.simRemindPlmn);
					} else if (sysStatus.roam_status == "1") {
						$("#simRemind").show();
						$("#simRemind").html(PROMPT.status.simRemindRoam);
					} else {
						$("#simRemind").hide();
					}
					if (sysStatus.wlan2g_switch == "1") {
						if (sysStatus.wlan2g_switch_0 == "1") {
							wifi2gState = "1";
						} else {
							wifi2gState = "0";
						}
					} else {
						wifi2gState = "0";
					}
					if (sysStatus.wlan5g_switch == "1") {
						if (sysStatus.wlan5g_switch_0 == "1") {
							wifi5gState = "1";
						} else {
							wifi5gState = "0";
						}
					} else {
						wifi5gState = "0";
					}
					var wiredLinkList = sysStatus.wired_link_list;
					if (wiredLinkList) {
						$("#lan1").hide();
						$("#lan2").hide();
						$("#lan3").hide();
						$("#lan4").hide();
						for (var i = 0; i < wiredLinkList.length; i++) {
							StatusUtil.formatLanWanInfo(wiredLinkList[i]);
						}
					}
					$('#wifiInfo').html(StatusUtil.formatWiFiInfo(wifi2gState));
					$('#wifiInfo5g').html(StatusUtil.format5gWiFiInfo(wifi5gState));
					$("#lteUsbInfo").html(StatusUtil.formatAtAssert(sysStatus.modem_assert, sysStatus.modem_at));
					if(sysStatus.data_switch == "1"){
						$("#dataSwitchOpen").show();
						$("#dataSwitchClose").hide();
					} else {
						$("#dataSwitchOpen").hide();
						$("#dataSwitchClose").show();
					}
				}
			});
		}

		loop();
	}
};

function getOpenInfo() {
	var loading = '-';
	var theRouterInfo = {},
		theLteInfo = {};
	Page.isNULLToSpace = true;
	var _sensitiveData = {};
	var _sensitiveVisible = {};

	function maskSensitiveValue(value) {
		if (!value || value === '-' || value === loading) return value;
		var str = String(value);
		if (str.length <= 4) return '••••';
		if (/^[0-9]+$/.test(str) && str.length >= 8) {
			return str.substring(0, 2) + '********' + str.substring(str.length - 2);
		}
		return str.substring(0, 2) + '********' + str.substring(str.length - 2);
	}

	function maskMac(value) {
		if (!value || value === '-' || value === loading) return value;
		var parts = String(value).split(':');
		if (parts.length === 6) {
			return parts[0] + ':' + parts[1] + ':**:**:' + parts[4] + ':' + parts[5];
		}
		return maskSensitiveValue(value);
	}

	function toggleSensitive(key, tableSelector) {
		_sensitiveVisible[key] = !_sensitiveVisible[key];
		var displayed = _sensitiveVisible[key] ? _sensitiveData[key] : maskSensitiveValue(_sensitiveData[key]);
		var cell = document.querySelector(tableSelector + ' td[data-sens-key="' + key + '"]');
		if (cell) {
			var valueSpan = cell.querySelector('.sens-value');
			var btn = cell.querySelector('.sens-toggle');
			if (valueSpan) valueSpan.textContent = displayed;
			if (btn) btn.textContent = _sensitiveVisible[key] ? 'HIDE' : 'SHOW';
		}
	}

	function injectSensitiveButtons(tableSelector) {
		var tables = document.querySelectorAll(tableSelector + ' table');
		if (!tables.length) return;

		var mapping = {
			'IMEI': true,
			'IMSI': true,
			'SN': true,
			'WAN MAC': true
		};

		var cells = document.querySelectorAll(tableSelector + ' td');
		cells.forEach(function(td) {
			if (td.querySelector('.sens-toggle')) return;
			var labelCell = td.previousElementSibling;
			if (!labelCell) return;
			var label = labelCell.textContent.trim().replace(/[:：\s]*$/, '');

			if (!mapping[label]) return;
			var key = tableSelector.replace('#', '') + '_' + label;
			if (typeof _sensitiveData[key] === 'undefined') return;

			td.setAttribute('data-sens-key', key);
			td.style.whiteSpace = 'nowrap';

			var valueSpan = td.querySelector('.sens-value');
			if (!valueSpan) {
				valueSpan = document.createElement('span');
				valueSpan.className = 'sens-value';
				valueSpan.textContent = _sensitiveVisible[key] ? _sensitiveData[key] : maskSensitiveValue(_sensitiveData[key]);
				td.textContent = '';
				td.appendChild(valueSpan);
			}

			var btn = document.createElement('span');
			btn.className = 'sens-toggle';
			btn.style.cssText = 'cursor:pointer; font-size:10px; margin-left:6px; color:#17a2b8; border:1px solid #17a2b8; padding:1px 5px; border-radius:3px; font-family:sans-serif; vertical-align:middle; user-select:none; display:inline-block;';
			btn.textContent = _sensitiveVisible[key] ? 'HIDE' : 'SHOW';
			btn.onclick = function(e) { e.stopPropagation(); toggleSensitive(key, tableSelector); };
			td.appendChild(btn);
		});
	}

	function createTable(routerInfo, lteInfo, noRefresh) {
		var supportedLte = true;
		var lte_info_id = '#lte_info';
		var wan_info_id = supportedLte ? '#wan_info' : '#wan_info2';
		var names = [],
			values = [];
		var lteNames = DOC.lte,
			netNames = DOC.net;
		var html;
		names.push(DOC.device.imsi);
		names.push(DOC.device.imei);
		names.push(lteNames.phyCellId);
		names.push(lteNames.sinr);
		names.push(lteNames.rsrp);
		names.push(lteNames.rssi);
		names.push(lteNames.freqPoint);
		names.push(lteNames.rsrq);
		names.push("SN");

		values.push(maskSensitiveValue(FormatUtil.formatField(routerInfo.IMSI || loading)));
		values.push(maskSensitiveValue(FormatUtil.formatField(routerInfo.module_imei || loading)));
		values.push((routerInfo.PCI || loading));
		values.push((routerInfo.SINR&&routerInfo.SINR!="-" ? (routerInfo.SINR + 'dB') : loading));
		values.push((routerInfo.RSRP ? (routerInfo.RSRP + 'dBm') : loading));
		values.push((routerInfo.RSSI ? FormatUtil.formatField(routerInfo.RSSI, 'dBm') : loading));
		values.push((routerInfo.FREQ ? routerInfo.FREQ : loading));
		values.push((routerInfo.RSRQ ? (routerInfo.RSRQ + 'dB') : loading));
		values.push(maskSensitiveValue(routerInfo.device_sn ? routerInfo.device_sn : loading));

		_sensitiveData['lte_info_IMSI'] = FormatUtil.formatField(routerInfo.IMSI || loading);
		_sensitiveData['lte_info_IMEI'] = FormatUtil.formatField(routerInfo.module_imei || loading);
		_sensitiveData['lte_info_SN'] = routerInfo.device_sn ? routerInfo.device_sn : loading;
		_sensitiveVisible['lte_info_IMSI'] = !!_sensitiveVisible['lte_info_IMSI'];
		_sensitiveVisible['lte_info_IMEI'] = !!_sensitiveVisible['lte_info_IMEI'];
		_sensitiveVisible['lte_info_SN'] = !!_sensitiveVisible['lte_info_SN'];

		html = Page.createTable(DOC.title.lteInfoBasic, names, values, names.length, 1, "detail2");
		$('#device_check').show();
		$(lte_info_id).html(html);
		Page.setStripeTable(lte_info_id);

		var names_route = [];
		names_route.push(DOC.lbl.runtime);
		names_route.push(DOC.device.firmwareVersion);


		var values_route = [];
		if (routerInfo.uptime) {
			values_route.push(ConvertUtil.parseUptime2(routerInfo.uptime) || loading);
		} else {
			values_route.push(loading);
		}
		if (routerInfo.fake_version) {
			values_route.push(FormatUtil.formatField(routerInfo.fake_version) || loading);
		} else {
			values_route.push(FormatUtil.formatField(loading));
		}
		sessionStorage["fake_version"] = routerInfo.fake_version || "1.0.0";
		sessionStorage["real_fwversion"] = routerInfo.real_fwversion || "1.0.0";

		html = Page.createTable(DOC.title.router, names_route, values_route, names_route.length, 1, "detail2");
		$('#router_info').html(html);
		Page.setStripeTable('#router_info');


		var names_wan = [];
		names_wan.push(netNames.ip);
		names_wan.push(DOC.device.wanMac);
		names_wan.push(netNames.dns1);
		names_wan.push(netNames.dns2);
		names_wan.push(netNames.ipv6);
		names_wan.push(netNames.dns3);
		names_wan.push(netNames.dns4);

		var values_wan = [];
		values_wan.push(FormatUtil.formatField(routerInfo.wan_ip || loading));
		values_wan.push(maskMac(FormatUtil.formatField(routerInfo.wan_mac || loading)));
		values_wan.push(FormatUtil.formatField(routerInfo.wan_dns || loading));
		values_wan.push(FormatUtil.formatField(routerInfo.wan_dns2 || loading));
		values_wan.push(FormatUtil.formatField(routerInfo.wan_ipv6_ip || loading));
		values_wan.push(FormatUtil.formatField(routerInfo.wan_ipv6_dns || loading));
		values_wan.push(FormatUtil.formatField(routerInfo.wan_ipv6_dns2 || loading));

		_sensitiveData['wan_info_WAN MAC'] = FormatUtil.formatField(routerInfo.wan_mac || loading);
		_sensitiveVisible['wan_info_WAN MAC'] = !!_sensitiveVisible['wan_info_WAN MAC'];

		html = Page.createTable(DOC.title.wan, names_wan, values_wan, names_wan.length, 1, "detail2");
		$(wan_info_id).html(html);
		Page.setStripeTable(wan_info_id);

		Vue.nextTick(function() {
			injectSensitiveButtons(lte_info_id);
			injectSensitiveButtons(wan_info_id);
		});




		setTimeout(getRouterInfo, 10000);

	}

	var SEPARATOR = '$',
		FIELD_SEPARATOR = '@',
		SYSTEM_MODE = 'System Mode',
		OPERATION_MODE = 'Operation Mode',
		PLMN = 'MCC MNC',
		LAC_TAC = 'TAC/LAC',
		SERVING_CELLID = 'Serving CellID',
		PHYSICAL_CELLID = 'Physical CellID',
		CURRENT_BAND = 'Frequency Band',
		EARFCN = 'EARFCN/ARFCN',
		DOWNLINK_BANDWIDTH = 'Downlink Bandwidth',
		UPLINK_BANDWIDTH = 'Uplink Bandwidth',
		RSRQ = 'RSRQ',
		RSRP = 'RSRP',
		RSRP2 = 'RSRP2',
		RSSI = 'RSSI',
		RSSI2 = 'RSSI2',
		SINR = 'SINR',
		SINR2 = 'SINR2',
		TZTRANSMODE = 'TZTRANSMODE',
		TZTA = 'TZTA',
		TZTXPOWER = 'TZTXPOWER';

	function getLteInfo(routerInfo) {
		Page.isOpenPage = true;
		Page.getHtml(MenuItem.CLIENT_LIST.url, MenuItem.CLIENT_LIST.cmd, function (data) {
			$('#client_info_hidden').html(data);
		});

		Page.postJSON({
			json: {
				method: JSONMethod.POST,
				cmd: RequestCmd.GET_LTE_STATUS
			},
			success: function (data) {
				var lteInfo = {};
				var phyCellId = '';
				var items = data.message.split(SEPARATOR);
				for (var i = 0; i < items.length; i++) {
					var item = items[i].split(FIELD_SEPARATOR);
					if (item.length == 2) {
						switch (item[0]) {
							case EARFCN:
								lteInfo.freq = item[1];
								break;
							case CURRENT_BAND:
								lteInfo.band = item[1];
								break;
							case RSRP:
								lteInfo.rsrp = item[1];
								break;
							case RSRP2:
								lteInfo.rsrp2 = item[1];
								break;
							case RSRQ:
								lteInfo.rsrq = item[1];
								break;
							case SINR:
								lteInfo.sinr = item[1];
								break;
							case SINR2:
								lteInfo.sinr2 = item[1];
								break;
							case RSSI:
								lteInfo.rssi = item[1];
								break;
							case RSSI2:
								lteInfo.rssi2 = item[1];
								break;

							case SERVING_CELLID:
								phyCellId = parseInt(item[1], 10);
								if (!isNaN(phyCellId)) {
									lteInfo.globalCellId = phyCellId.toString(16).toUpperCase();
									Page.cellId = phyCellId % 256;
									Page.enodeId = (phyCellId - Page.cellId) / 256;

									lteInfo.enodeBId = String.format('{0}/{1}', Page.enodeId, Page.cellId);
								} else {
									lteInfo.globalCellId = phyCellId;
									lteInfo.enodeBId = phyCellId;
								}
								break;

							case PHYSICAL_CELLID:
								lteInfo.phyCellId = item[1];
								break;

							case DOWNLINK_BANDWIDTH:
								lteInfo.bandWidth = item[1];
								break;
							case TZTRANSMODE:
								lteInfo.tm = item[1];
								break;
							case TZTA:
								lteInfo.tzta = item[1];
								break;
							case TZTXPOWER:
								lteInfo.txpower = item[1];
								break;

							default:
								break;
						}
					}
				}

				theLteInfo = lteInfo;
				createTable(routerInfo, lteInfo);
			},
			fail: function () {
				createTable(routerInfo, theLteInfo);
			},
			error: function () {
				createTable(routerInfo, theLteInfo);
			}
		});
	}

	function getRouterInfo() {
		Page.postJSON({
			json: {
				cmd: RequestCmd.ROUTER_INFO
			},
			success: function (routerInfo) {
				// save
				theRouterInfo = routerInfo;
				// getLteInfo(routerInfo);
				createTable(routerInfo, theLteInfo, true);
			},
			fail: function () {
				getLteInfo(theRouterInfo);
			},
			error: function () {
				getLteInfo(theRouterInfo);
			}
		});
	}

	getRouterInfo();
	createTable(theRouterInfo, theLteInfo, true);
};

function MenuHead(css, text, bodys) {
	this.css = css;
	this.text = text;
	this.bodys = [];
}

MenuHead.prototype.push = function (body, itemHide, itemSupported, supportFlag) {
	this.bodys.push(body);
}

function MenuBody(id, text) {
	this.id = id;
	this.text = text;
}

var MenuUtil = {
	create: function (menus) {
		var sb = new StringBuilder();
		var menu, body, bodys;
		for (var i = 0, length = menus.length; i < length; i++) {
			menu = menus[i];
			sb.append(String.format('<h3 class="{0}">{1}</h3>', menu.css, menu.text));
			sb.append(String.format('<ul class="{0}">', menu.css));

			bodys = menu.bodys;
			for (var j = 0, max = bodys.length; j < max; j++) {
				body = bodys[j];
				sb.append(String.format('<li><a id="{0}">{1}</a></li>', body.id, body.text));
			}
			sb.append('</ul>');
		}
		return sb.toString();
	}
};

function secondMenuClick(items, id) {
	$('#detail_container').pannel({
		items: items,
		id: id,
		init: function ($lis) {
			var hashArr = window.location.hash.split("#");
			_clearInterval();
			if (hashArr.length > 2 && id == hashArr[1]) {
				$lis.eq(hashArr[2]).click();
			} else {
				$lis.eq(0).click();
			}
		}
	});
}

function resetTime() {
	Page.postJSON({
		json: {
			cmd: RequestCmd.RESET_LOGIN_TIME,
			method: JSONMethod.GET
		},
		success: function (data) {}
	})
}

function _clearInterval() {
	clearInterval(Page.timer);
	Page.timer = null;
}

//dialer 返回错误码来显示对应的文本提示
function errorCodeInfo(code) {
	var txt = "";
	switch (code) {
		case 500:
			txt = PROMPT.status.error500;
			break;
		case 501:
			txt = PROMPT.status.error501;
			break;
		case 502:
			txt = PROMPT.status.error502;
			break;
		case 503:
			txt = PROMPT.status.error503;
			break;
		case 504:
			txt = PROMPT.status.error504;
			break;
		case 505:
			txt = PROMPT.status.error505;
			break;
		case 506:
			txt = PROMPT.status.error506;
			break;
		case 507:
			txt = PROMPT.status.error507;
			break;
		default:
			txt = PROMPT.status.errorUnknow;
	}
	return txt;
}
// 添加弹框                
// title    :'提示',            //标题
//   icon     : '',
// content  : '',               //内容
// skin     : '',               //皮肤
// position : 'fixed',			//定位方式
// closeBtn : true,   			//是否显示关闭按钮
// type     : 1,      			//type=2 为iframe
// drag     : false,   			//是否开启拖动
// time     : 2000,   			//当无头或无底部按钮时自动关闭时间
// shadow   : [0.3,'#000'], 	//遮罩
// shadowClose : true,  		//是否点击遮罩关闭
// animateType : 0, 			// 0为默认动画 1为底部弹出 2为顶部弹出 3为左部弹出 4为右部弹出
// aniExtend: '',   			//例 css动画名 opacity
// area     : ['auto','auto'], 	//设置宽高
// minmax   : false,
// direction: ['center','center'], 	//方向 key1:right left center  key2: top bottom center
// btns     : {                   	//按钮组
//    /* '确定' : function(){},*/
// },
// success  : function(){},  //弹出后回调
// end      : function(){}   //关闭后回调

//加载中...
function fyAlertMsgLoading(msg) {
	unFocus();
	var message = "";
	if (msg) {
		message = msg;
	} else {
		message = CHECK.format.waiting;
	}
	fyAlert.alert({
		title: message,
		closeBtn: false,
		animateType: 2,
		shadowClose: false,
		area: ['400px', '150px'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: '<p style="text-align:center;"><img src="../images/loading.gif" style="margin:0 auto;"></p>' //$("#contentText"),    //内容
	})
}
//成功
function fyAlertMsgSuccess(msg) {
	unFocus();
	fyAlert.destory();
	var message = "";
	if (msg) {
		message = msg;
	} else {
		message = PROMPT.status.success;
	}
	fyAlert.alert({
		title: message,
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: '<p style="text-align:center"><img src="../images/success.png"></p>', //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})

}
//失败
function fyAlertMsgFail(msg, flag) {
	if (!flag) {
		fyAlert.destory();
	}
	var message = "";
	if (msg) {
		message = msg;
	} else {
		message = PROMPT.status.fail;
	}
	fyAlert.alert({
		title: message,
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: '<p style="text-align:center"><img src="../images/failure.png"></p>', //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})
}
//确认取消
function fyConfirmMsg2(msg, clearDestory) {
	if (clearDestory) {
		fyAlert.destory();
	}
	fyAlert.alert({
		title: DOC.lbl.prompt,
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: msg, //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})
}

function fyConfirmMsg(msg, callback) {
	fyAlert.alert({
		title: " ",
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: msg, //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
				callback();
			},
			delete: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})
}

//警告
function fyAlertMsgWarn(text, flag) {
	if (flag) {
		fyAlert.destory();
	}
	var content = '<p style="text-align:center;"><img src="../images/warning.png"></p>';
	if (!!text) {
		content = content + '<p style="overflow: hidden;max-height: 38px;text-align:center;">' + text + '</p>'
	}
	fyAlert.alert({
		title: PROMPT.status.warn,
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: content, //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})

}

//带文本的等待框
function fyAlertMsgLoadText(text) {
	var content = '<p style="text-align:center;"><img src="../images/loading.gif"></p>';
	if (!!text) {
		content = content + '<p style="overflow: hidden;max-height: 38px;text-align:center;">' + text + '</p>'
	}
	fyAlert.alert({
		title: CHECK.format.waiting,
		closeBtn: false,
		animateType: 0,
		shadowClose: false,
		area: ['400px', 'auto'],
		direction: ['center', 'center'],
		skin: 'fyAlert-green',
		content: content, //$("#contentText"),    //内容
		btns: { //按钮组
			btns: function (obj) { //翻译在js里面
				obj.destory(); //在页面上
			}
		}
	})

}

function fyAlertDestory() {
	fyAlert.destory();
}

function IsPC() {
	var userAgentInfo = navigator.userAgent;
	var Agents = ["Android", "iPhone",
		"SymbianOS", "Windows Phone",
		"iPad", "iPod"
	];
	var flag = true;
	for (var v = 0; v < Agents.length; v++) {
		if (userAgentInfo.indexOf(Agents[v]) > 0) {
			flag = false;
			break;
		}
	}
	return flag;
}
function utf16to8(str) {//wifi直连二维码
	var out, i, len, c;  
	out = "";  
	len = str.length;  
	for(i = 0; i < len; i++) {  
	c = str.charCodeAt(i);  
	if ((c >= 0x0001) && (c <= 0x007F)) {  
		out += str.charAt(i);  
	} else if (c > 0x07FF) {  
		out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));  
		out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));  
		out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));  
	} else {  
		out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));  
		out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));  
	}  
	}  
	return out;  
}
function unFocus() {
  // 用于强制失焦 => elementUI bug, 点击按钮后不失焦
  var button = document.createElement('button');
  button.style.position = 'fixed';
  button.style.opacity = 0;
  document.body.appendChild(button);
  button.focus();
  button.remove();
};