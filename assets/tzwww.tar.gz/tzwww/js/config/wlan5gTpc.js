/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-08-05 13:55:56
 * @,@LastEditTime: ,: 2021-08-05 13:56:32
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\config\wlan5gTpc.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            tpcSwitch: false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            wifi5gTpc: MENU.settingWifi.wifi5gTpc,
            save: DOC.btn.save,
            helps: [{
                title: wlan5ghtml.helper.tpcTitle,
                item: wlan5ghtml.helper.tpcItem
            }]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WLAN_5G_TPC
                    },
                    success: function (data) {
                        vm.tpcSwitch = data.tpcSwitch == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.tpcSwitch = this.tpcSwitch ? "1" : "0";
                json.cmd = RequestCmd.WLAN_5G_TPC;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            setTimeout(function () {
                                fyAlertMsgSuccess();
                            }, 6000);
                        } else {
                            setTimeout(function () {
                                fyAlertMsgFail();
                            }, 6000);
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })

});