$(document).ready(function () {
    var fm = ["childForm", "networkform1_template", "childFormId"];
    var form = networkconfightml.form1;
    var showText = networkconfightml.prompt;
    var $mask = $('#mask');
    var rules = {
        lanIp: {
            required: true,
            gateway: true
        },
        netMask: {
            required: true,
            subnetmask_check: true
        },
        ipBegin: {
            required: true,
            ipnozero: true,
            // dhcp_check: "start",
            // dhcpCompare: "#txtDhcpIpPoolEnd"
        },
        ipEnd: {
            required: true,
            ipnozero: true,
            // dhcp_check: "end",
            // dhcpCompare: "#txtDhcpIpPoolStart"
        },
        main_dns: {
            required: true,
            ip: true
        },
        vice_dns: {
            ip: true
        },
        expireTime: {
            required: true,
            digits: true,
            min: 1,
            max: 168
        }
    };
    var messages = {
        lanIp: {
            required: showText.ipCheckMsg1,
            gateway: showText.ipCheckMsg3
        },
        netMask: {
            required: CHECK.required.netmask,
            subnetmask_check: CHECK.required.netmaskCheck
        },
        ipBegin: {
            required: showText.ipCheckMsg1,
            ipnozero: showText.ipCheckMsg3,
            dhcp_check: CHECK.format.dhcpCheck
        },
        ipEnd: {
            required: showText.ipCheckMsg1,
            ipnozero: showText.ipCheckMsg3,
            dhcp_check: CHECK.format.dhcpCheck1
        },
        main_dns: {
            required: CHECK.format.dns2,
            ip: CHECK.format.dns
        },
        vice_dns: {
            ip: CHECK.format.dns
        },
        expireTime: {
            required: showText.timeCheckMsg1,
            digits: showText.timeCheckMsg2,
            min: showText.timeCheckMsg3,
            max: showText.timeCheckMsg4
        }
    };
    var vm_dhcp = new Vue({
        el: "#networkform1_template",
        data: {
            th1: form.th1,
            th2: form.th2,
            th3: form.th3,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            th6: form.th6,
            th7: form.th7,
            th4: form.th4,
            th5: form.th5,
            td5: form.td5,
            btnSave: form.btnSave,
            addMac: form.addMac,
            ipAddres: networkconfightml.form1.ipAddres,
            edit: networkconfightml.form1.edit,
            del: networkconfightml.form1.del,
            butAble: false,
            indexId: 0,
            IP: DOC.net.ip,
            colon: DOC.colon,
            exam: DOC.lbl.example,
            save: DOC.btn.save,
            mac: DOC.net.mac,
            close: DOC.btn.close,
            confirm: DOC.lbl.confirm,
            lanName: '',
            lanIp: '',
            preLanIp: '', //当LAN IP修改时，记录修改前的LAN IP值
            netMask: '',
            dhcpServer: false,
            main_dns: '',
            vice_dns: '',
            ipBegin: '',
            ipEnd: '',
            expireTime: '',
            reserveIpMacsList: [],
            notShowList: [],
            macListIp: '',
            macList: '',
            editBox: false,
            isAdd: false,
            isEdit: false,
            flag: "",
            saveAble: false,
            lanIp1: null,
            lanIp2: null,
            lanIp3: null,
            dhcp_ip_pre: '',
            isOpenDhcpServer: false,
            changeHref: false, //标识修改LAN IP后是否需要替换浏览器地址
            ipBand: [],
            list: [{
                title: networkconfightml.helper.title1,
                item: networkconfightml.helper.item1
            },
            {
                title: networkconfightml.helper.title2,
                item: networkconfightml.helper.item2
            },
            {
                title: networkconfightml.helper.title3,
                item: networkconfightml.helper.item3
            },
            {
                title: networkconfightml.helper.title4,
                item: networkconfightml.helper.item4
            },
            {
                title: networkconfightml.helper.title5,
                item: networkconfightml.helper.item5
            }
            ]
        },
        methods: {
            deleteAll: function () {
                if (!this.reserveIpMacsList.length) {
                    this.$message({
                        message: CHECK.tip.isDataNull,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules1, function () {
                    var json = {};
                    fyAlertMsgLoading();
                    json.datas = [];
                    json.method = JSONMethod.POST;
                    json.success = true;
                    json.cmd = RequestCmd.STATIC_LEASE;
                    Page.postJSON({
                        json: json,
                        success: function (data) {
                            vm_dhcp.butAble = false;
                            if (data.success == true) {
                                fyAlertMsgSuccess();
                                vm_dhcp.getDataMacIp();
                                // Page.postJSON({
                                //     json: {
                                //         cmd: RequestCmd.IP_MAC_BINDING,
                                //         method: JSONMethod.POST,
                                //         success: true,
                                //         datas: []
                                //     },
                                //     success: function (data) {
                                //         if (data.success == true) {
                                //             Page.postJSON({
                                //                 json: {
                                //                     cmd: RequestCmd.APPLY_FILTER,
                                //                     method: JSONMethod.POST
                                //                 },
                                //                 success: function (data) {
                                //                     if (data.success == true) {
                                //                         fyAlertMsgSuccess();
                                //                         vm_dhcp.getDataMacIp();
                                //                     } else {
                                //                         fyAlertMsgFail();
                                //                     }
                                //                 }
                                //             });
                                //         } else {
                                //             fyAlertMsgFail();
                                //         }
                                //     }
                                // });
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    })
                })
            },
            add_mac: function () {
                $mask.show();
                this.editBox = true;
                this.macListIp = '';
                this.macList = '';
                this.isAdd = true;
                this.isEdit = false;
            },
            btnClose: function () {
                $mask.hide();
                this.editBox = false;
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_CONFIG,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        if (window.location.hostname === data.lanIp) {
                            vm_dhcp.changeHref = true;
                        }
                        vm_dhcp.lanIp = data.lanIp;
                        vm_dhcp.netMask = data.netMask;
                        vm_dhcp.dhcpServer = data.dhcpServer == "1" ? true : false;
                        vm_dhcp.main_dns = data.main_dns;
                        vm_dhcp.vice_dns = data.vice_dns;
                        vm_dhcp.ipBegin = data.ipBegin;
                        vm_dhcp.ipEnd = data.ipEnd;
                        vm_dhcp.expireTime = data.expireTime.split("h")[0];
                        vm_dhcp.isOpenDhcpServer = data.dhcpServer == "1" ? true :
                            false;
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_MAC_BINDING,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm_dhcp.ipBand = data.datas;
                        }
                    }
                });
            },
            changeIp: function () {
                var reg = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/;
                if(!reg.test(this.lanIp) || this.lanIp === this.preLanIp){ // 当LAN IP格式校验不正确或LAN IP未修改时，联动参数不做处理
                    return false;
                }
                if(this.preLanIp === this.main_dns) { //如果修改LAN IP时，比较得出LAN IP与主DNS相同，则同时修改主DNS
                    this.main_dns = this.lanIp
                }
                var index = this.lanIp.lastIndexOf(".");
                this.ipBegin = this.lanIp.substr(0, index) + this.ipBegin.substr(this.ipBegin
                    .lastIndexOf("."));
                this.ipEnd = this.lanIp.substr(0, index) + this.ipEnd.substr(this.ipEnd
                    .lastIndexOf("."));
            },
            clickBtnSave: function () {
                for(var i=0;i<this.reserveIpMacsList.length;i++){
                    if(this.lanIp == this.reserveIpMacsList[i].ip ){
                        AlertUtil.alertMsg(PROMPT.tips.dhcpLanIp1)
                        return ;
                    }
                }
                var $form = $("#childForm");
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    return;
                }
                var net = this.getNetworkBroadcastAddr(this.netMask, this.lanIp);
                if (this.lanIp == net[0] || this.lanIp == net[1]) {
                    this.$message({
                        message: DOC.apn.lanIpType + ":" + net[0] + "\\" + net[1],
                        type: 'warning',
                        offset: 200
                    });
                    return false;
                }
                if (vm_dhcp.dhcpServer) {
                    var ipBeginLast = this.ipChangeNum(this.ipBegin);
                    var ipEndLast = this.ipChangeNum(this.ipEnd);
                    if (ipEndLast < ipBeginLast) {
                        this.$message({
                            message: DOC.apn.ipRangeLimit,
                            type: 'warning',
                            offset: 200
                        });
                        return false;
                    }
                    var ipMIn = this.ipChangeNum(net[0]);
                    var ipMax = this.ipChangeNum(net[1]);
                    if (ipMax < ipBeginLast || ipBeginLast < ipMIn) {
                        this.$message({
                            message: DOC.apn.rule + ': [' +  net[0] + "-" + net[1] + ']',
                            type: 'warning',
                            offset: 200
                        });
                        return false;
                    }
                    if (ipMax < ipEndLast || ipEndLast < ipMIn) {
                        this.$message({
                            message: DOC.apn.rule + ': [' +  net[0] + "-" + net[1] + ']',
                            type: 'warning',
                            offset: 200
                        });
                        return false;
                    }
                    var lanIpLast = this.ipChangeNum(this.lanIp);
                    if (ipBeginLast <= lanIpLast && lanIpLast <= ipEndLast) {
                        this.$message({
                            message: DOC.apn.ipRange,
                            type: 'warning',
                            offset: 200
                        });
                        return false;
                    }
                }
                var json = {};
                json.lanIp = this.lanIp;
                json.netMask = this.netMask;
                json.dhcpServer = this.dhcpServer ? "1" : "0";
                if (this.dhcpServer) {
                    json.main_dns = this.main_dns;
                    json.vice_dns = this.vice_dns;
                    json.ipBegin = this.ipBegin;
                    json.ipEnd = this.ipEnd;
                    json.expireTime = this.expireTime + "h";
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORK_CONFIG;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.flag === '0') {
                            setTimeout(function () {
                                if (vm_dhcp.changeHref && json.lanIp !== window.location.hostname) {
                                    window.location.hostname = json.lanIp;
                                } else {
                                    window.location.reload();
                                }
                            }, 12000);
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });

            },
            saveListMacIp: function () {
                var json = {};
                fyAlertMsgLoading();
                json.datas = this.reserveIpMacsList;
                json.method = JSONMethod.POST;
                json.success = true;
                json.cmd = RequestCmd.STATIC_LEASE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm_dhcp.butAble = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                            // Page.postJSON({
                            //     json: {
                            //         cmd: RequestCmd.IP_MAC_BINDING,
                            //         method: JSONMethod.POST,
                            //         success: true,
                            //         datas: vm_dhcp.ipBand
                            //     },
                            //     success: function (data) {
                            //         if (data.success == true) {
                            //             Page.postJSON({
                            //                 json: {
                            //                     cmd: RequestCmd.APPLY_FILTER,
                            //                     method: JSONMethod.POST
                            //                 },
                            //                 success: function (data) {
                            //                     if (data.success == true) {
                            //                         fyAlertMsgSuccess();
                            //                     } else {
                            //                         fyAlertMsgFail();
                            //                     }
                            //                 }
                            //             });
                            //         } else {
                            //             fyAlertMsgFail();
                            //         }
                            //     }
                            // });
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            },
            getDataMacIp: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.STATIC_LEASE,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm_dhcp.reserveIpMacsList = data.datas;
                    }
                })
            },
            isAddSave: function () {
                var dataArr = {};
                if (!CheckUtil.checkIp(this.macListIp)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.macListIp == this.lanIp) {
                    AlertUtil.alertMsg(CHECK.format.lanIpSame);
                    return false;
                }
                if (!CheckUtil.checkMac(this.macList)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                this.macList = this.macList.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                var compare = this.sameData(this.macList, this.macListIp);
                if (!!compare) {
                    if (compare == "ip") {
                        AlertUtil.alertMsg(networkconfightml.prompt.ipCheckSame);
                    } else if (compare == "mac") {
                        AlertUtil.alertMsg(networkconfightml.prompt.macCheckSame);
                    }
                    return false;
                }
                var len = this.ipBand.length;
                var i = 0;
                for (i = 0; i < len; i++) {
                    if (this.ipBand[i].ip == this.macListIp && this.ipBand[i].mac.toLowerCase() == this.macList.toLowerCase()) {
                        i = -1;
                        break;
                    }
                }
                if (i === len) {
                    this.ipBand.push({
                        remark: "IP Reservation",
                        ip: this.macListIp,
                        enableRule: true,
                        ippro: "IPV4",
                        mac: this.macList,
                        flag: '1'
                    });
                }
                dataArr.ip = this.macListIp;
                dataArr.mac = this.macList;
                this.reserveIpMacsList.push(dataArr);
                $mask.hide();
                this.editBox = false;
            },
            isEditSave: function () {
                if (!CheckUtil.checkIp(this.macListIp)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.macListIp == this.lanIp) {
                    AlertUtil.alertMsg(CHECK.format.lanIpSame);
                    return false;
                }
                if (!CheckUtil.checkMac(this.macList)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                this.macList = this.macList.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                var compare = this.sameData(this.macList, this.macListIp, this.flag);
                if (!!compare) {
                    if (compare == "noChange") {
                        AlertUtil.alertMsg(networkconfightml.prompt.dataNoChang);
                    } else if (compare == "ip") {
                        AlertUtil.alertMsg(networkconfightml.prompt.ipCheckSame);
                    } else if (compare == "mac") {
                        AlertUtil.alertMsg(networkconfightml.prompt.macCheckSame);
                    }
                    return false;
                }
                var len = this.ipBand.length;
                var i = 0;
                for (i = 0; i < len; i++) {
                    if (this.ipBand[i].ip == this.macListIp && this.ipBand[i].mac.toLowerCase() == this.macList.toLowerCase()) {
                        i = -1;
                        break;
                    } else if (this.ipBand[i].ip == this.reserveIpMacsList[this.flag].ip && this.ipBand[i].mac.toLowerCase() == this.reserveIpMacsList[this.flag].mac.toLowerCase()) {
                        this.ipBand[i].ip = this.macListIp;
                        this.ipBand[i].mac = this.macList;
                        i = -1;
                        break;
                    }
                }
                if (i === len) {
                    this.ipBand.push({
                        remark: "IP Reservation",
                        ip: this.macListIp,
                        enableRule: true,
                        ippro: "IPV4",
                        mac: this.macList,
                        flag: '1'
                    });
                }
                this.reserveIpMacsList[this.flag].ip = this.macListIp;
                this.reserveIpMacsList[this.flag].mac = this.macList;
                $mask.hide();
                this.editBox = false;
            },
            clickEdit: function (item, index) {
                this.flag = index;
                this.isAdd = false;
                this.isEdit = true;
                this.macListIp = item.ip;
                this.macList = item.mac;
                this.editBox = true;
                $mask.show();
            },
            clickDel: function (item, index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    var tmp = vm_dhcp.reserveIpMacsList.splice(index, 1);
                    var len = vm_dhcp.ipBand.length;
                    var i = 0;
                    for (i = 0; i < len; i++) {
                        if (vm_dhcp.ipBand[i].ip == tmp[0].ip && vm_dhcp.ipBand[i].mac.toLowerCase() == tmp[0].mac.toLowerCase()) {
                            vm_dhcp.ipBand.splice(i, 1);
                            break;
                        }
                    }
                });
            },
            sameData: function (mac, ip, flagRow) {
                if (flagRow != undefined && (this.reserveIpMacsList[flagRow].mac.toLowerCase() == mac.toLowerCase()) && (this.reserveIpMacsList[flagRow].ip == ip)) {
                    return "noChange";
                }
                for (var i = 0; i < this.reserveIpMacsList.length; i++) {
                    if (i == flagRow) {
                        continue;
                    }
                    if (this.reserveIpMacsList[i].mac.toLowerCase() == mac.toLowerCase()) {
                        return "mac";
                    }
                    if (this.reserveIpMacsList[i].ip == ip) {
                        return "ip";
                    }
                }
                return false;
            },
            /***　　把IP地址转换成二进制格式*　　@param string  ip  待转换的IP的地址*/
            ipToBinary: function (ip) {
                if (CheckUtil.checkIp(ip)) {
                    var ip_str = "",
                        ip_arr = ip.split(".");

                    for (var i = 0; i < 4; i++) {
                        curr_num = ip_arr[i];
                        number_bin = parseInt(curr_num);
                        number_bin = number_bin.toString(2);
                        count = 8 - number_bin.length;
                        for (var j = 0; j < count; j++) {
                            number_bin = "0" + number_bin;
                        }
                        ip_str += number_bin;
                    }
                    return ip_str;
                }

                return 0;
            },
            /***　　把二进制格式转换成IP地址*　　@param string  binary  待转换的二进制　　*/
            binaryToIp: function (binary) {
                if (binary.length == 32) {
                    a = parseInt(binary.substr(0, 8), 2);
                    b = parseInt(binary.substr(8, 8), 2);
                    c = parseInt(binary.substr(16, 8), 2);
                    d = parseInt(binary.slice(-8), 2);

                    return a + '.' + b + '.' + c + '.' + d;
                }

                return '';
            },
            /**
            *　　根据子网掩码和网关计算网络地址和广播地址
            *　　@param  string    mask    子网掩码
            *　　@param  string    gateway 网关
            */
            getNetworkBroadcastAddr: function (mask, gateway) {
                network_broadcast = [];
                network_addr = "";

                mask_arr = mask.split(".");
                ip_arr = gateway.split(".");

                // 计算IP的网络地址 与(&)运算
                for (var i = 0; i < 4; i++) {
                    number1 = parseInt(mask_arr[i]);
                    number2 = parseInt(ip_arr[i]);
                    network_addr += number1 & number2;
                    if (i < 3) {
                        network_addr += ".";
                    }
                }
                network_broadcast.push(network_addr);

                // 计算广播地址
                // 子掩码后面有几个0，就去掉IP地址后几位再补1
                mask_binary = this.ipToBinary(mask);
                gateway_binary = this.ipToBinary(gateway);

                mask_zero = mask_binary.split(0).length - 1;
                one_number = new Array(mask_zero + 1).join('1'); // IP地址后位补1
                gateway_hou_wei_bu_yi = gateway_binary.slice(0, -mask_zero) + one_number;

                network_broadcast.push(this.binaryToIp(gateway_hou_wei_bu_yi));

                return network_broadcast;
            },
            /** 计算一个IP 地址的大小 */
            ipChangeNum: function (ip) {
                var ip_str = "",
                    ip_arr = ip.split(".");

                for (var i = 0; i < 4; i++) {
                    var number_bin = ip_arr[i];
                    var count = 3 - number_bin.length;
                    for (var j = 0; j < count; j++) {
                        number_bin = "0" + number_bin;
                    }
                    ip_str += number_bin;
                }
                return parseInt(ip_str);
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
            this.getDataMacIp();
        }
    });
});
