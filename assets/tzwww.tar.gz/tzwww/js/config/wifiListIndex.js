/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-06-08 16:26:13
 * @,@LastEditTime: ,: 2021-06-09 11:10:02
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\config\wifiListIndex.js
 */
$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "WIRELESS_MACFILTER";
    items.push({ title: wirelessconfightml.tab_menu.wifiList24, url: 'html/config/wifiList24g.html' });
    items.push({ title: wirelessconfightml.tab_menu.wifiList5, url: 'html/config/wifiList5g.html' });
   	secondMenuClick(items,id);
});