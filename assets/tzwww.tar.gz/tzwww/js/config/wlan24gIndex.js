/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-05-21 15:10:12
 * @,@LastEditTime: ,: 2021-06-07 20:10:24
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\config\wlan24gIndex.js
 */
$(document).ready(function () {
    var tabs = TAB.advance;
    var items = [];
    var id = "WIRELESS_CONFIG";
    items.push({ title: wirelessconfightml.tab_menu.item1, url: 'html/config/mainWifiSetting.html' });
    var wlan2g_switch = sessionStorage.getItem("wlan2g_switch");
    if(wlan2g_switch == "1"){
        if(Page.pageHideCheck(19))
            items.push({ title: wirelessconfightml.tab_menu.item12, url: 'html/config/setting_24wifi_1.html' });
        if(Page.pageHideCheck(20))    
            items.push({ title: wirelessconfightml.tab_menu.item13, url: 'html/config/setting_24wifi_2.html' });
        if(Page.pageHideCheck(21))
            items.push({ title: wirelessconfightml.tab_menu.item14, url: 'html/config/setting_24wifi_3.html' });
        // if(Page.pageHideCheck(22))
        //     items.push({ title: wirelessconfightml.tab_menu.item15, url: 'html/config/setting_24wifi_4.html' });
    }
    
    
    
   	secondMenuClick(items,id);
});