$(document).ready(function () {
    var $mask = $('#mask');
    var fm = ["childForm", "apnSetting_template", "childFormId"];
    $("#childForm").addClass("setting_apn_form");
    var rules = {
            apnMTU: {
                required: true,
                range: [600, 1500],
                digits: true
            },
        },
        messages = {
            apnMTU: {
                required: CHECK.required.mtu,
                range: CHECK.format.mtu,
                digits:CHECK.format.digits
            },
        };
    var vm = new Vue({
        el: "#apnSetting_template",
        data: {
            apn_nat: DOC.apn.nat,
            colon: DOC.colon,
            status_enable: DOC.status.enable,
            status_disable: DOC.status.disable,
            apn_natLookBack: DOC.apn.natLookBack,
            apn_mtu: DOC.apn.mtu,
            apn_type: DOC.apn.type,
            apn_authentication: DOC.apn.authentication,
            apn_user: DOC.apn.user,
            apn_password: DOC.apn.password,
            form5_btnSetting: networktoolhtml.form5.btnSetting,
            title: DOC.apn.apnList,
            editBox: false,
            edit: networkconfightml.form1.edit,
            del: networkconfightml.form1.del,
            save: DOC.lbl.confirm,
            close: DOC.btn.close,
            resetAPN: DOC.apn.apnReset,
            help: [{
                    title: DOC.apnHelper.title1,
                    name: DOC.apnHelper.name1
                },
                {
                    title: DOC.apnHelper.title8,
                    name: DOC.apnHelper.name8
                },
                {
                    title: DOC.apnHelper.title4,
                    name: DOC.apnHelper.name4
                },
                {
                    title: DOC.apnHelper.title9,
                    name: DOC.apnHelper.name9
                },
                {
                    title: DOC.apnHelper.title11,
                    name: DOC.apnHelper.name11
                },
                {
                    title: DOC.apnHelper.title3,
                    name: DOC.apnHelper.name3
                },
                {
                    title: DOC.apnHelper.title5,
                    name: DOC.apnHelper.name5
                },
                {
                    title: DOC.apnHelper.title6,
                    name: DOC.apnHelper.name6
                },
                {
                    title: DOC.apnHelper.title7,
                    name: DOC.apnHelper.name7
                },
                 {
                    title: DOC.apnHelper.title10,
                    name: DOC.apnHelper.name10
                }
            ],
            select_authentication:[
                {
                    name:"NONE",
                    value:"0"
                },
                {
                    name:"PAP",
                    value:"1"
                },
                {
                    name:"CHAP",
                    value:"2"
                },
                {
                    name:"PAP&CHAP",
                    value:"3"
                }

            ],
            select_type: [{
                    value: "IP",
                    name: "IPV4"
                },
                {
                    value: "IPV6",
                    name: "IPV6"
                },
                {
                    value: "IPV4V6",
                    name: "IPV4&V6"
                }
            ],
            apnNat: false,
            apnMTU: '',
            selectType: '',
            selectAuth: '0',
            apnUserName: '',
            apnUserPassword: '',
            butAble: false,
            apnName: "",
            apnItem: '',
            flag: '',
            apn_list: [],
            add: DOC.apn.addAPN,
            defaultFlag: "",
            editNum: 0
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_CONFIG,
                        methods: JSONMethod.GET,
                        subcmd: 3
                    },
                    success: function (data) {
                        vm.apnNat = data.apnNatName == "1" ? true : false;
                        vm.apnMTU = data.apnMTU;
                        vm.selectType = data.selectType;
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_INFO_PROCESS,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.apn_list = datas.apn_list;
                        vm.editNum = 0;
                        for (var i = 0; i < datas.apn_list.length; i++) {
                            if (datas.apn_list[i].default_flag == "1") {
                                vm.defaultFlag = "1";
                            }
                            if (datas.apn_list[i].edit_flag == "1") {
                                vm.editNum += 1;
                            }
                        }
                    }
                });
            },
            btnSave: function () {
                this.butAble = true;
                var $form = $("#childForm");
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    this.butAble = false;
                    return;
                }
                fyAlertMsgLoading();
                var json = {};
                json.selectType = this.selectType;
                json.apnMTU = this.apnMTU;
                json.apnNatName = this.apnNat ? "1" : "0";
                json.method = JSONMethod.POST;
                json.subcmd = 3;
                json.cmd = RequestCmd.APN_CONFIG;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.butAble = false;
                        if (data.message == "0") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            },
            btnSaveList: function () {
                if (this.apn_list.length < 1) {
                    AlertUtil.alertMsg(DOC.apn.fullAPN);
                    return false;
                }
                var json = {};
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.APN_INFO_PROCESS;
                json.apn_list = this.apn_list;
                console.log(this.apn_list);
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            btnReset: function(){
                var json = {};
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.APN_INFO_PROCESS;
                json.apn_reset = "1";
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            var wait = setTimeout(function(){
                                vm.getData();
                                fyAlertMsgSuccess();
                            },5000);
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            addAPN: function () {
                if (this.editNum >= 4) {
                    AlertUtil.alertMsg(DOC.apn.fullAPN);
                    return false;
                }
                $mask.show();
                this.editBox = true;
                this.apnItem = '';
                this.apnName = "";
                this.selectAuth = "0";
                this.apnUserName = "";
                this.apnUserPassword = "";
            },
            btnClose: function () {
                $mask.hide();
                this.editBox = false;
                this.flag = '';
            },
            isAddSave: function () {
                if (this.apnItem == "" || this.apnName == "") {
                    AlertUtil.alertMsg(DOC.apn.emptyAPNName);
                    return false;
                }
                if (!CheckUtil.checkAPNName(this.apnName)) {
                    AlertUtil.alertMsg(CHECK.format.apnError);
                    return false;
                }
                if (!!this.flag) {
                    this.apn_list[this.flag].name = this.apnItem;
                    this.apn_list[this.flag].apnName = this.apnName;
                    this.apn_list[this.flag].selectAuthtication = this.selectAuth.toString();
                    this.apn_list[this.flag].apnUserName = this.apnUserName;
                    this.apn_list[this.flag].apnUserPassword = this.apnUserPassword;
                } else {
                    var tmp = {};
                    tmp.name = this.apnItem;
                    tmp.apnName = this.apnName;
                    console.log(this.selectAuth);
                    tmp.selectAuthtication = this.selectAuth.toString();
                    tmp.apnUserName = this.apnUserName;
                    tmp.apnUserPassword = this.apnUserPassword;
                    tmp.edit_flag = "1";
                    tmp.default_flag = "0";
                    this.apn_list.push(tmp);
                }
                this.editNum += 1;
                this.btnClose();
            },
            clickEdit: function (index) {
                this.flag = index;
                this.apnItem = this.apn_list[this.flag].name;
                this.apnName = this.apn_list[this.flag].apnName;
                this.selectAuth = this.apn_list[this.flag].selectAuthtication || "0";
                this.apnUserName = this.apn_list[this.flag].apnUserName;
                this.apnUserPassword = this.apn_list[this.flag].apnUserPassword;
                this.editBox = true;
                $mask.show();
            },
            clickDel: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.editNum -= 1;
                    vm.apn_list.splice(index, 1);
                });
            },
            defaultChange: function (index) {
                for (var i = 0; i < this.apn_list.length; i++) {
                    if (index == i) {
                        this.apn_list[i].default_flag = "1";
                    } else {
                        this.apn_list[i].default_flag = "0";
                    }
                }
                this.defaultFlag = "1";
            }
        },
        mounted: function () {
            Page.createForm2(fm);
            this.getData()
        }
    });
});