$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "WIRELESS_ADVANCE";
    items.push({ title: MENU.settingWifi.wifiAdvance, url: 'html/config/wlan24gAdvance.html' });
   	secondMenuClick(items,id);
});