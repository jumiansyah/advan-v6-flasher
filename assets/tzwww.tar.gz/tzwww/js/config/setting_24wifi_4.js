var fm = ["childForm", "wlform1_template", "childFormId"];
var form1 = wirelessconfightml.form1;
var showText = wirelessconfightml.prompt;
jQuery.validator.addMethod("checkchar", function(value, element) {
  return this.optional(element) || ( CheckUtil.checkAPNName(value));
  }, "");
var rules = {
    key: {
        required: true,
        rangelength: [8, 31],
        ssid_password: true
    },
    ssid: {
        required: true,
        ssidLength: true,
        ssid_name: true,
        checkchar:true
    }
};
var messages = {
    key: {
        required: CHECK.format.password,
        rangelength: showText.keyCkeckMsg,
        ssid_password: showText.keyCkeckMsg2
    },
    ssid: {
        required: showText.ssidCheckMsg1,
        ssidLength: showText.ssidCheckMsg2,
        ssid_name: showText.ssidCheckMsg3,
        checkchar: CHECK.format.formatError
    }
};
var vm = new Vue({
    el: "#wlform1_template",
    data: {
        wifiFunction: form1.wifiFunction,
        wifissidBd: wirelessconfightml.form1.ssidBd,
        wifiwmm: form1.wmm,
        wifissid: form1.ssid,
        wifiwepMode: form1.wepMode,
        wifikey: form1.key,
        wifiqr:form1.qr,
        wifimaxStation: form1.maxStation,
        enable: DOC.status.enable,
        disable: DOC.status.disable,
        btnSave: form1.btnSave,
        authenticationOption: WlanPara.authentication,
        authentication: "0",
        max_station: "",
        maxStationCmt: form1.maxStationCmt,
        wifiOpen: false,
        broadcast: false,
        wifiWmmVal: false,
        ssid: "",
        key: "",
        butAble: false,
        wifiWmmValDis: true,
        helps: [{
                title: wlan5ghtml.helper.title1,
                item: wlan5ghtml.helper.item1
            },
            {
                title: wlan5ghtml.helper.title2,
                item: wlan5ghtml.helper.item2
            },
            {
                title: wlan5ghtml.helper.wmmTh,
                item: wlan5ghtml.helper.wmmTd
            },
            {
                title: wlan5ghtml.helper.title3,
                item: wlan5ghtml.helper.item3
            },
            {
                title: wlan5ghtml.helper.title6,
                item: wlan5ghtml.helper.item6
            },
            {
                title: wlan5ghtml.helper.title7,
                item: wlan5ghtml.helper.item7
            }
        ],
        qrcode: "",
        isError:false,
        oldKey:""
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.WIRELESS_CONFIG,
                    methods: JSONMethod.GET,
                    subcmd: 4
                },
                success: function (data) {
                    vm.wifiOpen = data.wifiOpen == "1" ? true : false;
                    vm.broadcast = data.broadcast == "1" ? true : false;
                    vm.wifiWmmVal = data.wifiwmm == "1" ? true : false;
                    vm.ssid = Base64.decode(data.ssid);
                    vm.key = data.key;
                    vm.oldKey = data.key;
                    // vm.max_station = data.maxStation;
                    vm.authentication = data.authenticationType;

                    if(vm.authentication==4){
                        var tst = "WIFI:T:SAE"+";S:"+vm.ssid+";"+"P:"+vm.key+";;";
                    }else{
                        var tst = "WIFI:T:WPA;P:"+vm.key+";S:"+vm.ssid+";";
                    }
                    if(vm.authentication != 0){
                        $('#qrcode').qrcode({width: 164,height: 164,text: utf16to8(tst)});
                    }
                }
            })
        },
        clickBtnSave: function () {
            $("#qrcode>canvas").remove();
            this.butAble = true;
            var $form = $("#childForm");
            if (!CheckUtil.checkForm($form, rules, messages)) {
                this.butAble = false;
                this.isError = true;
                return;
            }
            this.isError = false;
            fyAlertMsgLoading();
            var json = {};
            json.wifiOpen = vm.wifiOpen ? "1" : "0";
            json.broadcast = vm.broadcast ? "1" : "0";
            json.wifiwmm = vm.wifiWmmVal ? "1" : "0";
            json.ssid = Base64.encode(vm.ssid);
            json.key = vm.key;
            // json.maxStation = vm.max_station;
            json.authenticationType = vm.authentication;
            json.method = JSONMethod.POST;
            json.cmd = RequestCmd.WIRELESS_CONFIG;
            json.subcmd = 4;
            Page.postJSON({
                json: json,
                success: function (data) {
                    vm.butAble = false;
                    if (data.message == "0") {
                        setTimeout(function () {
                            fyAlertMsgSuccess();
                            vm.getData();
                        }, 6000);
                    } else {
                        fyAlertMsgFail();
                    }
                }
            })
        }
    },
    mounted: function () {
        this.getData();
        Page.createForm(fm);
    },
    watch:{
        authentication:function(val){
            if(val=="0"){
                this.key = this.oldKey
            }
        }
    }
});